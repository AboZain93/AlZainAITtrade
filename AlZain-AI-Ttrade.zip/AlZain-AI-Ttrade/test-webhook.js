// Test webhook endpoint with sample telegram callback
const axios = require('axios');

const testWebhook = async () => {
  try {
    // Simulate a Telegram callback query
    const callbackData = {
      callback_query: {
        id: "test_123",
        data: "partial",
        message: {
          message_id: 123,
          chat: {
            id: 1039954480
          },
          date: Math.floor(Date.now() / 1000) - 300 // 5 minutes ago
        },
        from: {
          id: 1039954480,
          username: "testuser"
        }
      }
    };

    console.log('Testing webhook with data:', JSON.stringify(callbackData, null, 2));

    const response = await axios.post('http://localhost:5000/api/telegram/webhook', callbackData);
    
    console.log('Webhook response:', response.data);
    console.log('Status:', response.status);
    
    // Also test getting the feedback data
    const feedbackResponse = await axios.get('http://localhost:5000/api/telegram-feedback?limit=5');
    console.log('Latest feedback:', feedbackResponse.data);
    
  } catch (error) {
    console.error('Error testing webhook:', error.message);
    if (error.response) {
      console.error('Response data:', error.response.data);
    }
  }
};

testWebhook();