#!/bin/bash

# AlZainTrade APK Generator Script
# This script helps you generate an APK file from the PWA

echo "🚀 AlZainTrade - مولد ملف APK"
echo "================================="

# Get the current Replit URL
if [ ! -z "$REPL_SLUG" ] && [ ! -z "$REPL_OWNER" ]; then
    APP_URL="https://$REPL_SLUG.$REPL_OWNER.repl.co"
    echo "🌐 تم اكتشاف بيئة Replit"
    echo "   رابط التطبيق: $APP_URL"
else
    APP_URL="http://localhost:5000"
    echo "💻 تشغيل محلي"
    echo "   رابط التطبيق: $APP_URL"
fi

echo ""
echo "📱 معلومات التطبيق:"
echo "   الاسم: AlZainTrade - الزين تريد"
echo "   Package: com.alzaintrade.app"
echo "   الرابط: $APP_URL"
echo ""

echo "🛠️ طرق إنشاء APK:"
echo ""

echo "1️⃣ الطريقة الأسهل - PWA Builder:"
echo "   • اذهب إلى: https://www.pwabuilder.com/"
echo "   • أدخل الرابط: $APP_URL"
echo "   • انقر على 'Start'"
echo "   • اختر 'Android Package'"
echo "   • حمل APK الجاهز"
echo ""

echo "2️⃣ التحقق من إعدادات PWA:"
echo "   • Manifest: $APP_URL/manifest.json"
echo "   • Service Worker: $APP_URL/sw.js"
echo "   • Icons: متوفرة ✅"
echo ""

# Check if curl is available and test the manifest
if command -v curl &> /dev/null; then
    echo "🔍 فحص ملف Manifest..."
    if curl -s -f "$APP_URL/manifest.json" > /dev/null; then
        echo "   ✅ ملف Manifest متاح"
    else
        echo "   ❌ ملف Manifest غير متاح"
    fi
    
    echo "🔍 فحص Service Worker..."
    if curl -s -f "$APP_URL/sw.js" > /dev/null; then
        echo "   ✅ Service Worker متاح"
    else
        echo "   ❌ Service Worker غير متاح"
    fi
else
    echo "⚠️  curl غير متاح للفحص"
fi

echo ""
echo "📋 خطوات إضافية:"
echo "   1. تأكد من أن التطبيق يعمل في المتصفح"
echo "   2. اختبر PWA features (التثبيت)"
echo "   3. استخدم PWA Builder لإنشاء APK"
echo "   4. اختبر APK على جهاز أندرويد"
echo ""

echo "🔗 روابط مفيدة:"
echo "   • PWA Builder: https://www.pwabuilder.com/"
echo "   • دليل APK: ./APK-Guide.md"
echo "   • Android Studio: https://developer.android.com/studio"
echo ""

echo "✅ جاهز لإنشاء APK!"
echo "💡 نصيحة: ابدأ بـ PWA Builder للحصول على نتيجة سريعة"

# Create a quick link file for easy access
cat > apk-links.txt << EOF
AlZainTrade APK Generation Links
==============================

App URL: $APP_URL
PWA Builder: https://www.pwabuilder.com/
Manifest: $APP_URL/manifest.json
Service Worker: $APP_URL/sw.js

Quick Steps:
1. Copy App URL: $APP_URL
2. Go to PWA Builder: https://www.pwabuilder.com/
3. Paste URL and generate APK
4. Download and install on Android

Package Name: com.alzaintrade.app
App Name: AlZainTrade - الزين تريد
EOF

echo "📄 تم إنشاء ملف apk-links.txt مع الروابط المطلوبة"