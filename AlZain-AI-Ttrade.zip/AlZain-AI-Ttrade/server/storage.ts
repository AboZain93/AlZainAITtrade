import { 
  users, 
  marketAssets, 
  tradingRecommendations, 
  marketData, 
  technicalIndicators, 
  telegramStats,
  licenses,
  tradeHistory,
  systemSettings,
  telegramFeedback,
  mlTrainingData,
  assetPerformance,
  portfolios,
  portfolioAssets,
  portfolioHistory,
  tradingStrategies,
  marketAnalysis,
  products,
  userSessions,
  userActivityLogs,
  passwordResetTokens,
  emailVerificationTokens,
  deviceSessions,
  payments,
  notifications,
  type User, 
  type InsertUser,
  type MarketAsset,
  type InsertMarketAsset,
  type TradingRecommendation,
  type InsertTradingRecommendation,
  type MarketData,
  type InsertMarketData,
  type TechnicalIndicators,
  type InsertTechnicalIndicators,
  type TelegramStats,
  type InsertTelegramStats,
  type License,
  type InsertLicense,
  type TradeHistory,
  type InsertTradeHistory,
  type SystemSettings,
  type InsertSystemSettings,
  type TelegramFeedback,
  type InsertTelegramFeedback,
  type MlTrainingData,
  type InsertMlTrainingData,
  type AssetPerformance,
  type InsertAssetPerformance,
  type Portfolio,
  type InsertPortfolio,
  type PortfolioAsset,
  type InsertPortfolioAsset,
  type PortfolioHistory,
  type InsertPortfolioHistory,
  type TradingStrategy,
  type InsertTradingStrategy,
  type MarketAnalysis,
  type InsertMarketAnalysis,
  type Product,
  type InsertProduct,
  type UserSession,
  type InsertUserSession,
  type UserActivityLog,
  type InsertUserActivityLog,
  type PasswordResetToken,
  type InsertPasswordResetToken,
  type EmailVerificationToken,
  type InsertEmailVerificationToken,
  type DeviceSession,
  type InsertDeviceSession,
  type Payment,
  type InsertPayment,
  type Notification,
  type InsertNotification
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<InsertUser>): Promise<void>;
  
  // Market asset operations
  getAllMarketAssets(): Promise<MarketAsset[]>;
  getMarketAsset(symbol: string): Promise<MarketAsset | undefined>;
  createMarketAsset(asset: InsertMarketAsset): Promise<MarketAsset>;
  
  // Trading recommendation operations
  getAllTradingRecommendations(): Promise<TradingRecommendation[]>;
  getRecentTradingRecommendations(limit: number): Promise<TradingRecommendation[]>;
  getTradingRecommendation(id: number): Promise<TradingRecommendation | undefined>;
  createTradingRecommendation(recommendation: InsertTradingRecommendation): Promise<TradingRecommendation>;
  updateTradingRecommendationResult(id: number, result: string): Promise<void>;
  
  // Market data operations
  getLatestMarketData(): Promise<MarketData[]>;
  getMarketDataBySymbol(symbol: string): Promise<MarketData | undefined>;
  createMarketData(data: InsertMarketData): Promise<MarketData>;
  
  // Technical indicators operations
  getLatestTechnicalIndicators(): Promise<TechnicalIndicators[]>;
  getTechnicalIndicatorsBySymbol(symbol: string): Promise<TechnicalIndicators | undefined>;
  createTechnicalIndicators(indicators: InsertTechnicalIndicators): Promise<TechnicalIndicators>;
  
  // Telegram stats operations
  getTelegramStats(): Promise<TelegramStats | undefined>;
  createTelegramStats(stats: InsertTelegramStats): Promise<TelegramStats>;
  updateTelegramStats(stats: Partial<InsertTelegramStats>): Promise<void>;

  // Product operations
  getAllProducts(): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: number, updates: Partial<InsertProduct>): Promise<void>;

  // License operations
  createLicense(license: InsertLicense): Promise<License>;
  getLicenseByKey(licenseKey: string): Promise<License | undefined>;
  getLicensesByUser(userId: number): Promise<License[]>;
  updateLicense(id: number, updates: Partial<InsertLicense>): Promise<void>;

  // User session operations
  createUserSession(session: InsertUserSession): Promise<UserSession>;
  getUserSessionByToken(sessionToken: string): Promise<UserSession | undefined>;
  updateUserSession(id: number, updates: Partial<InsertUserSession>): Promise<void>;

  // User activity operations
  createUserActivityLog(log: InsertUserActivityLog): Promise<UserActivityLog>;
  getUserActivityLogs(userId: number, limit?: number): Promise<UserActivityLog[]>;

  // Password reset operations
  createPasswordResetToken(token: InsertPasswordResetToken): Promise<PasswordResetToken>;
  getPasswordResetToken(token: string): Promise<PasswordResetToken | undefined>;
  updatePasswordResetToken(id: number, updates: Partial<InsertPasswordResetToken>): Promise<void>;

  // Email verification operations
  createEmailVerificationToken(token: InsertEmailVerificationToken): Promise<EmailVerificationToken>;
  getEmailVerificationToken(token: string): Promise<EmailVerificationToken | undefined>;
  updateEmailVerificationToken(id: number, updates: Partial<InsertEmailVerificationToken>): Promise<void>;

  // Device session operations
  createDeviceSession(session: InsertDeviceSession): Promise<DeviceSession>;
  getUserDeviceSessions(userId: number): Promise<DeviceSession[]>;

  // Payment operations
  createPayment(payment: InsertPayment): Promise<Payment>;
  getUserPayments(userId: number): Promise<Payment[]>;

  // Notification operations
  createNotification(notification: InsertNotification): Promise<Notification>;
  getUserNotifications(userId: number, limit?: number): Promise<Notification[]>;
  markNotificationAsRead(id: number): Promise<void>;
  
  // Trade history operations
  createTradeHistory(trade: InsertTradeHistory): Promise<TradeHistory>;
  getTradeHistoryByLicense(licenseId: number): Promise<TradeHistory[]>;
  getTradeHistoryByUser(userId: number): Promise<TradeHistory[]>;
  
  // System settings operations
  getSystemSettings(): Promise<SystemSettings[]>;
  getSystemSetting(key: string): Promise<SystemSettings | undefined>;
  updateSystemSetting(key: string, value: string, description?: string): Promise<void>;

  // Telegram feedback operations
  createTelegramFeedback(feedback: InsertTelegramFeedback): Promise<TelegramFeedback>;
  getTelegramFeedbackByRecommendation(recommendationId: number): Promise<TelegramFeedback[]>;
  getTelegramFeedbackByAsset(assetSymbol: string): Promise<TelegramFeedback[]>;
  getAllTelegramFeedback(limit?: number): Promise<TelegramFeedback[]>;
  
  // ML training data operations
  createMlTrainingData(data: InsertMlTrainingData): Promise<MlTrainingData>;
  getMlTrainingDataByAsset(assetSymbol: string, limit?: number): Promise<MlTrainingData[]>;
  getAllMlTrainingData(limit?: number): Promise<MlTrainingData[]>;
  
  // Asset performance operations
  getAssetPerformance(assetSymbol: string): Promise<AssetPerformance | undefined>;
  createAssetPerformance(performance: InsertAssetPerformance): Promise<AssetPerformance>;
  updateAssetPerformance(assetSymbol: string, updates: Partial<InsertAssetPerformance>): Promise<void>;
  getAllAssetPerformance(): Promise<AssetPerformance[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User> = new Map();
  private marketAssets: Map<string, MarketAsset> = new Map();
  private tradingRecommendations: Map<number, TradingRecommendation> = new Map();
  private marketData: Map<string, MarketData> = new Map();
  private technicalIndicators: Map<string, TechnicalIndicators> = new Map();
  private telegramStats: TelegramStats | undefined;
  private telegramFeedback: Map<number, TelegramFeedback> = new Map();
  private mlTrainingData: Map<number, MlTrainingData> = new Map();
  private assetPerformance: Map<string, AssetPerformance> = new Map();
  private products: Map<number, Product> = new Map();
  private licenses: Map<string, License> = new Map();
  private userSessions: Map<string, UserSession> = new Map();
  private userActivityLogs: Map<number, UserActivityLog[]> = new Map();
  private passwordResetTokens: Map<string, PasswordResetToken> = new Map();
  private emailVerificationTokens: Map<string, EmailVerificationToken> = new Map();
  private deviceSessions: Map<number, DeviceSession[]> = new Map();
  private payments: Map<number, Payment[]> = new Map();
  private notifications: Map<number, Notification[]> = new Map();
  
  private currentUserId = 1;
  private currentAssetId = 1;
  private currentRecommendationId = 1;
  private currentMarketDataId = 1;
  private currentTechnicalIndicatorsId = 1;
  private currentTelegramStatsId = 1;
  private currentTelegramFeedbackId = 1;
  private currentMlTrainingDataId = 1;
  private currentAssetPerformanceId = 1;
  private currentProductId = 1;
  private currentLicenseId = 1;
  private currentSessionId = 1;
  private currentActivityLogId = 1;
  private currentTokenId = 1;
  private currentDeviceSessionId = 1;
  private currentPaymentId = 1;
  private currentNotificationId = 1;

  constructor() {
    this.initializeDefaultData();
  }

  private generateBasePrice(assetType: string): number {
    switch (assetType) {
      case 'forex':
        return 1.0 + Math.random() * 0.5; // 1.0 - 1.5 for forex pairs
      case 'crypto':
        return 100 + Math.random() * 50000; // 100 - 50100 for crypto
      case 'commodity':
        return 1500 + Math.random() * 500; // 1500 - 2000 for commodities like gold
      case 'index':
        return 3000 + Math.random() * 2000; // 3000 - 5000 for indices
      case 'stock':
        return 50 + Math.random() * 200; // 50 - 250 for stocks
      default:
        return 100 + Math.random() * 100; // Default range
    }
  }

  private initializeDefaultData() {
    // Add Quotex platform assets
    const defaultAssets = [
      // Major Forex Pairs
      { symbol: "EUR/USD", name: "Euro/US Dollar", type: "forex", isActive: true },
      { symbol: "GBP/USD", name: "British Pound/US Dollar", type: "forex", isActive: true },
      { symbol: "USD/JPY", name: "US Dollar/Japanese Yen", type: "forex", isActive: true },
      { symbol: "USD/CHF", name: "US Dollar/Swiss Franc", type: "forex", isActive: true },
      { symbol: "AUD/USD", name: "Australian Dollar/US Dollar", type: "forex", isActive: true },
      { symbol: "USD/CAD", name: "US Dollar/Canadian Dollar", type: "forex", isActive: true },
      { symbol: "NZD/USD", name: "New Zealand Dollar/US Dollar", type: "forex", isActive: true },
      
      // Minor Forex Pairs
      { symbol: "EUR/GBP", name: "Euro/British Pound", type: "forex", isActive: true },
      { symbol: "EUR/JPY", name: "Euro/Japanese Yen", type: "forex", isActive: true },
      { symbol: "EUR/CHF", name: "Euro/Swiss Franc", type: "forex", isActive: true },
      { symbol: "EUR/AUD", name: "Euro/Australian Dollar", type: "forex", isActive: true },
      { symbol: "EUR/CAD", name: "Euro/Canadian Dollar", type: "forex", isActive: true },
      { symbol: "GBP/JPY", name: "British Pound/Japanese Yen", type: "forex", isActive: true },
      { symbol: "GBP/CHF", name: "British Pound/Swiss Franc", type: "forex", isActive: true },
      { symbol: "GBP/AUD", name: "British Pound/Australian Dollar", type: "forex", isActive: true },
      { symbol: "GBP/CAD", name: "British Pound/Canadian Dollar", type: "forex", isActive: true },
      { symbol: "AUD/JPY", name: "Australian Dollar/Japanese Yen", type: "forex", isActive: true },
      { symbol: "AUD/CHF", name: "Australian Dollar/Swiss Franc", type: "forex", isActive: true },
      { symbol: "AUD/CAD", name: "Australian Dollar/Canadian Dollar", type: "forex", isActive: true },
      { symbol: "CAD/JPY", name: "Canadian Dollar/Japanese Yen", type: "forex", isActive: true },
      { symbol: "CAD/CHF", name: "Canadian Dollar/Swiss Franc", type: "forex", isActive: true },
      { symbol: "CHF/JPY", name: "Swiss Franc/Japanese Yen", type: "forex", isActive: true },
      { symbol: "NZD/JPY", name: "New Zealand Dollar/Japanese Yen", type: "forex", isActive: true },
      { symbol: "NZD/CHF", name: "New Zealand Dollar/Swiss Franc", type: "forex", isActive: true },
      { symbol: "NZD/CAD", name: "New Zealand Dollar/Canadian Dollar", type: "forex", isActive: true },
      
      // Exotic Forex Pairs
      { symbol: "USD/TRY", name: "US Dollar/Turkish Lira", type: "forex", isActive: true },
      { symbol: "EUR/TRY", name: "Euro/Turkish Lira", type: "forex", isActive: true },
      { symbol: "GBP/TRY", name: "British Pound/Turkish Lira", type: "forex", isActive: true },
      { symbol: "USD/ZAR", name: "US Dollar/South African Rand", type: "forex", isActive: true },
      { symbol: "USD/MXN", name: "US Dollar/Mexican Peso", type: "forex", isActive: true },
      { symbol: "USD/NOK", name: "US Dollar/Norwegian Krone", type: "forex", isActive: true },
      { symbol: "USD/SEK", name: "US Dollar/Swedish Krona", type: "forex", isActive: true },
      { symbol: "USD/SGD", name: "US Dollar/Singapore Dollar", type: "forex", isActive: true },
      { symbol: "USD/HKD", name: "US Dollar/Hong Kong Dollar", type: "forex", isActive: true },
      { symbol: "USD/PLN", name: "US Dollar/Polish Zloty", type: "forex", isActive: true },
      { symbol: "USD/CZK", name: "US Dollar/Czech Koruna", type: "forex", isActive: true },
      { symbol: "USD/HUF", name: "US Dollar/Hungarian Forint", type: "forex", isActive: true },
      { symbol: "USD/IDR", name: "US Dollar/Indonesian Rupiah", type: "forex", isActive: true },
      { symbol: "USD/THB", name: "US Dollar/Thai Baht", type: "forex", isActive: true },
      { symbol: "USD/KRW", name: "US Dollar/South Korean Won", type: "forex", isActive: true },
      { symbol: "USD/INR", name: "US Dollar/Indian Rupee", type: "forex", isActive: true },
      { symbol: "USD/BRL", name: "US Dollar/Brazilian Real", type: "forex", isActive: true },
      { symbol: "USD/RUB", name: "US Dollar/Russian Ruble", type: "forex", isActive: true },
      { symbol: "USD/CNY", name: "US Dollar/Chinese Yuan", type: "forex", isActive: true },
      
      // Cryptocurrencies
      { symbol: "BTC/USD", name: "Bitcoin/US Dollar", type: "crypto", isActive: true },
      { symbol: "ETH/USD", name: "Ethereum/US Dollar", type: "crypto", isActive: true },
      { symbol: "LTC/USD", name: "Litecoin/US Dollar", type: "crypto", isActive: true },
      { symbol: "XRP/USD", name: "Ripple/US Dollar", type: "crypto", isActive: true },
      { symbol: "ADA/USD", name: "Cardano/US Dollar", type: "crypto", isActive: true },
      { symbol: "DOT/USD", name: "Polkadot/US Dollar", type: "crypto", isActive: true },
      { symbol: "LINK/USD", name: "Chainlink/US Dollar", type: "crypto", isActive: true },
      { symbol: "BCH/USD", name: "Bitcoin Cash/US Dollar", type: "crypto", isActive: true },
      { symbol: "XLM/USD", name: "Stellar/US Dollar", type: "crypto", isActive: true },
      { symbol: "DOGE/USD", name: "Dogecoin/US Dollar", type: "crypto", isActive: true },
      { symbol: "UNI/USD", name: "Uniswap/US Dollar", type: "crypto", isActive: true },
      { symbol: "MATIC/USD", name: "Polygon/US Dollar", type: "crypto", isActive: true },
      { symbol: "AVAX/USD", name: "Avalanche/US Dollar", type: "crypto", isActive: true },
      { symbol: "SOL/USD", name: "Solana/US Dollar", type: "crypto", isActive: true },
      { symbol: "ATOM/USD", name: "Cosmos/US Dollar", type: "crypto", isActive: true },
      
      // Commodities
      { symbol: "XAU/USD", name: "Gold/US Dollar", type: "commodity", isActive: true },
      { symbol: "XAG/USD", name: "Silver/US Dollar", type: "commodity", isActive: true },
      { symbol: "XPD/USD", name: "Palladium/US Dollar", type: "commodity", isActive: true },
      { symbol: "XPT/USD", name: "Platinum/US Dollar", type: "commodity", isActive: true },
      { symbol: "CRUDE/USD", name: "Crude Oil/US Dollar", type: "commodity", isActive: true },
      { symbol: "BRENT/USD", name: "Brent Oil/US Dollar", type: "commodity", isActive: true },
      { symbol: "NGAS/USD", name: "Natural Gas/US Dollar", type: "commodity", isActive: true },
      { symbol: "COPPER/USD", name: "Copper/US Dollar", type: "commodity", isActive: true },
      { symbol: "SUGAR/USD", name: "Sugar/US Dollar", type: "commodity", isActive: true },
      { symbol: "COFFEE/USD", name: "Coffee/US Dollar", type: "commodity", isActive: true },
      { symbol: "WHEAT/USD", name: "Wheat/US Dollar", type: "commodity", isActive: true },
      { symbol: "CORN/USD", name: "Corn/US Dollar", type: "commodity", isActive: true },
      
      // Stock Indices
      { symbol: "SPX", name: "S&P 500", type: "index", isActive: true },
      { symbol: "DJI", name: "Dow Jones Industrial Average", type: "index", isActive: true },
      { symbol: "IXIC", name: "NASDAQ Composite", type: "index", isActive: true },
      { symbol: "RUT", name: "Russell 2000", type: "index", isActive: true },
      { symbol: "FTSE", name: "FTSE 100", type: "index", isActive: true },
      { symbol: "DAX", name: "DAX 30", type: "index", isActive: true },
      { symbol: "CAC", name: "CAC 40", type: "index", isActive: true },
      { symbol: "ASX", name: "ASX 200", type: "index", isActive: true },
      { symbol: "NIKKEI", name: "Nikkei 225", type: "index", isActive: true },
      { symbol: "HSI", name: "Hang Seng Index", type: "index", isActive: true },
      { symbol: "KOSPI", name: "KOSPI", type: "index", isActive: true },
      { symbol: "TSX", name: "TSX Composite", type: "index", isActive: true },
      { symbol: "IBEX", name: "IBEX 35", type: "index", isActive: true },
      { symbol: "MIB", name: "FTSE MIB", type: "index", isActive: true },
      { symbol: "SMI", name: "Swiss Market Index", type: "index", isActive: true },
      { symbol: "BVSP", name: "Bovespa", type: "index", isActive: true },
      { symbol: "MOEX", name: "MOEX Russia Index", type: "index", isActive: true },
      { symbol: "EGX30", name: "EGX 30", type: "index", isActive: true },
      { symbol: "TASI", name: "TASI", type: "index", isActive: true },
      { symbol: "DFM", name: "DFM General Index", type: "index", isActive: true },
      
      // Individual Stocks (Popular ones)
      { symbol: "AAPL", name: "Apple Inc.", type: "stock", isActive: true },
      { symbol: "GOOGL", name: "Alphabet Inc.", type: "stock", isActive: true },
      { symbol: "MSFT", name: "Microsoft Corporation", type: "stock", isActive: true },
      { symbol: "AMZN", name: "Amazon.com Inc.", type: "stock", isActive: true },
      { symbol: "TSLA", name: "Tesla Inc.", type: "stock", isActive: true },
      { symbol: "META", name: "Meta Platforms Inc.", type: "stock", isActive: true },
      { symbol: "NVDA", name: "NVIDIA Corporation", type: "stock", isActive: true },
      { symbol: "NFLX", name: "Netflix Inc.", type: "stock", isActive: true },
      { symbol: "BABA", name: "Alibaba Group", type: "stock", isActive: true },
      { symbol: "JPM", name: "JPMorgan Chase & Co.", type: "stock", isActive: true },
      { symbol: "JNJ", name: "Johnson & Johnson", type: "stock", isActive: true },
      { symbol: "V", name: "Visa Inc.", type: "stock", isActive: true },
      { symbol: "PG", name: "Procter & Gamble", type: "stock", isActive: true },
      { symbol: "UNH", name: "UnitedHealth Group", type: "stock", isActive: true },
      { symbol: "HD", name: "Home Depot Inc.", type: "stock", isActive: true },
      { symbol: "MA", name: "Mastercard Inc.", type: "stock", isActive: true },
      { symbol: "BAC", name: "Bank of America", type: "stock", isActive: true },
      { symbol: "DIS", name: "Walt Disney Company", type: "stock", isActive: true },
      { symbol: "PYPL", name: "PayPal Holdings", type: "stock", isActive: true },
      { symbol: "ADBE", name: "Adobe Inc.", type: "stock", isActive: true },
    ];

    defaultAssets.forEach(asset => {
      const id = this.currentAssetId++;
      this.marketAssets.set(asset.symbol, { ...asset, id });
      
      // Also create sample market data for each asset
      const marketDataId = this.currentMarketDataId++;
      const basePrice = this.generateBasePrice(asset.type);
      const change = (Math.random() - 0.5) * basePrice * 0.02; // ±2% change
      const marketData: MarketData = {
        id: marketDataId,
        symbol: asset.symbol,
        price: basePrice + change,
        change: change,
        changePercent: (change / basePrice) * 100,
        volume: Math.floor(Math.random() * 100000) + 10000,
        timestamp: new Date()
      };
      this.marketData.set(asset.symbol, marketData);
    });

    // Initialize telegram stats
    this.telegramStats = {
      id: this.currentTelegramStatsId++,
      sentToday: 47,
      subscribers: 1234,
      responseRate: 94.0,
      lastSent: new Date(),
      updatedAt: new Date(),
    };

    // Add sample trading recommendations
    const sampleRecommendations = [
      {
        assetSymbol: "EUR/USD",
        direction: "BUY",
        confidence: 91.5,
        riskLevel: "low",
        technicalAnalysis: "RSI oversold condition, MACD positive divergence",
        marketStatus: "UPTREND مع قوة 85%",
        entryTime: new Date().toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' }),
        duration: "5 دقائق",
        trend: "UPTREND",
        liquidity: "مرتفعة",
        result: "success",
        sentToTelegram: true,
      },
      {
        assetSymbol: "GBP/USD",
        direction: "SELL",
        confidence: 78.3,
        riskLevel: "medium",
        technicalAnalysis: "RSI overbought condition, price below moving averages",
        marketStatus: "DOWNTREND مع قوة 62%",
        entryTime: new Date().toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' }),
        duration: "3 دقائق",
        trend: "DOWNTREND",
        liquidity: "متوسطة",
        result: "pending",
        sentToTelegram: true,
      },
      {
        assetSymbol: "XAU/USD",
        direction: "BUY",
        confidence: 88.7,
        riskLevel: "low",
        technicalAnalysis: "Price above moving averages, MACD positive divergence",
        marketStatus: "UPTREND مع قوة 79%",
        entryTime: new Date().toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' }),
        duration: "2 دقيقة",
        trend: "UPTREND",
        liquidity: "مرتفعة",
        result: "success",
        sentToTelegram: true,
      }
    ];

    sampleRecommendations.forEach(rec => {
      const id = this.currentRecommendationId++;
      const recommendation: TradingRecommendation = { 
        ...rec, 
        id, 
        createdAt: new Date() 
      };
      this.tradingRecommendations.set(id, recommendation);
    });

    // Add sample telegram feedback for testing analytics
    const sampleFeedback = [
      {
        recommendationId: 1,
        feedbackType: 'success' as const,
        assetSymbol: "EUR/USD",
        direction: "BUY",
        confidence: 85.4,
        actualResult: "success",
        responseTime: 5
      },
      {
        recommendationId: 2,
        feedbackType: 'partial' as const,
        assetSymbol: "GBP/USD",
        direction: "SELL",
        confidence: 78.3,
        actualResult: "partial",
        responseTime: 8
      },
      {
        recommendationId: 3,
        feedbackType: 'success' as const,
        assetSymbol: "XAU/USD",
        direction: "BUY",
        confidence: 88.7,
        actualResult: "success",
        responseTime: 3
      },
      {
        recommendationId: 1,
        feedbackType: 'failure' as const,
        assetSymbol: "USD/JPY",
        direction: "SELL",
        confidence: 65.2,
        actualResult: "failure",
        responseTime: 12
      },
      {
        recommendationId: 2,
        feedbackType: 'success' as const,
        assetSymbol: "BTC/USD",
        direction: "BUY",
        confidence: 92.1,
        actualResult: "success",
        responseTime: 4
      }
    ];

    sampleFeedback.forEach(feedback => {
      const id = this.currentTelegramFeedbackId++;
      const telegramFeedback: TelegramFeedback = {
        ...feedback,
        id,
        createdAt: new Date(),
        userId: null,
        messageId: `demo_msg_${id}`,
        chatId: `demo_chat_${id}`,
      };
      this.telegramFeedback.set(id, telegramFeedback);
    });

    // Add sample ML training data
    const sampleMLData = [
      {
        assetSymbol: "EUR/USD",
        direction: "BUY",
        originalConfidence: 85.4,
        actualResult: "success",
        successScore: 0.9
      },
      {
        assetSymbol: "GBP/USD",
        direction: "SELL",
        originalConfidence: 78.3,
        actualResult: "partial",
        successScore: 0.6
      },
      {
        assetSymbol: "XAU/USD",
        direction: "BUY",
        originalConfidence: 88.7,
        actualResult: "success",
        successScore: 0.95
      },
      {
        assetSymbol: "USD/JPY",
        direction: "SELL",
        originalConfidence: 65.2,
        actualResult: "failure",
        successScore: 0.2
      },
      {
        assetSymbol: "BTC/USD",
        direction: "BUY",
        originalConfidence: 92.1,
        actualResult: "success",
        successScore: 0.98
      }
    ];

    sampleMLData.forEach(mlData => {
      const id = this.currentMlTrainingDataId++;
      const trainingData: MlTrainingData = {
        ...mlData,
        id,
        createdAt: new Date(),
        recommendationId: null,
        technicalIndicators: {},
        marketConditions: {},
        timingFactors: {},
        learningWeight: null,
      };
      this.mlTrainingData.set(id, trainingData);
    });

    // Add sample asset performance data
    const samplePerformance = [
      {
        assetSymbol: "EUR/USD",
        totalRecommendations: 25,
        successfulTrades: 20,
        partialSuccessTrades: 3,
        failedTrades: 2,
        successRate: 80.0,
        averageConfidence: 78.5
      },
      {
        assetSymbol: "GBP/USD",
        totalRecommendations: 18,
        successfulTrades: 12,
        partialSuccessTrades: 4,
        failedTrades: 2,
        successRate: 66.7,
        averageConfidence: 75.2
      },
      {
        assetSymbol: "XAU/USD",
        totalRecommendations: 22,
        successfulTrades: 19,
        partialSuccessTrades: 2,
        failedTrades: 1,
        successRate: 86.4,
        averageConfidence: 85.8
      },
      {
        assetSymbol: "BTC/USD",
        totalRecommendations: 15,
        successfulTrades: 13,
        partialSuccessTrades: 1,
        failedTrades: 1,
        successRate: 86.7,
        averageConfidence: 88.3
      },
      {
        assetSymbol: "USD/JPY",
        totalRecommendations: 20,
        successfulTrades: 11,
        partialSuccessTrades: 5,
        failedTrades: 4,
        successRate: 55.0,
        averageConfidence: 68.9
      }
    ];

    samplePerformance.forEach(performance => {
      const id = this.currentAssetPerformanceId++;
      const assetPerformance: AssetPerformance = {
        ...performance,
        id,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      this.assetPerformance.set(performance.assetSymbol, assetPerformance);
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { 
      ...insertUser, 
      id, 
      firstName: insertUser.firstName || null,
      lastName: insertUser.lastName || null,
      phoneNumber: insertUser.phoneNumber || null,
      country: insertUser.country || null,
      telegramId: insertUser.telegramId || null,
      role: insertUser.role || "user",
      accountStatus: insertUser.accountStatus || "active",
      emailVerified: insertUser.emailVerified || false,
      phoneVerified: insertUser.phoneVerified || false,
      twoFactorEnabled: insertUser.twoFactorEnabled || false,
      lastLoginAt: insertUser.lastLoginAt || null,
      profileImage: insertUser.profileImage || null,
      timezone: insertUser.timezone || "UTC",
      language: insertUser.language || "en",
      isActive: insertUser.isActive !== false,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, updates: Partial<InsertUser>): Promise<void> {
    const user = this.users.get(id);
    if (user) {
      const updatedUser = { ...user, ...updates, updatedAt: new Date() };
      this.users.set(id, updatedUser);
    }
  }

  // Market asset operations
  async getAllMarketAssets(): Promise<MarketAsset[]> {
    return Array.from(this.marketAssets.values()).filter(asset => asset.isActive);
  }

  async getMarketAsset(symbol: string): Promise<MarketAsset | undefined> {
    return this.marketAssets.get(symbol);
  }

  async createMarketAsset(insertAsset: InsertMarketAsset): Promise<MarketAsset> {
    const id = this.currentAssetId++;
    const asset: MarketAsset = { 
      ...insertAsset, 
      id,
      isActive: insertAsset.isActive || null
    };
    this.marketAssets.set(asset.symbol, asset);
    return asset;
  }

  // Trading recommendation operations
  async getAllTradingRecommendations(): Promise<TradingRecommendation[]> {
    return Array.from(this.tradingRecommendations.values())
      .sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime());
  }

  async getRecentTradingRecommendations(limit: number): Promise<TradingRecommendation[]> {
    const all = await this.getAllTradingRecommendations();
    return all.slice(0, limit);
  }

  async getTradingRecommendation(id: number): Promise<TradingRecommendation | undefined> {
    return this.tradingRecommendations.get(id);
  }

  async createTradingRecommendation(insertRecommendation: InsertTradingRecommendation): Promise<TradingRecommendation> {
    const id = this.currentRecommendationId++;
    const recommendation: TradingRecommendation = { 
      ...insertRecommendation, 
      id, 
      result: insertRecommendation.result || null,
      sentToTelegram: insertRecommendation.sentToTelegram || null,
      createdAt: new Date() 
    };
    this.tradingRecommendations.set(id, recommendation);
    return recommendation;
  }

  async updateTradingRecommendationResult(id: number, result: string): Promise<void> {
    const recommendation = this.tradingRecommendations.get(id);
    if (recommendation) {
      recommendation.result = result;
      this.tradingRecommendations.set(id, recommendation);
    }
  }

  // Market data operations
  async getLatestMarketData(): Promise<MarketData[]> {
    return Array.from(this.marketData.values());
  }

  async getMarketDataBySymbol(symbol: string): Promise<MarketData | undefined> {
    return this.marketData.get(symbol);
  }

  async createMarketData(insertData: InsertMarketData): Promise<MarketData> {
    const id = this.currentMarketDataId++;
    const data: MarketData = { 
      ...insertData, 
      id, 
      volume: insertData.volume || null,
      timestamp: new Date() 
    };
    this.marketData.set(data.symbol, data);
    return data;
  }

  // Technical indicators operations
  async getLatestTechnicalIndicators(): Promise<TechnicalIndicators[]> {
    return Array.from(this.technicalIndicators.values());
  }

  async getTechnicalIndicatorsBySymbol(symbol: string): Promise<TechnicalIndicators | undefined> {
    return this.technicalIndicators.get(symbol);
  }

  async createTechnicalIndicators(insertIndicators: InsertTechnicalIndicators): Promise<TechnicalIndicators> {
    const id = this.currentTechnicalIndicatorsId++;
    const indicators: TechnicalIndicators = { 
      ...insertIndicators, 
      id, 
      volume: insertIndicators.volume || null,
      rsi: insertIndicators.rsi || null,
      macd: insertIndicators.macd || null,
      ma20: insertIndicators.ma20 || null,
      ma50: insertIndicators.ma50 || null,
      signal: insertIndicators.signal || null,
      timestamp: new Date() 
    };
    this.technicalIndicators.set(indicators.symbol, indicators);
    return indicators;
  }

  // Telegram stats operations
  async getTelegramStats(): Promise<TelegramStats | undefined> {
    return this.telegramStats;
  }

  async createTelegramStats(insertStats: InsertTelegramStats): Promise<TelegramStats> {
    const id = this.currentTelegramStatsId++;
    const stats: TelegramStats = { 
      ...insertStats, 
      id, 
      sentToday: insertStats.sentToday || null,
      subscribers: insertStats.subscribers || null,
      responseRate: insertStats.responseRate || null,
      lastSent: insertStats.lastSent || null,
      updatedAt: new Date() 
    };
    this.telegramStats = stats;
    return stats;
  }

  async updateTelegramStats(updateStats: Partial<InsertTelegramStats>): Promise<void> {
    if (this.telegramStats) {
      this.telegramStats = {
        ...this.telegramStats,
        ...updateStats,
        updatedAt: new Date(),
      };
    }
  }

  // Product operations
  async getAllProducts(): Promise<Product[]> {
    return Array.from(this.products.values()).filter(product => product.isActive);
  }

  async getProduct(id: number): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const id = this.currentProductId++;
    const product: Product = {
      ...insertProduct,
      id,
      isActive: insertProduct.isActive !== false,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.products.set(id, product);
    return product;
  }

  async updateProduct(id: number, updates: Partial<InsertProduct>): Promise<void> {
    const product = this.products.get(id);
    if (product) {
      const updatedProduct = { ...product, ...updates, updatedAt: new Date() };
      this.products.set(id, updatedProduct);
    }
  }

  // License operations
  async createLicense(insertLicense: InsertLicense): Promise<License> {
    const id = this.currentLicenseId++;
    const license: License = { 
      ...insertLicense,
      id,
      status: insertLicense.status || "active",
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.licenses.set(license.licenseKey, license);
    return license;
  }

  async getLicenseByKey(licenseKey: string): Promise<License | undefined> {
    return this.licenses.get(licenseKey);
  }

  async getLicensesByUser(userId: number): Promise<License[]> {
    return Array.from(this.licenses.values()).filter(license => license.userId === userId);
  }

  async updateLicense(id: number, updates: Partial<InsertLicense>): Promise<void> {
    const license = Array.from(this.licenses.values()).find(l => l.id === id);
    if (license) {
      const updatedLicense = { ...license, ...updates, updatedAt: new Date() };
      this.licenses.set(license.licenseKey, updatedLicense);
    }
  }

  // User session operations
  async createUserSession(insertSession: InsertUserSession): Promise<UserSession> {
    const id = this.currentSessionId++;
    const session: UserSession = {
      ...insertSession,
      id,
      isActive: insertSession.isActive !== false,
      createdAt: new Date()
    };
    this.userSessions.set(session.sessionToken, session);
    return session;
  }

  async getUserSessionByToken(sessionToken: string): Promise<UserSession | undefined> {
    return this.userSessions.get(sessionToken);
  }

  async updateUserSession(id: number, updates: Partial<InsertUserSession>): Promise<void> {
    const session = Array.from(this.userSessions.values()).find(s => s.id === id);
    if (session) {
      const updatedSession = { ...session, ...updates };
      this.userSessions.set(session.sessionToken, updatedSession);
    }
  }

  // User activity operations
  async createUserActivityLog(insertLog: InsertUserActivityLog): Promise<UserActivityLog> {
    const id = this.currentActivityLogId++;
    const log: UserActivityLog = {
      ...insertLog,
      id,
      createdAt: new Date()
    };
    
    const userLogs = this.userActivityLogs.get(insertLog.userId) || [];
    userLogs.push(log);
    this.userActivityLogs.set(insertLog.userId, userLogs);
    
    return log;
  }

  async getUserActivityLogs(userId: number, limit?: number): Promise<UserActivityLog[]> {
    const logs = this.userActivityLogs.get(userId) || [];
    return limit ? logs.slice(-limit) : logs;
  }

  // Password reset operations
  async createPasswordResetToken(insertToken: InsertPasswordResetToken): Promise<PasswordResetToken> {
    const id = this.currentTokenId++;
    const token: PasswordResetToken = {
      ...insertToken,
      id,
      used: false,
      createdAt: new Date()
    };
    this.passwordResetTokens.set(token.token, token);
    return token;
  }

  async getPasswordResetToken(token: string): Promise<PasswordResetToken | undefined> {
    return this.passwordResetTokens.get(token);
  }

  async updatePasswordResetToken(id: number, updates: Partial<InsertPasswordResetToken>): Promise<void> {
    const token = Array.from(this.passwordResetTokens.values()).find(t => t.id === id);
    if (token) {
      const updatedToken = { ...token, ...updates };
      this.passwordResetTokens.set(token.token, updatedToken);
    }
  }

  // Email verification operations
  async createEmailVerificationToken(insertToken: InsertEmailVerificationToken): Promise<EmailVerificationToken> {
    const id = this.currentTokenId++;
    const token: EmailVerificationToken = {
      ...insertToken,
      id,
      used: false,
      createdAt: new Date()
    };
    this.emailVerificationTokens.set(token.token, token);
    return token;
  }

  async getEmailVerificationToken(token: string): Promise<EmailVerificationToken | undefined> {
    return this.emailVerificationTokens.get(token);
  }

  async updateEmailVerificationToken(id: number, updates: Partial<InsertEmailVerificationToken>): Promise<void> {
    const token = Array.from(this.emailVerificationTokens.values()).find(t => t.id === id);
    if (token) {
      const updatedToken = { ...token, ...updates };
      this.emailVerificationTokens.set(token.token, updatedToken);
    }
  }

  // Device session operations
  async createDeviceSession(insertSession: InsertDeviceSession): Promise<DeviceSession> {
    const id = this.currentDeviceSessionId++;
    const session: DeviceSession = {
      ...insertSession,
      id,
      isActive: insertSession.isActive !== false,
      createdAt: new Date()
    };
    
    const userSessions = this.deviceSessions.get(insertSession.userId) || [];
    userSessions.push(session);
    this.deviceSessions.set(insertSession.userId, userSessions);
    
    return session;
  }

  async getUserDeviceSessions(userId: number): Promise<DeviceSession[]> {
    return this.deviceSessions.get(userId) || [];
  }

  // Payment operations
  async createPayment(insertPayment: InsertPayment): Promise<Payment> {
    const id = this.currentPaymentId++;
    const payment: Payment = {
      ...insertPayment,
      id,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    const userPayments = this.payments.get(insertPayment.userId) || [];
    userPayments.push(payment);
    this.payments.set(insertPayment.userId, userPayments);
    
    return payment;
  }

  async getUserPayments(userId: number): Promise<Payment[]> {
    return this.payments.get(userId) || [];
  }

  // Notification operations
  async createNotification(insertNotification: InsertNotification): Promise<Notification> {
    const id = this.currentNotificationId++;
    const notification: Notification = {
      ...insertNotification,
      id,
      read: false,
      createdAt: new Date()
    };
    
    const userNotifications = this.notifications.get(insertNotification.userId) || [];
    userNotifications.push(notification);
    this.notifications.set(insertNotification.userId, userNotifications);
    
    return notification;
  }

  async getUserNotifications(userId: number, limit?: number): Promise<Notification[]> {
    const notifications = this.notifications.get(userId) || [];
    return limit ? notifications.slice(-limit) : notifications;
  }

  async markNotificationAsRead(id: number): Promise<void> {
    for (const [userId, notifications] of this.notifications.entries()) {
      const notification = notifications.find(n => n.id === id);
      if (notification) {
        notification.read = true;
        notification.readAt = new Date();
        break;
      }
    }
  }
  
  async createTradeHistory(insertTrade: InsertTradeHistory): Promise<TradeHistory> {
    const trade: TradeHistory = {
      id: this.currentTelegramStatsId++,
      licenseId: insertTrade.licenseId || null,
      userId: insertTrade.userId || null,
      recommendationId: insertTrade.recommendationId || null,
      assetSymbol: insertTrade.assetSymbol,
      direction: insertTrade.direction,
      confidence: insertTrade.confidence,
      result: insertTrade.result || null,
      tradedAt: new Date()
    };
    return trade;
  }

  async getTradeHistoryByLicense(licenseId: number): Promise<TradeHistory[]> {
    return [];
  }

  async getTradeHistoryByUser(userId: number): Promise<TradeHistory[]> {
    return [];
  }
  
  async getSystemSettings(): Promise<SystemSettings[]> {
    return [];
  }

  async getSystemSetting(key: string): Promise<SystemSettings | undefined> {
    return undefined;
  }

  async updateSystemSetting(key: string, value: string, description?: string): Promise<void> {
    // Stub implementation
  }

  // Telegram feedback operations
  async createTelegramFeedback(insertFeedback: InsertTelegramFeedback): Promise<TelegramFeedback> {
    const feedback: TelegramFeedback = {
      id: this.currentTelegramFeedbackId++,
      createdAt: new Date(),
      ...insertFeedback,
      confidence: insertFeedback.confidence ?? null,
      recommendationId: insertFeedback.recommendationId ?? null,
      userId: insertFeedback.userId ?? null,
      actualResult: insertFeedback.actualResult ?? null,
      responseTime: insertFeedback.responseTime ?? null,
    };
    this.telegramFeedback.set(feedback.id, feedback);
    return feedback;
  }

  async getTelegramFeedbackByRecommendation(recommendationId: number): Promise<TelegramFeedback[]> {
    return Array.from(this.telegramFeedback.values()).filter(
      feedback => feedback.recommendationId === recommendationId
    );
  }

  async getTelegramFeedbackByAsset(assetSymbol: string): Promise<TelegramFeedback[]> {
    return Array.from(this.telegramFeedback.values()).filter(
      feedback => feedback.assetSymbol === assetSymbol
    );
  }

  async getAllTelegramFeedback(limit?: number): Promise<TelegramFeedback[]> {
    const allFeedback = Array.from(this.telegramFeedback.values())
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    return limit ? allFeedback.slice(0, limit) : allFeedback;
  }

  // ML training data operations
  async createMlTrainingData(insertData: InsertMlTrainingData): Promise<MlTrainingData> {
    const data: MlTrainingData = {
      id: this.currentMlTrainingDataId++,
      createdAt: new Date(),
      ...insertData,
      recommendationId: insertData.recommendationId ?? null,
      technicalIndicators: insertData.technicalIndicators ?? null,
      marketConditions: insertData.marketConditions ?? null,
      timingFactors: insertData.timingFactors ?? null,
      learningWeight: insertData.learningWeight ?? 1.0,
    };
    this.mlTrainingData.set(data.id, data);
    return data;
  }

  async getMlTrainingDataByAsset(assetSymbol: string, limit?: number): Promise<MlTrainingData[]> {
    const filtered = Array.from(this.mlTrainingData.values()).filter(
      data => data.assetSymbol === assetSymbol
    );
    return limit ? filtered.slice(0, limit) : filtered;
  }

  async getAllMlTrainingData(limit?: number): Promise<MlTrainingData[]> {
    const all = Array.from(this.mlTrainingData.values());
    return limit ? all.slice(0, limit) : all;
  }

  // Asset performance operations
  async getAssetPerformance(assetSymbol: string): Promise<AssetPerformance | undefined> {
    return this.assetPerformance.get(assetSymbol);
  }

  async createAssetPerformance(insertPerformance: InsertAssetPerformance): Promise<AssetPerformance> {
    const performance: AssetPerformance = {
      id: this.currentAssetPerformanceId++,
      lastUpdated: new Date(),
      ...insertPerformance,
      totalRecommendations: insertPerformance.totalRecommendations ?? 0,
      successfulTrades: insertPerformance.successfulTrades ?? 0,
      partialSuccessTrades: insertPerformance.partialSuccessTrades ?? 0,
      failedTrades: insertPerformance.failedTrades ?? 0,
      averageConfidence: insertPerformance.averageConfidence ?? 0,
      successRate: insertPerformance.successRate ?? 0,
      adjustedSuccessRate: insertPerformance.adjustedSuccessRate ?? 0,
    };
    this.assetPerformance.set(performance.assetSymbol, performance);
    return performance;
  }

  async updateAssetPerformance(assetSymbol: string, updates: Partial<InsertAssetPerformance>): Promise<void> {
    const existing = this.assetPerformance.get(assetSymbol);
    if (existing) {
      const updated: AssetPerformance = {
        ...existing,
        ...updates,
        lastUpdated: new Date(),
      };
      this.assetPerformance.set(assetSymbol, updated);
    }
  }

  async getAllAssetPerformance(): Promise<AssetPerformance[]> {
    return Array.from(this.assetPerformance.values());
  }
}

// Database Storage Implementation
export class DatabaseStorage implements IStorage {
  constructor() {
    if (!db) {
      throw new Error('Database connection not available. Ensure DATABASE_URL is set for production or use MemStorage for development.');
    }
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db!.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  // Market asset operations
  async getAllMarketAssets(): Promise<MarketAsset[]> {
    return await db.select().from(marketAssets);
  }

  async getMarketAsset(symbol: string): Promise<MarketAsset | undefined> {
    const [asset] = await db.select().from(marketAssets).where(eq(marketAssets.symbol, symbol));
    return asset;
  }

  async createMarketAsset(insertAsset: InsertMarketAsset): Promise<MarketAsset> {
    const [asset] = await db.insert(marketAssets).values(insertAsset).returning();
    return asset;
  }

  // Trading recommendation operations
  async getAllTradingRecommendations(): Promise<TradingRecommendation[]> {
    return await db.select().from(tradingRecommendations).orderBy(desc(tradingRecommendations.createdAt));
  }

  async getRecentTradingRecommendations(limit: number): Promise<TradingRecommendation[]> {
    return await db.select().from(tradingRecommendations)
      .orderBy(desc(tradingRecommendations.createdAt))
      .limit(limit);
  }

  async getTradingRecommendation(id: number): Promise<TradingRecommendation | undefined> {
    const [recommendation] = await db.select().from(tradingRecommendations).where(eq(tradingRecommendations.id, id));
    return recommendation;
  }

  async createTradingRecommendation(insertRecommendation: InsertTradingRecommendation): Promise<TradingRecommendation> {
    const [recommendation] = await db.insert(tradingRecommendations).values(insertRecommendation).returning();
    return recommendation;
  }

  async updateTradingRecommendationResult(id: number, result: string): Promise<void> {
    await db.update(tradingRecommendations)
      .set({ result })
      .where(eq(tradingRecommendations.id, id));
  }

  // Market data operations
  async getLatestMarketData(): Promise<MarketData[]> {
    return await db.select().from(marketData).orderBy(desc(marketData.timestamp));
  }

  async getMarketDataBySymbol(symbol: string): Promise<MarketData | undefined> {
    const [data] = await db.select().from(marketData)
      .where(eq(marketData.symbol, symbol))
      .orderBy(desc(marketData.timestamp));
    return data;
  }

  async createMarketData(insertData: InsertMarketData): Promise<MarketData> {
    const [data] = await db.insert(marketData).values(insertData).returning();
    return data;
  }

  // Technical indicators operations
  async getLatestTechnicalIndicators(): Promise<TechnicalIndicators[]> {
    return await db.select().from(technicalIndicators).orderBy(desc(technicalIndicators.timestamp));
  }

  async getTechnicalIndicatorsBySymbol(symbol: string): Promise<TechnicalIndicators | undefined> {
    const [indicators] = await db.select().from(technicalIndicators)
      .where(eq(technicalIndicators.symbol, symbol))
      .orderBy(desc(technicalIndicators.timestamp));
    return indicators;
  }

  async createTechnicalIndicators(insertIndicators: InsertTechnicalIndicators): Promise<TechnicalIndicators> {
    const [indicators] = await db.insert(technicalIndicators).values(insertIndicators).returning();
    return indicators;
  }

  // Telegram stats operations
  async getTelegramStats(): Promise<TelegramStats | undefined> {
    const [stats] = await db.select().from(telegramStats).orderBy(desc(telegramStats.updatedAt));
    return stats;
  }

  async createTelegramStats(insertStats: InsertTelegramStats): Promise<TelegramStats> {
    const [stats] = await db.insert(telegramStats).values(insertStats).returning();
    return stats;
  }

  async updateTelegramStats(updateStats: Partial<InsertTelegramStats>): Promise<void> {
    const [existingStats] = await db.select().from(telegramStats).limit(1);
    
    if (existingStats) {
      await db.update(telegramStats)
        .set({ ...updateStats, updatedAt: new Date() })
        .where(eq(telegramStats.id, existingStats.id));
    } else {
      await db.insert(telegramStats).values(updateStats as InsertTelegramStats);
    }
  }

  // License operations
  async createLicense(insertLicense: InsertLicense): Promise<License> {
    const [license] = await db.insert(licenses).values(insertLicense).returning();
    return license;
  }

  async getLicenseByKey(licenseKey: string): Promise<License | undefined> {
    const [license] = await db.select().from(licenses).where(eq(licenses.licenseKey, licenseKey));
    return license;
  }

  async getLicensesByUser(userId: number): Promise<License[]> {
    return await db.select().from(licenses).where(eq(licenses.userId, userId));
  }

  async updateLicense(id: number, updates: Partial<InsertLicense>): Promise<void> {
    await db.update(licenses)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(licenses.id, id));
  }

  // Trade history operations
  async createTradeHistory(insertTrade: InsertTradeHistory): Promise<TradeHistory> {
    const [trade] = await db.insert(tradeHistory).values(insertTrade).returning();
    return trade;
  }

  async getTradeHistoryByLicense(licenseId: number): Promise<TradeHistory[]> {
    return await db.select().from(tradeHistory)
      .where(eq(tradeHistory.licenseId, licenseId))
      .orderBy(desc(tradeHistory.tradedAt));
  }

  async getTradeHistoryByUser(userId: number): Promise<TradeHistory[]> {
    return await db.select().from(tradeHistory)
      .where(eq(tradeHistory.userId, userId))
      .orderBy(desc(tradeHistory.tradedAt));
  }

  // System settings operations
  async getSystemSettings(): Promise<SystemSettings[]> {
    return await db.select().from(systemSettings);
  }

  async getSystemSetting(key: string): Promise<SystemSettings | undefined> {
    const [setting] = await db.select().from(systemSettings).where(eq(systemSettings.key, key));
    return setting;
  }

  async updateSystemSetting(key: string, value: string, description?: string): Promise<void> {
    await db.insert(systemSettings)
      .values({ key, value, description })
      .onConflictDoUpdate({
        target: systemSettings.key,
        set: { value, updatedAt: new Date() }
      });
  }

  // Telegram feedback operations
  async createTelegramFeedback(insertFeedback: InsertTelegramFeedback): Promise<TelegramFeedback> {
    const [feedback] = await db.insert(telegramFeedback).values(insertFeedback).returning();
    return feedback;
  }

  async getTelegramFeedbackByRecommendation(recommendationId: number): Promise<TelegramFeedback[]> {
    return await db.select().from(telegramFeedback)
      .where(eq(telegramFeedback.recommendationId, recommendationId))
      .orderBy(desc(telegramFeedback.createdAt));
  }

  async getTelegramFeedbackByAsset(assetSymbol: string): Promise<TelegramFeedback[]> {
    return await db.select().from(telegramFeedback)
      .where(eq(telegramFeedback.assetSymbol, assetSymbol))
      .orderBy(desc(telegramFeedback.createdAt));
  }

  async getAllTelegramFeedback(limit?: number): Promise<TelegramFeedback[]> {
    if (limit) {
      return await db.select().from(telegramFeedback)
        .orderBy(desc(telegramFeedback.createdAt))
        .limit(limit);
    }
    
    return await db.select().from(telegramFeedback)
      .orderBy(desc(telegramFeedback.createdAt));
  }

  // ML training data operations
  async createMlTrainingData(insertData: InsertMlTrainingData): Promise<MlTrainingData> {
    const [data] = await db.insert(mlTrainingData).values(insertData).returning();
    return data;
  }

  async getMlTrainingDataByAsset(assetSymbol: string, limit?: number): Promise<MlTrainingData[]> {
    if (limit) {
      return await db.select().from(mlTrainingData)
        .where(eq(mlTrainingData.assetSymbol, assetSymbol))
        .orderBy(desc(mlTrainingData.createdAt))
        .limit(limit);
    }
    
    return await db.select().from(mlTrainingData)
      .where(eq(mlTrainingData.assetSymbol, assetSymbol))
      .orderBy(desc(mlTrainingData.createdAt));
  }

  async getAllMlTrainingData(limit?: number): Promise<MlTrainingData[]> {
    if (limit) {
      return await db.select().from(mlTrainingData)
        .orderBy(desc(mlTrainingData.createdAt))
        .limit(limit);
    }
    
    return await db.select().from(mlTrainingData)
      .orderBy(desc(mlTrainingData.createdAt));
  }

  // Asset performance operations
  async getAssetPerformance(assetSymbol: string): Promise<AssetPerformance | undefined> {
    const [performance] = await db.select().from(assetPerformance)
      .where(eq(assetPerformance.assetSymbol, assetSymbol));
    return performance;
  }

  async createAssetPerformance(insertPerformance: InsertAssetPerformance): Promise<AssetPerformance> {
    const [performance] = await db.insert(assetPerformance).values(insertPerformance).returning();
    return performance;
  }

  async updateAssetPerformance(assetSymbol: string, updates: Partial<InsertAssetPerformance>): Promise<void> {
    await db.update(assetPerformance)
      .set({ ...updates, lastUpdated: new Date() })
      .where(eq(assetPerformance.assetSymbol, assetSymbol));
  }

  async getAllAssetPerformance(): Promise<AssetPerformance[]> {
    return await db.select().from(assetPerformance)
      .orderBy(desc(assetPerformance.successRate));
  }
}

// Use DatabaseStorage in production, MemStorage for development
export const storage = process.env.NODE_ENV === 'development' ? new MemStorage() : new DatabaseStorage();
