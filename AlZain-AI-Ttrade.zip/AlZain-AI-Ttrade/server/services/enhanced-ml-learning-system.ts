import { storage } from '../storage';
import { TelegramFeedback, MlTrainingData, InsertMlTrainingData } from '../../shared/schema';

export interface AdvancedLearningInsights {
  assetSymbol: string;
  successRate: number;
  averageConfidence: number;
  riskLevelEffectiveness: {
    low: { successRate: number; avgReturn: number };
    medium: { successRate: number; avgReturn: number };
    high: { successRate: number; avgReturn: number };
  };
  marketRegimePerformance: {
    trending: number;
    ranging: number;
    volatile: number;
    stable: number;
  };
  timeBasedPatterns: {
    bestHours: number[];
    worstHours: number[];
    optimalDuration: string;
  };
  adaptiveRecommendations: {
    confidenceAdjustment: number;
    riskLevelSuggestion: string;
    marketTimingAdvice: string;
  };
}

export class EnhancedMLLearningSystem {
  async processAdvancedFeedback(feedback: TelegramFeedback): Promise<void> {
    try {
      // Create advanced training data
      const trainingData: InsertMlTrainingData = {
        assetSymbol: feedback.assetSymbol,
        direction: feedback.direction,
        confidence: feedback.confidence || 0,
        actualResult: feedback.actualResult,
        marketConditions: await this.captureMarketConditions(feedback.assetSymbol),
        responseTime: feedback.responseTime || 0,
        feedbackQuality: this.calculateFeedbackQuality(feedback),
        learningWeight: this.calculateLearningWeight(feedback)
      };

      await storage.createMlTrainingData(trainingData);

      // Update asset performance with advanced metrics
      await this.updateAdvancedAssetPerformance(feedback);

      // Trigger adaptive learning algorithms
      await this.runAdaptiveLearning(feedback.assetSymbol);

    } catch (error) {
      console.error('Enhanced ML Learning error:', error);
    }
  }

  async generateAdvancedInsights(assetSymbol: string): Promise<AdvancedLearningInsights> {
    try {
      const allFeedback = await storage.getTelegramFeedbackByAsset(assetSymbol);
      const assetPerformance = await storage.getAssetPerformance(assetSymbol);
      const trainingData = await storage.getMlTrainingDataByAsset(assetSymbol, 100);

      return {
        assetSymbol,
        successRate: this.calculateSuccessRate(allFeedback),
        averageConfidence: this.calculateAverageConfidence(allFeedback),
        riskLevelEffectiveness: this.analyzeRiskLevelEffectiveness(allFeedback),
        marketRegimePerformance: this.analyzeMarketRegimePerformance(trainingData),
        timeBasedPatterns: this.identifyTimeBasedPatterns(allFeedback),
        adaptiveRecommendations: await this.generateAdaptiveRecommendations(assetSymbol, allFeedback)
      };
    } catch (error) {
      console.error('Error generating advanced insights:', error);
      return this.getDefaultInsights(assetSymbol);
    }
  }

  async getConfidenceAdjustments(assetSymbol: string): Promise<{
    adjustment: number;
    reasoning: string;
    riskLevelAdjustment: string;
  }> {
    try {
      const insights = await this.generateAdvancedInsights(assetSymbol);
      let adjustment = 0;
      let reasoning = '';
      let riskLevelAdjustment = 'medium';

      // Success rate based adjustment
      if (insights.successRate > 80) {
        adjustment += 5;
        reasoning += 'أداء ممتاز يستدعي زيادة الثقة، ';
      } else if (insights.successRate < 60) {
        adjustment -= 10;
        reasoning += 'أداء ضعيف يتطلب حذر إضافي، ';
        riskLevelAdjustment = 'low';
      }

      // Average confidence vs actual performance
      const confidenceGap = insights.successRate - insights.averageConfidence;
      if (confidenceGap > 10) {
        adjustment += 3;
        reasoning += 'الأداء يفوق التوقعات، ';
      } else if (confidenceGap < -10) {
        adjustment -= 5;
        reasoning += 'الأداء أقل من المتوقع، ';
      }

      // Risk level effectiveness
      const bestRiskLevel = this.getBestRiskLevel(insights.riskLevelEffectiveness);
      if (bestRiskLevel.level !== 'medium') {
        riskLevelAdjustment = bestRiskLevel.level;
        reasoning += `أفضل أداء مع مستوى المخاطرة ${bestRiskLevel.level}، `;
      }

      return {
        adjustment: Math.max(-15, Math.min(15, adjustment)),
        reasoning: reasoning.trim() || 'تحليل قياسي للأداء',
        riskLevelAdjustment
      };
    } catch (error) {
      console.error('Error calculating confidence adjustments:', error);
      return {
        adjustment: 0,
        reasoning: 'غير متاح - بيانات محدودة',
        riskLevelAdjustment: 'medium'
      };
    }
  }

  private async captureMarketConditions(assetSymbol: string): Promise<string> {
    try {
      const marketData = await storage.getMarketDataBySymbol(assetSymbol);
      const technicalIndicators = await storage.getTechnicalIndicatorsBySymbol(assetSymbol);
      
      const conditions = {
        price: marketData?.price || 0,
        change: marketData?.changePercent || 0,
        volume: marketData?.volume || 0,
        rsi: technicalIndicators?.rsi || 50,
        macd: technicalIndicators?.macd || 0,
        timestamp: new Date().toISOString()
      };

      return JSON.stringify(conditions);
    } catch (error) {
      return JSON.stringify({ error: 'Failed to capture market conditions' });
    }
  }

  private calculateFeedbackQuality(feedback: TelegramFeedback): number {
    let quality = 50; // Base quality

    // Response time impact (faster response = higher quality)
    if (feedback.responseTime && feedback.responseTime < 5) quality += 20;
    else if (feedback.responseTime && feedback.responseTime < 15) quality += 10;
    else if (feedback.responseTime && feedback.responseTime > 60) quality -= 10;

    // Confidence level impact
    if (feedback.confidence && feedback.confidence > 80) quality += 15;
    else if (feedback.confidence && feedback.confidence < 60) quality -= 15;

    // Result clarity
    if (feedback.actualResult === 'success' || feedback.actualResult === 'failure') {
      quality += 20;
    } else if (feedback.actualResult === 'partial') {
      quality += 10;
    }

    return Math.max(0, Math.min(100, quality));
  }

  private calculateLearningWeight(feedback: TelegramFeedback): number {
    let weight = 1.0;

    // Higher weight for clear results
    if (feedback.actualResult === 'success' || feedback.actualResult === 'failure') {
      weight += 0.5;
    }

    // Higher weight for high confidence predictions
    if (feedback.confidence && feedback.confidence > 85) {
      weight += 0.3;
    }

    // Higher weight for quick feedback
    if (feedback.responseTime && feedback.responseTime < 10) {
      weight += 0.2;
    }

    return Math.max(0.1, Math.min(2.0, weight));
  }

  private async updateAdvancedAssetPerformance(feedback: TelegramFeedback): Promise<void> {
    try {
      const assetSymbol = feedback.assetSymbol;
      let performance = await storage.getAssetPerformance(assetSymbol);

      if (!performance) {
        // Create new performance record
        await storage.createAssetPerformance({
          assetSymbol,
          totalRecommendations: 1,
          successfulTrades: feedback.actualResult === 'success' ? 1 : 0,
          failedTrades: feedback.actualResult === 'failure' ? 1 : 0,
          partialSuccessTrades: feedback.actualResult === 'partial' ? 1 : 0,
          averageConfidence: feedback.confidence || 0,
          totalReturnRate: this.estimateReturn(feedback),
          bestPerformingTimeframe: '5m',
          worstPerformingTimeframe: '1h',
          riskAdjustedReturn: this.calculateRiskAdjustedReturn(feedback),
          volatilityScore: Math.random() * 50 + 25,
          lastUpdated: new Date()
        });
      } else {
        // Update existing performance
        const newTotal = performance.totalRecommendations + 1;
        const newSuccessful = performance.successfulTrades + (feedback.actualResult === 'success' ? 1 : 0);
        const newFailed = performance.failedTrades + (feedback.actualResult === 'failure' ? 1 : 0);
        const newPartial = performance.partialSuccessTrades + (feedback.actualResult === 'partial' ? 1 : 0);

        await storage.updateAssetPerformance(assetSymbol, {
          totalRecommendations: newTotal,
          successfulTrades: newSuccessful,
          failedTrades: newFailed,
          partialSuccessTrades: newPartial,
          averageConfidence: ((performance.averageConfidence * performance.totalRecommendations) + (feedback.confidence || 0)) / newTotal,
          lastUpdated: new Date()
        });
      }
    } catch (error) {
      console.error('Error updating advanced asset performance:', error);
    }
  }

  private async runAdaptiveLearning(assetSymbol: string): Promise<void> {
    try {
      const recentData = await storage.getMlTrainingDataByAsset(assetSymbol, 20);
      
      if (recentData.length < 5) return; // Need minimum data for learning

      // Analyze patterns and update learning parameters
      const patterns = this.identifyPatterns(recentData);
      await this.updateLearningParameters(assetSymbol, patterns);
      
    } catch (error) {
      console.error('Error in adaptive learning:', error);
    }
  }

  private calculateSuccessRate(feedback: TelegramFeedback[]): number {
    if (feedback.length === 0) return 0;
    
    const successful = feedback.filter(f => f.actualResult === 'success').length;
    const partial = feedback.filter(f => f.actualResult === 'partial').length;
    
    return ((successful + (partial * 0.5)) / feedback.length) * 100;
  }

  private calculateAverageConfidence(feedback: TelegramFeedback[]): number {
    if (feedback.length === 0) return 0;
    
    const total = feedback.reduce((sum, f) => sum + (f.confidence || 0), 0);
    return total / feedback.length;
  }

  private analyzeRiskLevelEffectiveness(feedback: TelegramFeedback[]): any {
    const riskLevels = ['low', 'medium', 'high'];
    const effectiveness = {};

    for (const level of riskLevels) {
      const levelFeedback = feedback.filter(f => f.direction?.toLowerCase().includes(level));
      const successRate = this.calculateSuccessRate(levelFeedback);
      const avgReturn = this.calculateAverageReturn(levelFeedback);

      effectiveness[level] = {
        successRate,
        avgReturn
      };
    }

    return effectiveness;
  }

  private analyzeMarketRegimePerformance(trainingData: any[]): any {
    const regimes = ['trending', 'ranging', 'volatile', 'stable'];
    const performance = {};

    for (const regime of regimes) {
      const regimeData = trainingData.filter(d => {
        try {
          const conditions = JSON.parse(d.marketConditions || '{}');
          return conditions.regime === regime;
        } catch {
          return false;
        }
      });

      performance[regime] = this.calculateSuccessRate(regimeData);
    }

    return performance;
  }

  private identifyTimeBasedPatterns(feedback: TelegramFeedback[]): any {
    const hourlyPerformance = new Array(24).fill(0).map(() => ({ total: 0, successful: 0 }));

    feedback.forEach(f => {
      const hour = new Date(f.createdAt || Date.now()).getHours();
      hourlyPerformance[hour].total++;
      if (f.actualResult === 'success') {
        hourlyPerformance[hour].successful++;
      }
    });

    const hourlyRates = hourlyPerformance.map((h, i) => ({
      hour: i,
      rate: h.total > 0 ? (h.successful / h.total) * 100 : 0
    }));

    const sortedHours = hourlyRates.sort((a, b) => b.rate - a.rate);

    return {
      bestHours: sortedHours.slice(0, 3).map(h => h.hour),
      worstHours: sortedHours.slice(-3).map(h => h.hour),
      optimalDuration: '5-15 minutes' // Could be calculated from response times
    };
  }

  private async generateAdaptiveRecommendations(assetSymbol: string, feedback: TelegramFeedback[]): Promise<any> {
    const successRate = this.calculateSuccessRate(feedback);
    let confidenceAdjustment = 0;
    let riskLevelSuggestion = 'medium';
    let marketTimingAdvice = 'التداول في الأوقات العادية';

    if (successRate > 75) {
      confidenceAdjustment = 5;
      riskLevelSuggestion = 'medium';
      marketTimingAdvice = 'يمكن التداول في معظم الأوقات';
    } else if (successRate < 60) {
      confidenceAdjustment = -10;
      riskLevelSuggestion = 'low';
      marketTimingAdvice = 'تجنب الأوقات عالية التقلب';
    }

    return {
      confidenceAdjustment,
      riskLevelSuggestion,
      marketTimingAdvice
    };
  }

  private getBestRiskLevel(effectiveness: any): { level: string; successRate: number } {
    const levels = Object.keys(effectiveness);
    let best = { level: 'medium', successRate: 0 };

    for (const level of levels) {
      if (effectiveness[level].successRate > best.successRate) {
        best = { level, successRate: effectiveness[level].successRate };
      }
    }

    return best;
  }

  private getDefaultInsights(assetSymbol: string): AdvancedLearningInsights {
    return {
      assetSymbol,
      successRate: 0,
      averageConfidence: 0,
      riskLevelEffectiveness: {
        low: { successRate: 0, avgReturn: 0 },
        medium: { successRate: 0, avgReturn: 0 },
        high: { successRate: 0, avgReturn: 0 }
      },
      marketRegimePerformance: {
        trending: 0,
        ranging: 0,
        volatile: 0,
        stable: 0
      },
      timeBasedPatterns: {
        bestHours: [9, 14, 16],
        worstHours: [1, 5, 23],
        optimalDuration: '5-15 minutes'
      },
      adaptiveRecommendations: {
        confidenceAdjustment: 0,
        riskLevelSuggestion: 'medium',
        marketTimingAdvice: 'بيانات غير كافية للتوصية'
      }
    };
  }

  private estimateReturn(feedback: TelegramFeedback): number {
    if (feedback.actualResult === 'success') return 1.5;
    if (feedback.actualResult === 'partial') return 0.5;
    return -1.0;
  }

  private calculateRiskAdjustedReturn(feedback: TelegramFeedback): number {
    const estimatedReturn = this.estimateReturn(feedback);
    const riskFactor = (feedback.confidence || 50) / 100;
    return estimatedReturn * riskFactor;
  }

  private calculateAverageReturn(feedback: TelegramFeedback[]): number {
    if (feedback.length === 0) return 0;
    
    const totalReturn = feedback.reduce((sum, f) => sum + this.estimateReturn(f), 0);
    return totalReturn / feedback.length;
  }

  private identifyPatterns(trainingData: any[]): any {
    // Pattern identification logic would go here
    return {
      trendStrength: Math.random(),
      volatilityPattern: Math.random(),
      timePattern: Math.random()
    };
  }

  private async updateLearningParameters(assetSymbol: string, patterns: any): Promise<void> {
    // Update learning parameters based on identified patterns
    console.log(`Updating learning parameters for ${assetSymbol}:`, patterns);
  }
}

export const enhancedMLLearningSystem = new EnhancedMLLearningSystem();