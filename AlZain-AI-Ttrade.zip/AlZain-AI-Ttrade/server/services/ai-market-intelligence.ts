import { ProfessionalTechnicalAnalysisService } from './professional-technical-analysis.js';
import axios from 'axios';

interface MarketDataProvider {
  symbol: string;
  price: number;
  change: number;
  changePercent: number;
  volume: number;
  high24h: number;
  low24h: number;
  timestamp: number;
}

interface CryptoMarketData extends MarketDataProvider {
  marketCap: number;
  circulatingSupply: number;
  totalSupply: number;
  fear_greed_index: number;
}

interface ForexMarketData extends MarketDataProvider {
  spread: number;
  pivot_points: {
    pivot: number;
    r1: number;
    r2: number;
    r3: number;
    s1: number;
    s2: number;
    s3: number;
  };
  central_bank_rates: {
    base_currency_rate: number;
    quote_currency_rate: number;
  };
}

interface AIModelPrediction {
  signal: 'BUY' | 'SELL' | 'HOLD';
  confidence: number;
  probability_distribution: {
    buy_probability: number;
    sell_probability: number;
    hold_probability: number;
  };
  price_targets: {
    target_1h: number;
    target_4h: number;
    target_1d: number;
  };
  risk_metrics: {
    value_at_risk: number;
    expected_shortfall: number;
    maximum_drawdown: number;
  };
  feature_importance: {
    [key: string]: number;
  };
}

export class AIMarketIntelligenceService {
  private professionalTA: ProfessionalTechnicalAnalysisService;
  private modelWeights: Map<string, number>;
  private historicalAccuracy: Map<string, number>;
  
  constructor() {
    this.professionalTA = new ProfessionalTechnicalAnalysisService();
    this.modelWeights = new Map([
      ['technical_analysis', 0.35],
      ['pattern_recognition', 0.25],
      ['sentiment_analysis', 0.15],
      ['volume_profile', 0.15],
      ['market_structure', 0.10]
    ]);
    this.historicalAccuracy = new Map();
  }

  // خدمة الذكاء الصناعي المتطورة لتحليل السوق
  async generateAdvancedAISignal(symbol: string): Promise<{
    signal: 'BUY' | 'SELL' | 'HOLD';
    confidence: number;
    strength: 'قوية جداً' | 'قوية' | 'متوسطة' | 'ضعيفة';
    riskLevel: 'LOW' | 'MEDIUM' | 'HIGH';
    reasoning: string[];
    aiAnalysis: {
      modelConsensus: number;
      predictionAccuracy: number;
      marketRegime: 'trending' | 'ranging' | 'volatile' | 'reversal';
      optimalTimeframes: string[];
      riskRewardRatio: number;
      entryStrategy: string;
      exitStrategy: string;
      positionSizing: number;
    };
    technicalLevels: {
      entryPrice: number;
      stopLoss: number;
      takeProfit1: number;
      takeProfit2: number;
      dynamicSupport: number;
      dynamicResistance: number;
    };
    marketContext: {
      correlationAnalysis: any;
      intermarketSignals: any;
      institutionalFlow: 'accumulation' | 'distribution' | 'neutral';
      smartMoneyIndicators: any;
    };
  }> {
    
    try {
      // جمع البيانات من مصادر متعددة
      const marketData = await this.collectMultiSourceData(symbol);
      
      // تطبيق نماذج الذكاء الصناعي المتعددة
      const aiPredictions = await this.runEnsembleModels(marketData);
      
      // تحليل البيانات المتعمق
      const deepAnalysis = await this.performDeepMarketAnalysis(marketData, aiPredictions);
      
      // تحليل الارتباطات والأسواق المتداخلة
      const correlationAnalysis = await this.analyzeMarketCorrelations(symbol, marketData);
      
      // كشف تدفق رؤوس الأموال الذكية
      const smartMoneyFlow = await this.detectSmartMoneyFlow(marketData);
      
      // تحديد نظام السوق الحالي
      const marketRegime = this.identifyMarketRegime(marketData);
      
      // حساب الإشارة النهائية
      const finalSignal = await this.computeFinalAISignal(
        deepAnalysis,
        aiPredictions,
        correlationAnalysis,
        smartMoneyFlow,
        marketRegime
      );
      
      return finalSignal;
      
    } catch (error) {
      console.error('AI Market Intelligence error:', error);
      
      // العودة لنظام احتياطي بتحليل محسن
      return this.getFallbackEnhancedSignal(symbol);
    }
  }
  
  private async collectMultiSourceData(symbol: string): Promise<any> {
    const data: any = {
      symbol,
      timeframes: {},
      marketType: this.determineMarketType(symbol),
      economicCalendar: await this.getEconomicEvents(symbol),
      marketSession: this.getCurrentMarketSession(),
      volatilityRegime: 'normal'
    };
    
    // محاكاة جمع البيانات من أطر زمنية متعددة
    const timeframes = ['1m', '5m', '15m', '1h', '4h', '1d'];
    
    for (const tf of timeframes) {
      data.timeframes[tf] = await this.generateRealisticTimeframeData(symbol, tf);
    }
    
    return data;
  }
  
  private async generateRealisticTimeframeData(symbol: string, timeframe: string): Promise<any> {
    const basePrice = 100 + Math.random() * 50; // سعر أساسي واقعي
    const points = this.getTimeframePoints(timeframe);
    
    const data = {
      prices: [],
      highs: [],
      lows: [],
      volumes: [],
      opens: [],
      timestamp: []
    };
    
    let currentPrice = basePrice;
    const volatility = this.getTimeframeVolatility(timeframe);
    
    for (let i = 0; i < points; i++) {
      // محاكاة حركة السعر الواقعية
      const priceChange = (Math.random() - 0.5) * volatility * currentPrice;
      currentPrice += priceChange;
      
      const high = currentPrice + Math.random() * volatility * currentPrice * 0.5;
      const low = currentPrice - Math.random() * volatility * currentPrice * 0.5;
      const open = currentPrice + (Math.random() - 0.5) * volatility * currentPrice * 0.2;
      const volume = Math.random() * 1000000 + 100000;
      
      data.prices.push(currentPrice);
      data.highs.push(high);
      data.lows.push(low);
      data.opens.push(open);
      data.volumes.push(volume);
      data.timestamp.push(Date.now() - (points - i) * this.getTimeframeMilliseconds(timeframe));
    }
    
    return data;
  }
  
  private getTimeframePoints(timeframe: string): number {
    const points = {
      '1m': 200,
      '5m': 150,
      '15m': 100,
      '1h': 100,
      '4h': 60,
      '1d': 50
    };
    return points[timeframe] || 100;
  }
  
  private getTimeframeVolatility(timeframe: string): number {
    const volatilities = {
      '1m': 0.001,
      '5m': 0.002,
      '15m': 0.003,
      '1h': 0.005,
      '4h': 0.008,
      '1d': 0.015
    };
    return volatilities[timeframe] || 0.005;
  }
  
  private getTimeframeMilliseconds(timeframe: string): number {
    const ms = {
      '1m': 60000,
      '5m': 300000,
      '15m': 900000,
      '1h': 3600000,
      '4h': 14400000,
      '1d': 86400000
    };
    return ms[timeframe] || 3600000;
  }
  
  private async runEnsembleModels(marketData: any): Promise<AIModelPrediction[]> {
    const models = [
      'gradient_boosting_regressor',
      'lstm_neural_network',
      'random_forest_classifier',
      'support_vector_machine',
      'transformer_attention_model'
    ];
    
    const predictions: AIModelPrediction[] = [];
    
    for (const model of models) {
      const prediction = await this.runSingleModel(model, marketData);
      predictions.push(prediction);
    }
    
    return predictions;
  }
  
  private async runSingleModel(modelName: string, marketData: any): Promise<AIModelPrediction> {
    // محاكاة تشغيل نماذج الذكاء الصناعي المختلفة
    const baseAccuracy = this.getModelBaseAccuracy(modelName);
    const marketComplexity = this.assessMarketComplexity(marketData);
    
    const adjustedAccuracy = baseAccuracy * (1 - marketComplexity * 0.2);
    
    // توليد توقعات واقعية بناءً على نوع النموذج
    const prediction = this.generateModelPrediction(modelName, marketData, adjustedAccuracy);
    
    return prediction;
  }
  
  private getModelBaseAccuracy(modelName: string): number {
    const accuracies = {
      'gradient_boosting_regressor': 0.82,
      'lstm_neural_network': 0.78,
      'random_forest_classifier': 0.85,
      'support_vector_machine': 0.79,
      'transformer_attention_model': 0.88
    };
    return accuracies[modelName] || 0.75;
  }
  
  private assessMarketComplexity(marketData: any): number {
    // تقييم تعقيد السوق بناءً على التقلبات والأحداث
    let complexity = 0.3; // أساسي
    
    if (marketData.economicCalendar?.length > 0) complexity += 0.2;
    if (marketData.marketSession === 'overlap') complexity += 0.1;
    
    return Math.min(0.8, complexity);
  }
  
  private generateModelPrediction(modelName: string, marketData: any, accuracy: number): AIModelPrediction {
    const signals = ['BUY', 'SELL', 'HOLD'];
    const signal = signals[Math.floor(Math.random() * signals.length)] as 'BUY' | 'SELL' | 'HOLD';
    
    const confidence = 60 + Math.random() * 35; // 60-95%
    
    const buyProb = signal === 'BUY' ? 0.4 + Math.random() * 0.5 : Math.random() * 0.3;
    const sellProb = signal === 'SELL' ? 0.4 + Math.random() * 0.5 : Math.random() * 0.3;
    const holdProb = 1 - buyProb - sellProb;
    
    const currentPrice = marketData.timeframes['1h']?.prices?.slice(-1)[0] || 100;
    
    return {
      signal,
      confidence,
      probability_distribution: {
        buy_probability: buyProb,
        sell_probability: sellProb,
        hold_probability: Math.max(0, holdProb)
      },
      price_targets: {
        target_1h: currentPrice * (1 + (Math.random() - 0.5) * 0.02),
        target_4h: currentPrice * (1 + (Math.random() - 0.5) * 0.05),
        target_1d: currentPrice * (1 + (Math.random() - 0.5) * 0.1)
      },
      risk_metrics: {
        value_at_risk: currentPrice * 0.02,
        expected_shortfall: currentPrice * 0.03,
        maximum_drawdown: 0.05
      },
      feature_importance: {
        'price_momentum': Math.random() * 0.3,
        'volume_profile': Math.random() * 0.25,
        'technical_indicators': Math.random() * 0.2,
        'market_sentiment': Math.random() * 0.15,
        'correlation_signals': Math.random() * 0.1
      }
    };
  }
  
  private async performDeepMarketAnalysis(marketData: any, predictions: AIModelPrediction[]): Promise<any> {
    const analysis = {
      patternRecognition: await this.identifyChartPatterns(marketData),
      volumeProfile: this.analyzeVolumeProfile(marketData),
      orderFlow: this.analyzeOrderFlow(marketData),
      marketMicrostructure: this.analyzeMicrostructure(marketData),
      behavioralSignals: this.identifyBehavioralSignals(marketData)
    };
    
    return analysis;
  }
  
  private async identifyChartPatterns(marketData: any): Promise<any> {
    const patterns = [];
    
    // محاكاة كشف الأنماط الفنية
    const patternTypes = [
      'head_and_shoulders',
      'double_top',
      'double_bottom',
      'triangle_ascending',
      'triangle_descending',
      'flag_pattern',
      'pennant',
      'wedge_rising',
      'wedge_falling'
    ];
    
    const detectedPatterns = patternTypes.filter(() => Math.random() > 0.8);
    
    for (const pattern of detectedPatterns) {
      patterns.push({
        type: pattern,
        confidence: 70 + Math.random() * 25,
        timeframe: ['1h', '4h', '1d'][Math.floor(Math.random() * 3)],
        completion: Math.random() * 100
      });
    }
    
    return patterns;
  }
  
  private analyzeVolumeProfile(marketData: any): any {
    const volumes = marketData.timeframes['1h']?.volumes || [];
    const prices = marketData.timeframes['1h']?.prices || [];
    
    if (volumes.length === 0) return { strength: 'متوسط', trend: 'محايد' };
    
    const avgVolume = volumes.reduce((a, b) => a + b, 0) / volumes.length;
    const recentVolume = volumes.slice(-5).reduce((a, b) => a + b, 0) / 5;
    
    const volumeStrength = recentVolume > avgVolume * 1.5 ? 'قوي' : 
                          recentVolume > avgVolume * 1.2 ? 'متوسط' : 'ضعيف';
    
    return {
      strength: volumeStrength,
      trend: this.getVolumeTrend(volumes),
      pocPrice: this.calculatePOC(prices, volumes),
      volumeNodes: this.identifyVolumeNodes(prices, volumes)
    };
  }
  
  private analyzeOrderFlow(marketData: any): any {
    // محاكاة تحليل تدفق الأوامر
    return {
      buyPressure: Math.random() * 100,
      sellPressure: Math.random() * 100,
      netFlow: (Math.random() - 0.5) * 200,
      largeOrderActivity: Math.random() > 0.7,
      marketMakerActivity: Math.random() > 0.6
    };
  }
  
  private analyzeMicrostructure(marketData: any): any {
    return {
      bidAskSpread: Math.random() * 0.001,
      marketDepth: Math.random() * 1000000,
      orderBookImbalance: (Math.random() - 0.5) * 2,
      tickDirection: Math.random() > 0.5 ? 'up' : 'down'
    };
  }
  
  private identifyBehavioralSignals(marketData: any): any {
    return {
      fearGreedIndex: Math.random() * 100,
      retailSentiment: Math.random() > 0.5 ? 'bullish' : 'bearish',
      institutionalPosition: Math.random() > 0.5 ? 'long' : 'short',
      contrarian_signals: Math.random() > 0.8
    };
  }
  
  private async analyzeMarketCorrelations(symbol: string, marketData: any): Promise<any> {
    // تحليل الارتباطات مع الأسواق الأخرى
    return {
      forexCorrelations: this.getForexCorrelations(symbol),
      commodityCorrelations: this.getCommodityCorrelations(symbol),
      indexCorrelations: this.getIndexCorrelations(symbol),
      cryptoCorrelations: this.getCryptoCorrelations(symbol)
    };
  }
  
  private async detectSmartMoneyFlow(marketData: any): Promise<any> {
    return {
      institutionalFlow: Math.random() > 0.5 ? 'accumulation' : 'distribution',
      darkPoolActivity: Math.random() * 100,
      whaleMovements: Math.random() > 0.8,
      unusualOptionsActivity: Math.random() > 0.7
    };
  }
  
  private identifyMarketRegime(marketData: any): 'trending' | 'ranging' | 'volatile' | 'reversal' {
    const regimes = ['trending', 'ranging', 'volatile', 'reversal'];
    return regimes[Math.floor(Math.random() * regimes.length)] as any;
  }
  
  private async computeFinalAISignal(
    deepAnalysis: any,
    aiPredictions: AIModelPrediction[],
    correlationAnalysis: any,
    smartMoneyFlow: any,
    marketRegime: string
  ): Promise<any> {
    
    // حساب الإجماع بين النماذج
    const modelConsensus = this.calculateModelConsensus(aiPredictions);
    
    // حساب متوسط الثقة المرجح
    const weightedConfidence = this.calculateWeightedConfidence(aiPredictions);
    
    // تحديد الإشارة النهائية
    const finalSignal = this.determineFinalSignal(aiPredictions, modelConsensus);
    
    // حساب قوة الإشارة
    const strength = this.calculateSignalStrength(weightedConfidence, modelConsensus);
    
    // تحديد مستوى المخاطر
    const riskLevel = this.assessRiskLevel(marketRegime, weightedConfidence, deepAnalysis);
    
    // إنتاج الاستدلال المتقدم
    const reasoning = this.generateAdvancedReasoning(
      aiPredictions, deepAnalysis, correlationAnalysis, smartMoneyFlow, marketRegime
    );
    
    // حساب المستويات الفنية
    const technicalLevels = this.calculateAdvancedTechnicalLevels(deepAnalysis, finalSignal);
    
    return {
      signal: finalSignal,
      confidence: Math.round(weightedConfidence),
      strength,
      riskLevel,
      reasoning,
      aiAnalysis: {
        modelConsensus: Math.round(modelConsensus),
        predictionAccuracy: this.estimatePredictionAccuracy(aiPredictions),
        marketRegime,
        optimalTimeframes: this.identifyOptimalTimeframes(aiPredictions),
        riskRewardRatio: this.calculateRiskRewardRatio(technicalLevels),
        entryStrategy: this.generateEntryStrategy(finalSignal, marketRegime),
        exitStrategy: this.generateExitStrategy(finalSignal, marketRegime),
        positionSizing: this.calculateOptimalPositionSize(riskLevel, weightedConfidence)
      },
      technicalLevels,
      marketContext: {
        correlationAnalysis,
        intermarketSignals: this.generateIntermarketSignals(correlationAnalysis),
        institutionalFlow: smartMoneyFlow.institutionalFlow,
        smartMoneyIndicators: smartMoneyFlow
      }
    };
  }
  
  private calculateModelConsensus(predictions: AIModelPrediction[]): number {
    if (predictions.length === 0) return 0;
    
    const signals = predictions.map(p => p.signal);
    const mostCommon = this.getMostCommonSignal(signals);
    const count = signals.filter(s => s === mostCommon).length;
    
    return (count / signals.length) * 100;
  }
  
  private calculateWeightedConfidence(predictions: AIModelPrediction[]): number {
    if (predictions.length === 0) return 50;
    
    const totalWeight = predictions.reduce((sum, pred, idx) => {
      const modelWeight = Array.from(this.modelWeights.values())[idx] || 0.2;
      return sum + modelWeight;
    }, 0);
    
    const weightedSum = predictions.reduce((sum, pred, idx) => {
      const modelWeight = Array.from(this.modelWeights.values())[idx] || 0.2;
      return sum + (pred.confidence * modelWeight);
    }, 0);
    
    return weightedSum / totalWeight;
  }
  
  private determineFinalSignal(predictions: AIModelPrediction[], consensus: number): 'BUY' | 'SELL' | 'HOLD' {
    if (consensus < 60) return 'HOLD';
    
    const signals = predictions.map(p => p.signal);
    return this.getMostCommonSignal(signals);
  }
  
  private getMostCommonSignal(signals: string[]): 'BUY' | 'SELL' | 'HOLD' {
    const counts = signals.reduce((acc: any, signal) => {
      acc[signal] = (acc[signal] || 0) + 1;
      return acc;
    }, {});
    
    const maxCount = Math.max(...Object.values(counts) as number[]);
    const mostCommon = Object.keys(counts).find(key => counts[key] === maxCount);
    
    return (mostCommon as 'BUY' | 'SELL' | 'HOLD') || 'HOLD';
  }
  
  private calculateSignalStrength(confidence: number, consensus: number): 'قوية جداً' | 'قوية' | 'متوسطة' | 'ضعيفة' {
    const combinedScore = (confidence + consensus) / 2;
    
    if (combinedScore >= 90) return 'قوية جداً';
    if (combinedScore >= 80) return 'قوية';
    if (combinedScore >= 70) return 'متوسطة';
    return 'ضعيفة';
  }
  
  private assessRiskLevel(marketRegime: string, confidence: number, analysis: any): 'LOW' | 'MEDIUM' | 'HIGH' {
    let riskScore = 0;
    
    if (marketRegime === 'volatile') riskScore += 30;
    else if (marketRegime === 'reversal') riskScore += 20;
    else if (marketRegime === 'ranging') riskScore += 10;
    
    if (confidence < 70) riskScore += 20;
    else if (confidence < 80) riskScore += 10;
    
    if (analysis.volumeProfile?.strength === 'ضعيف') riskScore += 15;
    
    if (riskScore >= 40) return 'HIGH';
    if (riskScore >= 20) return 'MEDIUM';
    return 'LOW';
  }
  
  private generateAdvancedReasoning(
    predictions: any[], 
    analysis: any, 
    correlations: any, 
    smartMoney: any, 
    regime: string
  ): string[] {
    const reasoning = [];
    
    reasoning.push(`نظام السوق الحالي: ${regime} مع إجماع النماذج ${this.calculateModelConsensus(predictions).toFixed(1)}%`);
    
    if (analysis.patternRecognition?.length > 0) {
      reasoning.push(`كشف نماذج فنية: ${analysis.patternRecognition[0].type}`);
    }
    
    reasoning.push(`تحليل الحجم: ${analysis.volumeProfile?.strength || 'متوسط'} مع اتجاه ${analysis.volumeProfile?.trend || 'محايد'}`);
    
    if (smartMoney.institutionalFlow !== 'neutral') {
      reasoning.push(`التدفق المؤسسي: ${smartMoney.institutionalFlow}`);
    }
    
    if (smartMoney.whaleMovements) {
      reasoning.push('نشاط حركات الحيتان الكبيرة مكتشف');
    }
    
    reasoning.push(`تحليل السيولة: عمق السوق ${analysis.marketMicrostructure?.marketDepth > 500000 ? 'عالي' : 'متوسط'}`);
    
    return reasoning;
  }
  
  private calculateAdvancedTechnicalLevels(analysis: any, signal: 'BUY' | 'SELL' | 'HOLD'): any {
    const basePrice = 100; // سيتم استبدالها بالسعر الحقيقي
    const volatility = 0.02;
    
    const entryPrice = basePrice;
    const stopLoss = signal === 'BUY' ? 
      basePrice * (1 - volatility * 2) : 
      basePrice * (1 + volatility * 2);
    const takeProfit1 = signal === 'BUY' ? 
      basePrice * (1 + volatility * 1.5) : 
      basePrice * (1 - volatility * 1.5);
    const takeProfit2 = signal === 'BUY' ? 
      basePrice * (1 + volatility * 3) : 
      basePrice * (1 - volatility * 3);
    
    return {
      entryPrice,
      stopLoss,
      takeProfit1,
      takeProfit2,
      dynamicSupport: basePrice * (1 - volatility),
      dynamicResistance: basePrice * (1 + volatility)
    };
  }
  
  // الطرق المساعدة
  private determineMarketType(symbol: string): string {
    if (symbol.includes('USD') || symbol.includes('EUR') || symbol.includes('GBP')) return 'forex';
    if (['BTC', 'ETH', 'ADA', 'DOT'].includes(symbol)) return 'crypto';
    if (['GOLD', 'SILVER', 'OIL'].includes(symbol)) return 'commodity';
    return 'forex';
  }
  
  private async getEconomicEvents(symbol: string): Promise<any[]> {
    // محاكاة الأحداث الاقتصادية
    return Math.random() > 0.7 ? [{ type: 'high_impact', time: new Date() }] : [];
  }
  
  private getCurrentMarketSession(): 'asian' | 'london' | 'newyork' | 'overlap' | 'closed' {
    const sessions = ['asian', 'london', 'newyork', 'overlap'];
    return sessions[Math.floor(Math.random() * sessions.length)] as any;
  }
  
  private getVolumeTrend(volumes: number[]): string {
    if (volumes.length < 10) return 'محايد';
    
    const recent = volumes.slice(-5).reduce((a, b) => a + b, 0) / 5;
    const previous = volumes.slice(-10, -5).reduce((a, b) => a + b, 0) / 5;
    
    if (recent > previous * 1.1) return 'متزايد';
    if (recent < previous * 0.9) return 'متناقص';
    return 'مستقر';
  }
  
  private calculatePOC(prices: number[], volumes: number[]): number {
    // حساب نقطة التحكم في الحجم
    return prices[prices.length - 1] || 100;
  }
  
  private identifyVolumeNodes(prices: number[], volumes: number[]): any[] {
    return []; // تطبيق مبسط
  }
  
  private getForexCorrelations(symbol: string): any {
    return { EURUSD: Math.random(), GBPUSD: Math.random(), USDJPY: Math.random() };
  }
  
  private getCommodityCorrelations(symbol: string): any {
    return { GOLD: Math.random(), OIL: Math.random(), SILVER: Math.random() };
  }
  
  private getIndexCorrelations(symbol: string): any {
    return { SPX500: Math.random(), NASDAQ: Math.random(), DAX: Math.random() };
  }
  
  private getCryptoCorrelations(symbol: string): any {
    return { BTC: Math.random(), ETH: Math.random(), ADA: Math.random() };
  }
  
  private estimatePredictionAccuracy(predictions: AIModelPrediction[]): number {
    return predictions.reduce((sum, p) => sum + p.confidence, 0) / predictions.length * 0.85;
  }
  
  private identifyOptimalTimeframes(predictions: AIModelPrediction[]): string[] {
    return ['5m', '15m', '1h']; // مبسط
  }
  
  private calculateRiskRewardRatio(levels: any): number {
    const risk = Math.abs(levels.entryPrice - levels.stopLoss);
    const reward = Math.abs(levels.takeProfit1 - levels.entryPrice);
    return reward / risk;
  }
  
  private generateEntryStrategy(signal: string, regime: string): string {
    const strategies = {
      'trending': 'دخول على انسحاب في الاتجاه الرئيسي',
      'ranging': 'دخول من مستويات الدعم والمقاومة',
      'volatile': 'انتظار استقرار التقلبات قبل الدخول',
      'reversal': 'دخول تدريجي مع تأكيد الانعكاس'
    };
    return strategies[regime] || 'دخول عند تأكيد الاتجاه';
  }
  
  private generateExitStrategy(signal: string, regime: string): string {
    return 'خروج تدريجي عند تحقيق الأهداف مع trailing stop';
  }
  
  private calculateOptimalPositionSize(riskLevel: string, confidence: number): number {
    const baseSize = 0.02; // 2% من رأس المال
    
    if (riskLevel === 'LOW' && confidence > 85) return baseSize * 1.5;
    if (riskLevel === 'HIGH' || confidence < 70) return baseSize * 0.5;
    return baseSize;
  }
  
  private generateIntermarketSignals(correlations: any): any {
    return {
      forex_sentiment: 'bullish',
      commodity_trend: 'neutral',
      equity_flow: 'bearish'
    };
  }
  
  private async getFallbackEnhancedSignal(symbol: string): Promise<any> {
    // نظام احتياطي محسن
    return {
      signal: 'HOLD' as const,
      confidence: 60,
      strength: 'متوسطة' as const,
      riskLevel: 'MEDIUM' as const,
      reasoning: ['نظام احتياطي - البيانات محدودة', 'تحليل محافظ بناءً على الظروف الحالية'],
      aiAnalysis: {
        modelConsensus: 60,
        predictionAccuracy: 70,
        marketRegime: 'ranging' as const,
        optimalTimeframes: ['5m', '15m'],
        riskRewardRatio: 1.5,
        entryStrategy: 'انتظار إشارات أقوى',
        exitStrategy: 'إدارة مخاطر محافظة',
        positionSizing: 0.01
      },
      technicalLevels: {
        entryPrice: 100,
        stopLoss: 98,
        takeProfit1: 102,
        takeProfit2: 104,
        dynamicSupport: 99,
        dynamicResistance: 101
      },
      marketContext: {
        correlationAnalysis: {},
        intermarketSignals: {},
        institutionalFlow: 'neutral' as const,
        smartMoneyIndicators: {}
      }
    };
  }
}