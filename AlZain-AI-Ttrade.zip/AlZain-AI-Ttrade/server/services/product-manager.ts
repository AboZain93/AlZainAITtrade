import { products, licenses, commercialUsers } from '@shared/commercial-schema';
import { db } from '../db';
import { eq, desc } from 'drizzle-orm';

export interface ProductCreationData {
  name: string;
  nameAr: string;
  description: string;
  descriptionAr: string;
  productType: 'subscription' | 'lifetime' | 'addon';
  category: 'basic' | 'pro' | 'premium' | 'enterprise';
  priceUSD: number;
  originalPriceUSD?: number;
  billingCycle?: 'monthly' | 'yearly' | 'lifetime';
  features: string[];
  limits: {
    dailySignals: number;
    monthlySignals: number;
    maxDevices: number;
    apiCalls: number;
    features: string[];
  };
  trialDays?: number;
  isPopular?: boolean;
}

export class ProductManager {
  
  async initializeDefaultProducts(): Promise<void> {
    try {
      // Check if products already exist
      const existingProducts = await db.select().from(products).limit(1);
      if (existingProducts.length > 0) {
        console.log('Products already initialized');
        return;
      }

      const defaultProducts: ProductCreationData[] = [
        {
          name: 'Basic Plan',
          nameAr: 'الخطة الأساسية',
          description: 'Perfect for individual traders starting their journey',
          descriptionAr: 'مثالية للمتداولين الأفراد الذين يبدؤون رحلتهم',
          productType: 'subscription',
          category: 'basic',
          priceUSD: 29.99,
          billingCycle: 'monthly',
          features: [
            'Up to 50 daily signals',
            'Basic technical analysis',
            'Telegram notifications',
            'Mobile app access',
            'Email support'
          ],
          limits: {
            dailySignals: 50,
            monthlySignals: 1500,
            maxDevices: 2,
            apiCalls: 1000,
            features: ['basic_signals', 'telegram_notifications', 'mobile_access']
          },
          trialDays: 7
        },
        {
          name: 'Pro Plan',
          nameAr: 'الخطة الاحترافية',
          description: 'Advanced features for serious traders',
          descriptionAr: 'ميزات متقدمة للمتداولين الجادين',
          productType: 'subscription',
          category: 'pro',
          priceUSD: 79.99,
          originalPriceUSD: 99.99,
          billingCycle: 'monthly',
          features: [
            'Up to 150 daily signals',
            'Advanced AI analysis',
            'Risk management tools',
            'Portfolio analytics',
            'Priority support',
            'Custom alerts',
            'Historical data'
          ],
          limits: {
            dailySignals: 150,
            monthlySignals: 4500,
            maxDevices: 5,
            apiCalls: 5000,
            features: [
              'advanced_signals', 'ai_analysis', 'risk_management',
              'portfolio_analytics', 'custom_alerts', 'historical_data'
            ]
          },
          trialDays: 14,
          isPopular: true
        },
        {
          name: 'Premium Plan',
          nameAr: 'الخطة المميزة',
          description: 'Ultimate trading experience with all features',
          descriptionAr: 'تجربة التداول المطلقة مع جميع الميزات',
          productType: 'subscription',
          category: 'premium',
          priceUSD: 149.99,
          originalPriceUSD: 199.99,
          billingCycle: 'monthly',
          features: [
            'Unlimited daily signals',
            'Ultra-advanced AI',
            'Multi-asset portfolio',
            'Real-time market data',
            'VIP support',
            'Custom strategies',
            'API access',
            'White-label options'
          ],
          limits: {
            dailySignals: -1, // Unlimited
            monthlySignals: -1, // Unlimited
            maxDevices: 10,
            apiCalls: 20000,
            features: [
              'unlimited_signals', 'ultra_ai', 'multi_asset_portfolio',
              'realtime_data', 'vip_support', 'custom_strategies',
              'api_access', 'white_label'
            ]
          },
          trialDays: 30
        },
        {
          name: 'Enterprise Plan',
          nameAr: 'خطة المؤسسات',
          description: 'Custom solutions for institutions and large teams',
          descriptionAr: 'حلول مخصصة للمؤسسات والفرق الكبيرة',
          productType: 'subscription',
          category: 'enterprise',
          priceUSD: 499.99,
          billingCycle: 'monthly',
          features: [
            'Unlimited everything',
            'Dedicated account manager',
            'Custom AI models',
            'On-premise deployment',
            'SLA guarantee',
            'Custom integrations',
            'Training sessions',
            'Priority development'
          ],
          limits: {
            dailySignals: -1,
            monthlySignals: -1,
            maxDevices: -1, // Unlimited
            apiCalls: -1, // Unlimited
            features: [
              'unlimited_all', 'dedicated_manager', 'custom_ai',
              'on_premise', 'sla_guarantee', 'custom_integrations',
              'training_sessions', 'priority_development'
            ]
          },
          trialDays: 30
        },
        {
          name: 'Lifetime Access',
          nameAr: 'الوصول مدى الحياة',
          description: 'One-time payment for lifetime access to Pro features',
          descriptionAr: 'دفعة واحدة للوصول مدى الحياة لميزات الخطة الاحترافية',
          productType: 'lifetime',
          category: 'pro',
          priceUSD: 999.99,
          originalPriceUSD: 1499.99,
          billingCycle: 'lifetime',
          features: [
            'All Pro features',
            'Lifetime updates',
            'No monthly fees',
            'Transfer license',
            'Priority support'
          ],
          limits: {
            dailySignals: 150,
            monthlySignals: 4500,
            maxDevices: 5,
            apiCalls: 5000,
            features: [
              'advanced_signals', 'ai_analysis', 'risk_management',
              'portfolio_analytics', 'lifetime_updates', 'transferable'
            ]
          }
        }
      ];

      for (const productData of defaultProducts) {
        await this.createProduct(productData);
      }

      console.log('✅ Default products initialized successfully');
    } catch (error) {
      console.error('Error initializing default products:', error);
    }
  }

  async createProduct(productData: ProductCreationData): Promise<string> {
    try {
      const [product] = await db.insert(products).values({
        name: productData.name,
        nameAr: productData.nameAr,
        description: productData.description,
        descriptionAr: productData.descriptionAr,
        productType: productData.productType,
        category: productData.category,
        priceUSD: productData.priceUSD,
        originalPriceUSD: productData.originalPriceUSD,
        billingCycle: productData.billingCycle,
        features: productData.features,
        limits: productData.limits,
        trialDays: productData.trialDays || 0,
        isPopular: productData.isPopular || false,
        isActive: true
      }).returning();

      return product.id;
    } catch (error) {
      console.error('Error creating product:', error);
      throw error;
    }
  }

  async getAllProducts(): Promise<any[]> {
    try {
      return await db.select()
        .from(products)
        .where(eq(products.isActive, true))
        .orderBy(products.sortOrder, products.priceUSD);
    } catch (error) {
      console.error('Error fetching products:', error);
      return [];
    }
  }

  async getProduct(productId: string): Promise<any | null> {
    try {
      const [product] = await db.select()
        .from(products)
        .where(eq(products.id, productId))
        .limit(1);

      return product || null;
    } catch (error) {
      console.error('Error fetching product:', error);
      return null;
    }
  }

  async updateProduct(productId: string, updateData: Partial<ProductCreationData>): Promise<boolean> {
    try {
      await db.update(products)
        .set({
          ...updateData,
          updatedAt: new Date()
        })
        .where(eq(products.id, productId));

      return true;
    } catch (error) {
      console.error('Error updating product:', error);
      return false;
    }
  }

  async deleteProduct(productId: string): Promise<boolean> {
    try {
      // Soft delete - mark as inactive
      await db.update(products)
        .set({
          isActive: false,
          updatedAt: new Date()
        })
        .where(eq(products.id, productId));

      return true;
    } catch (error) {
      console.error('Error deleting product:', error);
      return false;
    }
  }

  async getProductsByCategory(category: string): Promise<any[]> {
    try {
      return await db.select()
        .from(products)
        .where(eq(products.category, category))
        .orderBy(products.priceUSD);
    } catch (error) {
      console.error('Error fetching products by category:', error);
      return [];
    }
  }

  async getPopularProducts(): Promise<any[]> {
    try {
      return await db.select()
        .from(products)
        .where(eq(products.isPopular, true))
        .orderBy(products.sortOrder);
    } catch (error) {
      console.error('Error fetching popular products:', error);
      return [];
    }
  }

  async getProductStats(productId: string): Promise<any> {
    try {
      // Get product license statistics
      const totalLicenses = await db.select({ count: productKeys.id })
        .from(productKeys)
        .where(eq(productKeys.productId, productId));

      const activatedLicenses = await db.select({ count: productKeys.id })
        .from(productKeys)
        .where(eq(productKeys.productId, productId))
        .where(eq(productKeys.isActivated, true));

      const validLicenses = await db.select({ count: productKeys.id })
        .from(productKeys)
        .where(eq(productKeys.productId, productId))
        .where(eq(productKeys.isValid, true));

      return {
        totalLicenses: totalLicenses.length,
        activatedLicenses: activatedLicenses.length,
        validLicenses: validLicenses.length,
        activationRate: totalLicenses.length > 0 ? 
          (activatedLicenses.length / totalLicenses.length) * 100 : 0
      };
    } catch (error) {
      console.error('Error fetching product stats:', error);
      return {
        totalLicenses: 0,
        activatedLicenses: 0,
        validLicenses: 0,
        activationRate: 0
      };
    }
  }

  getProductFeaturesList(): { [key: string]: string } {
    return {
      'basic_signals': 'Basic Trading Signals',
      'advanced_signals': 'Advanced Trading Signals',
      'unlimited_signals': 'Unlimited Trading Signals',
      'telegram_notifications': 'Telegram Notifications',
      'mobile_access': 'Mobile App Access',
      'ai_analysis': 'AI Analysis',
      'ultra_ai': 'Ultra-Advanced AI',
      'risk_management': 'Risk Management Tools',
      'portfolio_analytics': 'Portfolio Analytics',
      'custom_alerts': 'Custom Alerts',
      'historical_data': 'Historical Data Access',
      'realtime_data': 'Real-time Market Data',
      'vip_support': 'VIP Support',
      'custom_strategies': 'Custom Trading Strategies',
      'api_access': 'API Access',
      'white_label': 'White-label Options',
      'multi_asset_portfolio': 'Multi-asset Portfolio',
      'lifetime_updates': 'Lifetime Updates',
      'transferable': 'Transferable License',
      'unlimited_all': 'Unlimited Everything',
      'dedicated_manager': 'Dedicated Account Manager',
      'custom_ai': 'Custom AI Models',
      'on_premise': 'On-premise Deployment',
      'sla_guarantee': 'SLA Guarantee',
      'custom_integrations': 'Custom Integrations',
      'training_sessions': 'Training Sessions',
      'priority_development': 'Priority Development'
    };
  }
}

export const productManager = new ProductManager();