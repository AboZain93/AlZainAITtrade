import { MarketData } from "@shared/schema";

export interface AdvancedTechnicalIndicators {
  rsi: number;
  macd: {
    macd: number;
    signal: number;
    histogram: number;
  };
  bollingerBands: {
    upper: number;
    middle: number;
    lower: number;
  };
  stochastic: {
    k: number;
    d: number;
  };
  williamsR: number;
  cci: number; // Commodity Channel Index
  atr: number; // Average True Range
  obv: number; // On-Balance Volume
  mfi: number; // Money Flow Index
  adx: number; // Average Directional Index
  momentum: number;
  roc: number; // Rate of Change
  pivotPoints: {
    pivot: number;
    r1: number;
    r2: number;
    r3: number;
    s1: number;
    s2: number;
    s3: number;
  };
  fibonacciLevels: {
    level23_6: number;
    level38_2: number;
    level50: number;
    level61_8: number;
    level78_6: number;
  };
}

export interface MarketSentiment {
  fearGreedIndex: number; // 0-100
  volatilityIndex: number;
  trendStrength: 'weak' | 'moderate' | 'strong';
  marketPhase: 'accumulation' | 'uptrend' | 'distribution' | 'downtrend';
  supportResistance: {
    support: number[];
    resistance: number[];
  };
}

export interface TradingSignal {
  signal: 'buy' | 'sell' | 'hold';
  strength: number; // 0-100
  confidence: number; // 0-100
  timeframe: '1m' | '5m' | '15m' | '1h' | '4h' | '1d';
  reasons: string[];
  riskLevel: 'low' | 'medium' | 'high';
  entryPrice: number;
  stopLoss: number;
  takeProfit: number[];
  expectedDuration: string;
}

export class AdvancedTechnicalAnalysisService {
  
  // Calculate RSI with customizable period
  calculateRSI(prices: number[], period: number = 14): number {
    if (prices.length < period + 1) return 50;
    
    let gains = 0;
    let losses = 0;
    
    for (let i = 1; i <= period; i++) {
      const change = prices[i] - prices[i - 1];
      if (change > 0) gains += change;
      else losses -= change;
    }
    
    const avgGain = gains / period;
    const avgLoss = losses / period;
    
    if (avgLoss === 0) return 100;
    
    const rs = avgGain / avgLoss;
    return 100 - (100 / (1 + rs));
  }
  
  // Calculate MACD
  calculateMACD(prices: number[], fastPeriod: number = 12, slowPeriod: number = 26, signalPeriod: number = 9) {
    const fastEMA = this.calculateEMA(prices, fastPeriod);
    const slowEMA = this.calculateEMA(prices, slowPeriod);
    const macdLine = fastEMA - slowEMA;
    
    // For simplicity, using SMA instead of EMA for signal line
    const macdHistory = prices.slice(-signalPeriod).map((_, i) => {
      const fEMA = this.calculateEMA(prices.slice(0, prices.length - signalPeriod + i + 1), fastPeriod);
      const sEMA = this.calculateEMA(prices.slice(0, prices.length - signalPeriod + i + 1), slowPeriod);
      return fEMA - sEMA;
    });
    
    const signal = macdHistory.reduce((sum, val) => sum + val, 0) / macdHistory.length;
    const histogram = macdLine - signal;
    
    return { macd: macdLine, signal, histogram };
  }
  
  // Calculate Exponential Moving Average
  calculateEMA(prices: number[], period: number): number {
    if (prices.length === 0) return 0;
    if (prices.length === 1) return prices[0];
    
    const multiplier = 2 / (period + 1);
    let ema = prices[0];
    
    for (let i = 1; i < prices.length; i++) {
      ema = (prices[i] * multiplier) + (ema * (1 - multiplier));
    }
    
    return ema;
  }
  
  // Calculate Bollinger Bands
  calculateBollingerBands(prices: number[], period: number = 20, stdDevMultiplier: number = 2) {
    const sma = prices.slice(-period).reduce((sum, price) => sum + price, 0) / period;
    const variance = prices.slice(-period).reduce((sum, price) => sum + Math.pow(price - sma, 2), 0) / period;
    const stdDev = Math.sqrt(variance);
    
    return {
      upper: sma + (stdDev * stdDevMultiplier),
      middle: sma,
      lower: sma - (stdDev * stdDevMultiplier)
    };
  }
  
  // Calculate Stochastic Oscillator
  calculateStochastic(highs: number[], lows: number[], closes: number[], kPeriod: number = 14, dPeriod: number = 3) {
    const recentData = {
      highs: highs.slice(-kPeriod),
      lows: lows.slice(-kPeriod),
      closes: closes.slice(-kPeriod)
    };
    
    const highestHigh = Math.max(...recentData.highs);
    const lowestLow = Math.min(...recentData.lows);
    const currentClose = recentData.closes[recentData.closes.length - 1];
    
    const k = ((currentClose - lowestLow) / (highestHigh - lowestLow)) * 100;
    
    // Calculate %D (simple moving average of %K)
    const recentK = closes.slice(-dPeriod).map((close, i) => {
      const high = Math.max(...highs.slice(-(kPeriod + dPeriod - i), -dPeriod + i + 1 || undefined));
      const low = Math.min(...lows.slice(-(kPeriod + dPeriod - i), -dPeriod + i + 1 || undefined));
      return ((close - low) / (high - low)) * 100;
    });
    
    const d = recentK.reduce((sum, val) => sum + val, 0) / recentK.length;
    
    return { k, d };
  }
  
  // Calculate Williams %R
  calculateWilliamsR(highs: number[], lows: number[], closes: number[], period: number = 14): number {
    const recentHighs = highs.slice(-period);
    const recentLows = lows.slice(-period);
    const currentClose = closes[closes.length - 1];
    
    const highestHigh = Math.max(...recentHighs);
    const lowestLow = Math.min(...recentLows);
    
    return ((highestHigh - currentClose) / (highestHigh - lowestLow)) * -100;
  }
  
  // Calculate Commodity Channel Index (CCI)
  calculateCCI(highs: number[], lows: number[], closes: number[], period: number = 20): number {
    const typicalPrices = closes.map((close, i) => (highs[i] + lows[i] + close) / 3);
    const recentTypicalPrices = typicalPrices.slice(-period);
    const sma = recentTypicalPrices.reduce((sum, tp) => sum + tp, 0) / period;
    
    const meanDeviation = recentTypicalPrices.reduce((sum, tp) => sum + Math.abs(tp - sma), 0) / period;
    const currentTypicalPrice = typicalPrices[typicalPrices.length - 1];
    
    return (currentTypicalPrice - sma) / (0.015 * meanDeviation);
  }
  
  // Calculate Average True Range (ATR)
  calculateATR(highs: number[], lows: number[], closes: number[], period: number = 14): number {
    const trueRanges = [];
    
    for (let i = 1; i < closes.length; i++) {
      const tr1 = highs[i] - lows[i];
      const tr2 = Math.abs(highs[i] - closes[i - 1]);
      const tr3 = Math.abs(lows[i] - closes[i - 1]);
      trueRanges.push(Math.max(tr1, tr2, tr3));
    }
    
    const recentTR = trueRanges.slice(-period);
    return recentTR.reduce((sum, tr) => sum + tr, 0) / period;
  }
  
  // Calculate Money Flow Index (MFI)
  calculateMFI(highs: number[], lows: number[], closes: number[], volumes: number[], period: number = 14): number {
    const typicalPrices = closes.map((close, i) => (highs[i] + lows[i] + close) / 3);
    const moneyFlows = typicalPrices.map((tp, i) => tp * volumes[i]);
    
    let positiveFlow = 0;
    let negativeFlow = 0;
    
    for (let i = 1; i < Math.min(period + 1, typicalPrices.length); i++) {
      if (typicalPrices[typicalPrices.length - i] > typicalPrices[typicalPrices.length - i - 1]) {
        positiveFlow += moneyFlows[moneyFlows.length - i];
      } else {
        negativeFlow += moneyFlows[moneyFlows.length - i];
      }
    }
    
    if (negativeFlow === 0) return 100;
    const moneyRatio = positiveFlow / negativeFlow;
    return 100 - (100 / (1 + moneyRatio));
  }
  
  // Calculate Pivot Points
  calculatePivotPoints(high: number, low: number, close: number) {
    const pivot = (high + low + close) / 3;
    
    return {
      pivot,
      r1: (2 * pivot) - low,
      r2: pivot + (high - low),
      r3: high + 2 * (pivot - low),
      s1: (2 * pivot) - high,
      s2: pivot - (high - low),
      s3: low - 2 * (high - pivot)
    };
  }
  
  // Calculate Fibonacci Retracement Levels
  calculateFibonacciLevels(high: number, low: number) {
    const range = high - low;
    
    return {
      level23_6: high - (range * 0.236),
      level38_2: high - (range * 0.382),
      level50: high - (range * 0.5),
      level61_8: high - (range * 0.618),
      level78_6: high - (range * 0.786)
    };
  }
  
  // Comprehensive analysis combining all indicators
  analyzeMarket(marketData: MarketData[], volumes?: number[]): {
    indicators: AdvancedTechnicalIndicators;
    sentiment: MarketSentiment;
    signals: TradingSignal[];
  } {
    if (marketData.length < 50) {
      throw new Error('Insufficient data for comprehensive analysis');
    }
    
    const prices = marketData.map(d => d.price);
    const highs = prices.map(p => p * (1 + Math.random() * 0.002)); // Simulated highs
    const lows = prices.map(p => p * (1 - Math.random() * 0.002)); // Simulated lows
    const defaultVolumes = volumes || prices.map(() => Math.random() * 1000000);
    
    const latest = marketData[marketData.length - 1];
    const high = Math.max(...prices.slice(-20));
    const low = Math.min(...prices.slice(-20));
    
    // Calculate all technical indicators
    const indicators: AdvancedTechnicalIndicators = {
      rsi: this.calculateRSI(prices),
      macd: this.calculateMACD(prices),
      bollingerBands: this.calculateBollingerBands(prices),
      stochastic: this.calculateStochastic(highs, lows, prices),
      williamsR: this.calculateWilliamsR(highs, lows, prices),
      cci: this.calculateCCI(highs, lows, prices),
      atr: this.calculateATR(highs, lows, prices),
      obv: defaultVolumes.reduce((sum, vol, i) => {
        if (i === 0) return vol;
        return sum + (prices[i] > prices[i-1] ? vol : -vol);
      }, 0),
      mfi: this.calculateMFI(highs, lows, prices, defaultVolumes),
      adx: this.calculateRSI(prices, 14), // Simplified ADX
      momentum: ((prices[prices.length - 1] / prices[prices.length - 10]) - 1) * 100,
      roc: ((prices[prices.length - 1] / prices[prices.length - 12]) - 1) * 100,
      pivotPoints: this.calculatePivotPoints(high, low, latest.price),
      fibonacciLevels: this.calculateFibonacciLevels(high, low)
    };
    
    // Calculate market sentiment
    const volatility = this.calculateATR(highs, lows, prices) / latest.price * 100;
    const trendStrength = Math.abs(indicators.adx) > 25 ? 'strong' : 
                         Math.abs(indicators.adx) > 15 ? 'moderate' : 'weak';
    
    const sentiment: MarketSentiment = {
      fearGreedIndex: this.calculateFearGreedIndex(indicators),
      volatilityIndex: volatility,
      trendStrength,
      marketPhase: this.determineMarketPhase(indicators),
      supportResistance: {
        support: [indicators.bollingerBands.lower, indicators.pivotPoints.s1, indicators.pivotPoints.s2],
        resistance: [indicators.bollingerBands.upper, indicators.pivotPoints.r1, indicators.pivotPoints.r2]
      }
    };
    
    // Generate trading signals
    const signals = this.generateTradingSignals(indicators, sentiment, latest.price);
    
    return { indicators, sentiment, signals };
  }
  
  private calculateFearGreedIndex(indicators: AdvancedTechnicalIndicators): number {
    // Combine multiple indicators to create fear/greed index
    const rsiScore = indicators.rsi > 70 ? 20 : indicators.rsi < 30 ? 80 : 50;
    const macdScore = indicators.macd.histogram > 0 ? 70 : 30;
    const volatilityScore = indicators.atr > 2 ? 20 : 60;
    
    return Math.round((rsiScore + macdScore + volatilityScore) / 3);
  }
  
  private determineMarketPhase(indicators: AdvancedTechnicalIndicators): 'accumulation' | 'uptrend' | 'distribution' | 'downtrend' {
    if (indicators.rsi < 40 && indicators.macd.histogram < 0) return 'accumulation';
    if (indicators.rsi > 60 && indicators.macd.histogram > 0) return 'uptrend';
    if (indicators.rsi > 60 && indicators.macd.histogram < 0) return 'distribution';
    return 'downtrend';
  }
  
  private generateTradingSignals(indicators: AdvancedTechnicalIndicators, sentiment: MarketSentiment, currentPrice: number): TradingSignal[] {
    const signals: TradingSignal[] = [];
    
    // Generate buy signal
    if (indicators.rsi < 30 && indicators.stochastic.k < 20 && indicators.macd.histogram > 0) {
      signals.push({
        signal: 'buy',
        strength: 85,
        confidence: 78,
        timeframe: '15m',
        reasons: ['RSI oversold', 'Stochastic oversold', 'MACD bullish crossover'],
        riskLevel: 'medium',
        entryPrice: currentPrice,
        stopLoss: currentPrice * 0.98,
        takeProfit: [currentPrice * 1.02, currentPrice * 1.04],
        expectedDuration: '2-4 hours'
      });
    }
    
    // Generate sell signal
    if (indicators.rsi > 70 && indicators.stochastic.k > 80 && indicators.macd.histogram < 0) {
      signals.push({
        signal: 'sell',
        strength: 80,
        confidence: 75,
        timeframe: '15m',
        reasons: ['RSI overbought', 'Stochastic overbought', 'MACD bearish crossover'],
        riskLevel: 'medium',
        entryPrice: currentPrice,
        stopLoss: currentPrice * 1.02,
        takeProfit: [currentPrice * 0.98, currentPrice * 0.96],
        expectedDuration: '1-3 hours'
      });
    }
    
    return signals;
  }
}

export const advancedTechnicalAnalysis = new AdvancedTechnicalAnalysisService();