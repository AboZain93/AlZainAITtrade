import { storage } from "../storage";

export interface TraderProfile {
  id: number;
  username: string;
  displayName: string;
  avatar?: string;
  level: 'beginner' | 'intermediate' | 'advanced' | 'expert' | 'master';
  skillRating: number; // 0-100
  totalTrades: number;
  winRate: number;
  profitLoss: number;
  avgReturnPercent: number;
  followers: number;
  following: number;
  joinDate: Date;
  lastActive: Date;
  isVerified: boolean;
  badges: string[];
  tradingStyle: 'scalping' | 'day-trading' | 'swing' | 'position';
  riskLevel: 'low' | 'medium' | 'high';
  specialization: string[]; // ['forex', 'crypto', 'stocks', 'commodities']
  monthlyPerformance: {
    month: string;
    return: number;
    trades: number;
    winRate: number;
  }[];
}

export interface TradingSignal {
  id: number;
  traderId: number;
  symbol: string;
  direction: 'BUY' | 'SELL';
  confidence: number;
  entryPrice: number;
  targetPrice: number;
  stopLoss: number;
  timeframe: string;
  analysis: string;
  timestamp: Date;
  status: 'active' | 'closed' | 'cancelled';
  result?: 'win' | 'loss';
  actualReturn?: number;
  likes: number;
  comments: number;
  copies: number;
}

export interface CopyTrade {
  id: number;
  followerId: number;
  traderId: number;
  signalId: number;
  amount: number;
  multiplier: number;
  status: 'active' | 'closed';
  entryPrice: number;
  exitPrice?: number;
  profit?: number;
  timestamp: Date;
}

export interface LeaderboardEntry {
  rank: number;
  trader: TraderProfile;
  monthlyReturn: number;
  monthlyTrades: number;
  monthlyWinRate: number;
  change: number; // rank change from last month
}

class SocialTradingService {
  private traders: Map<number, TraderProfile> = new Map();
  private signals: Map<number, TradingSignal> = new Map();
  private copyTrades: Map<number, CopyTrade> = new Map();
  private currentTraderId = 1;
  private currentSignalId = 1;
  private currentCopyTradeId = 1;

  constructor() {
    this.initializeMockData();
  }

  private initializeMockData() {
    // إنشاء متداولين وهميين للعرض
    const mockTraders: Partial<TraderProfile>[] = [
      {
        id: 1,
        username: 'احمد_الخبير',
        displayName: 'أحمد الخبير',
        level: 'expert',
        skillRating: 92,
        totalTrades: 1247,
        winRate: 78.5,
        profitLoss: 45678.90,
        avgReturnPercent: 12.3,
        followers: 2341,
        following: 45,
        isVerified: true,
        badges: ['متداول الشهر', 'خبير فوركس', 'مؤشر عالي'],
        tradingStyle: 'day-trading',
        riskLevel: 'medium',
        specialization: ['forex', 'crypto'],
        monthlyPerformance: [
          { month: '2024-12', return: 15.2, trades: 89, winRate: 82.1 },
          { month: '2024-11', return: 11.8, trades: 76, winRate: 75.0 },
          { month: '2024-10', return: 9.4, trades: 94, winRate: 79.8 }
        ]
      },
      {
        id: 2,
        username: 'فاطمة_الذهبية',
        displayName: 'فاطمة الذهبية',
        level: 'advanced',
        skillRating: 87,
        totalTrades: 892,
        winRate: 74.2,
        profitLoss: 23456.78,
        avgReturnPercent: 8.7,
        followers: 1567,
        following: 67,
        isVerified: true,
        badges: ['تاجرة الأسبوع', 'خبيرة ذهب'],
        tradingStyle: 'swing',
        riskLevel: 'low',
        specialization: ['commodities', 'stocks'],
        monthlyPerformance: [
          { month: '2024-12', return: 12.1, trades: 56, winRate: 80.4 },
          { month: '2024-11', return: 8.9, trades: 67, winRate: 71.6 },
          { month: '2024-10', return: 6.8, trades: 78, winRate: 76.9 }
        ]
      },
      {
        id: 3,
        username: 'محمد_الكريبتو',
        displayName: 'محمد الكريبتو',
        level: 'master',
        skillRating: 95,
        totalTrades: 2156,
        winRate: 81.3,
        profitLoss: 78901.23,
        avgReturnPercent: 18.9,
        followers: 3892,
        following: 23,
        isVerified: true,
        badges: ['ماستر كريبتو', 'أفضل متداول', 'تحليل تقني'],
        tradingStyle: 'scalping',
        riskLevel: 'high',
        specialization: ['crypto'],
        monthlyPerformance: [
          { month: '2024-12', return: 22.7, trades: 156, winRate: 85.3 },
          { month: '2024-11', return: 19.4, trades: 134, winRate: 79.9 },
          { month: '2024-10', return: 16.8, trades: 189, winRate: 83.1 }
        ]
      },
      {
        id: 4,
        username: 'سارة_الأسهم',
        displayName: 'سارة الأسهم',
        level: 'intermediate',
        skillRating: 76,
        totalTrades: 567,
        winRate: 69.8,
        profitLoss: 12345.67,
        avgReturnPercent: 6.4,
        followers: 789,
        following: 89,
        isVerified: false,
        badges: ['متداولة صاعدة'],
        tradingStyle: 'position',
        riskLevel: 'low',
        specialization: ['stocks'],
        monthlyPerformance: [
          { month: '2024-12', return: 7.8, trades: 34, winRate: 73.5 },
          { month: '2024-11', return: 5.2, trades: 41, winRate: 68.3 },
          { month: '2024-10', return: 4.9, trades: 38, winRate: 71.1 }
        ]
      },
      {
        id: 5,
        username: 'عمر_الفوركس',
        displayName: 'عمر الفوركس',
        level: 'expert',
        skillRating: 89,
        totalTrades: 1534,
        winRate: 76.9,
        profitLoss: 34567.89,
        avgReturnPercent: 10.2,
        followers: 1998,
        following: 34,
        isVerified: true,
        badges: ['خبير فوركس', 'محلل فني'],
        tradingStyle: 'day-trading',
        riskLevel: 'medium',
        specialization: ['forex'],
        monthlyPerformance: [
          { month: '2024-12', return: 13.6, trades: 92, winRate: 81.5 },
          { month: '2024-11', return: 9.8, trades: 87, winRate: 74.7 },
          { month: '2024-10', return: 8.4, trades: 103, winRate: 78.6 }
        ]
      }
    ];

    // إضافة التواريخ والخصائص المفقودة
    mockTraders.forEach((trader, index) => {
      const fullTrader: TraderProfile = {
        ...trader,
        joinDate: new Date(2023, 6 + index, 15),
        lastActive: new Date(Date.now() - Math.random() * 3600000), // آخر نشاط خلال الساعة الماضية
      } as TraderProfile;
      
      this.traders.set(fullTrader.id, fullTrader);
    });

    // إنشاء إشارات وهمية
    const mockSignals: Partial<TradingSignal>[] = [
      {
        id: 1,
        traderId: 1,
        symbol: 'EUR/USD',
        direction: 'BUY',
        confidence: 85,
        entryPrice: 1.2145,
        targetPrice: 1.2245,
        stopLoss: 1.2095,
        timeframe: '1H',
        analysis: 'تحليل فني قوي يشير إلى اتجاه صاعد مع كسر مستوى المقاومة',
        timestamp: new Date(Date.now() - 1800000), // قبل 30 دقيقة
        status: 'active',
        likes: 23,
        comments: 8,
        copies: 45
      },
      {
        id: 2,
        traderId: 2,
        symbol: 'GOLD',
        direction: 'SELL',
        confidence: 78,
        entryPrice: 2078.50,
        targetPrice: 2055.00,
        stopLoss: 2090.00,
        timeframe: '4H',
        analysis: 'مؤشرات فنية تشير إلى ضعف في اتجاه الذهب مع تقوية الدولار',
        timestamp: new Date(Date.now() - 3600000), // قبل ساعة
        status: 'active',
        likes: 31,
        comments: 12,
        copies: 67
      },
      {
        id: 3,
        traderId: 3,
        symbol: 'BTC/USD',
        direction: 'BUY',
        confidence: 92,
        entryPrice: 43500,
        targetPrice: 45200,
        stopLoss: 42800,
        timeframe: '15M',
        analysis: 'نمط صاعد قوي مع حجم تداول عالي وكسر مستوى مقاومة مهم',
        timestamp: new Date(Date.now() - 900000), // قبل 15 دقيقة
        status: 'active',
        likes: 89,
        comments: 34,
        copies: 156
      }
    ];

    mockSignals.forEach(signal => {
      this.signals.set(signal.id!, signal as TradingSignal);
    });
  }

  // الحصول على لائحة المتداولين الأعلى تقييماً
  async getLeaderboard(limit: number = 10): Promise<LeaderboardEntry[]> {
    const traders = Array.from(this.traders.values());
    
    // ترتيب حسب التقييم والأداء الشهري
    const sortedTraders = traders
      .sort((a, b) => {
        const aMonthlyReturn = a.monthlyPerformance[0]?.return || 0;
        const bMonthlyReturn = b.monthlyPerformance[0]?.return || 0;
        return (b.skillRating * 0.7 + bMonthlyReturn * 0.3) - (a.skillRating * 0.7 + aMonthlyReturn * 0.3);
      })
      .slice(0, limit);

    return sortedTraders.map((trader, index) => ({
      rank: index + 1,
      trader,
      monthlyReturn: trader.monthlyPerformance[0]?.return || 0,
      monthlyTrades: trader.monthlyPerformance[0]?.trades || 0,
      monthlyWinRate: trader.monthlyPerformance[0]?.winRate || 0,
      change: Math.floor(Math.random() * 10) - 5 // تغيير عشوائي في الترتيب
    }));
  }

  // الحصول على إشارات التداول النشطة
  async getActiveSignals(limit: number = 20): Promise<TradingSignal[]> {
    const signals = Array.from(this.signals.values())
      .filter(signal => signal.status === 'active')
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
      .slice(0, limit);

    return signals;
  }

  // الحصول على ملف متداول محدد
  async getTraderProfile(traderId: number): Promise<TraderProfile | undefined> {
    return this.traders.get(traderId);
  }

  // الحصول على إشارات متداول محدد
  async getTraderSignals(traderId: number, limit: number = 10): Promise<TradingSignal[]> {
    const signals = Array.from(this.signals.values())
      .filter(signal => signal.traderId === traderId)
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
      .slice(0, limit);

    return signals;
  }

  // متابعة متداول
  async followTrader(followerId: number, traderId: number): Promise<boolean> {
    const trader = this.traders.get(traderId);
    if (trader) {
      trader.followers += 1;
      return true;
    }
    return false;
  }

  // إلغاء متابعة متداول
  async unfollowTrader(followerId: number, traderId: number): Promise<boolean> {
    const trader = this.traders.get(traderId);
    if (trader && trader.followers > 0) {
      trader.followers -= 1;
      return true;
    }
    return false;
  }

  // نسخ صفقة
  async copyTrade(followerId: number, signalId: number, amount: number, multiplier: number = 1): Promise<CopyTrade | null> {
    const signal = this.signals.get(signalId);
    if (!signal || signal.status !== 'active') {
      return null;
    }

    const copyTrade: CopyTrade = {
      id: this.currentCopyTradeId++,
      followerId,
      traderId: signal.traderId,
      signalId,
      amount,
      multiplier,
      status: 'active',
      entryPrice: signal.entryPrice,
      timestamp: new Date()
    };

    this.copyTrades.set(copyTrade.id, copyTrade);
    
    // زيادة عدد النسخ للإشارة
    signal.copies += 1;

    return copyTrade;
  }

  // الحصول على إحصائيات التداول الاجتماعي
  async getSocialTradingStats(): Promise<{
    totalTraders: number;
    totalSignals: number;
    totalCopyTrades: number;
    avgSuccessRate: number;
    topPerformers: TraderProfile[];
  }> {
    const traders = Array.from(this.traders.values());
    const signals = Array.from(this.signals.values());
    const copyTrades = Array.from(this.copyTrades.values());

    const avgSuccessRate = traders.reduce((sum, trader) => sum + trader.winRate, 0) / traders.length;
    const topPerformers = traders
      .sort((a, b) => b.skillRating - a.skillRating)
      .slice(0, 5);

    return {
      totalTraders: traders.length,
      totalSignals: signals.length,
      totalCopyTrades: copyTrades.length,
      avgSuccessRate,
      topPerformers
    };
  }

  // البحث عن متداولين
  async searchTraders(query: string, filters?: {
    level?: string;
    specialization?: string;
    riskLevel?: string;
    minWinRate?: number;
  }): Promise<TraderProfile[]> {
    let traders = Array.from(this.traders.values());

    // تطبيق البحث النصي
    if (query) {
      const searchQuery = query.toLowerCase();
      traders = traders.filter(trader => 
        trader.username.toLowerCase().includes(searchQuery) ||
        trader.displayName.toLowerCase().includes(searchQuery)
      );
    }

    // تطبيق المرشحات
    if (filters) {
      if (filters.level) {
        traders = traders.filter(trader => trader.level === filters.level);
      }
      if (filters.specialization) {
        traders = traders.filter(trader => trader.specialization.includes(filters.specialization));
      }
      if (filters.riskLevel) {
        traders = traders.filter(trader => trader.riskLevel === filters.riskLevel);
      }
      if (filters.minWinRate) {
        traders = traders.filter(trader => trader.winRate >= filters.minWinRate);
      }
    }

    return traders.sort((a, b) => b.skillRating - a.skillRating);
  }

  // إعجاب بإشارة
  async likeSignal(signalId: number): Promise<boolean> {
    const signal = this.signals.get(signalId);
    if (signal) {
      signal.likes += 1;
      return true;
    }
    return false;
  }

  // الحصول على أفضل الإشارات
  async getTrendingSignals(limit: number = 10): Promise<TradingSignal[]> {
    const signals = Array.from(this.signals.values())
      .sort((a, b) => (b.likes + b.copies) - (a.likes + a.copies))
      .slice(0, limit);

    return signals;
  }
}

export const socialTradingService = new SocialTradingService();