import { alphaVantageService } from './alpha-vantage-service';
import { newsAPIService } from './news-api-service';
import { fredAPIService } from './fred-api-service';
import { ultraAdvancedAI } from './ultra-advanced-ai-analytics';

interface EnhancedMarketData {
  symbol: string;
  realTimePrice: number;
  priceChange: number;
  priceChangePercent: number;
  technicalIndicators: {
    rsi?: number;
    macd?: number;
    signal?: 'BUY' | 'SELL' | 'HOLD';
  };
  fundamentalData: {
    sentiment: number;
    newsCount: number;
    economicImpact: 'HIGH' | 'MEDIUM' | 'LOW';
  };
  externalSources: {
    alphaVantage: boolean;
    newsAPI: boolean;
    fredAPI: boolean;
  };
  confidence: number;
  lastUpdated: string;
}

interface ComprehensiveAnalysis {
  symbol: string;
  recommendation: 'BUY' | 'SELL' | 'HOLD';
  confidence: number;
  reasoning: string[];
  dataQuality: number;
  sources: string[];
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH';
  timeframe: string;
  expectedReturn: number;
  stopLoss: number;
  takeProfit: number;
  marketContext: {
    economicSentiment: number;
    newsSentiment: number;
    technicalStrength: number;
  };
}

class EnhancedDataIntegrationService {
  private cache = new Map<string, any>();
  private cacheExpiry = 300000; // 5 minutes

  constructor() {
    console.log('🚀 Enhanced Data Integration Service initialized');
  }

  private isCacheValid(key: string): boolean {
    const cached = this.cache.get(key);
    if (!cached) return false;
    return Date.now() - cached.timestamp < this.cacheExpiry;
  }

  private setCache(key: string, data: any): void {
    this.cache.set(key, {
      data,
      timestamp: Date.now()
    });
  }

  private getCache(key: string): any {
    const cached = this.cache.get(key);
    return cached ? cached.data : null;
  }

  async getEnhancedMarketData(symbol: string): Promise<EnhancedMarketData | null> {
    const cacheKey = `enhanced_market_${symbol}`;
    
    if (this.isCacheValid(cacheKey)) {
      return this.getCache(cacheKey);
    }

    console.log(`📊 Fetching enhanced market data for ${symbol}`);

    try {
      // Parallel data fetching from all sources
      const [alphaVantageData, newsData, economicData] = await Promise.allSettled([
        alphaVantageService.getComprehensiveMarketData(symbol),
        newsAPIService.getNewsForSymbol(symbol),
        fredAPIService.getMarketMoodFromEconomicData()
      ]);

      // Process Alpha Vantage data
      const avData = alphaVantageData.status === 'fulfilled' ? alphaVantageData.value : null;
      const realTimePrice = avData?.quote?.price || 0;
      const priceChange = avData?.quote?.change || 0;
      const priceChangePercent = avData?.quote?.changePercent || 0;

      // Process technical indicators
      const technicalIndicators = {
        rsi: avData?.technicalIndicators?.rsi?.value,
        macd: avData?.technicalIndicators?.macd?.value,
        signal: this.deriveTechnicalSignal(avData?.technicalIndicators)
      };

      // Process news sentiment
      const newsArticles = newsData.status === 'fulfilled' ? newsData.value : [];
      const newsSentiment = this.calculateNewsSentiment(newsArticles);

      // Process economic data
      const econData = economicData.status === 'fulfilled' ? economicData.value : null;
      const economicSentiment = econData?.overallSentiment || 0;

      // Determine fundamental impact
      const fundamentalData = {
        sentiment: (newsSentiment + economicSentiment) / 2,
        newsCount: newsArticles.length,
        economicImpact: this.assessEconomicImpact(economicSentiment, newsArticles.length)
      };

      // Check source availability
      const externalSources = {
        alphaVantage: !!avData,
        newsAPI: newsArticles.length > 0,
        fredAPI: !!econData
      };

      // Calculate overall confidence
      const confidence = this.calculateDataConfidence(externalSources, fundamentalData, technicalIndicators);

      const enhancedData: EnhancedMarketData = {
        symbol,
        realTimePrice,
        priceChange,
        priceChangePercent,
        technicalIndicators,
        fundamentalData,
        externalSources,
        confidence,
        lastUpdated: new Date().toISOString()
      };

      this.setCache(cacheKey, enhancedData);
      
      console.log(`✅ Enhanced data for ${symbol}: Price=${realTimePrice}, Confidence=${confidence}%`);
      
      return enhancedData;
    } catch (error) {
      console.error(`❌ Error fetching enhanced data for ${symbol}:`, error);
      return null;
    }
  }

  private deriveTechnicalSignal(indicators: any): 'BUY' | 'SELL' | 'HOLD' {
    if (!indicators) return 'HOLD';

    let signals = 0;
    let totalSignals = 0;

    if (indicators.rsi) {
      totalSignals++;
      if (indicators.rsi.signal === 'BUY') signals++;
      else if (indicators.rsi.signal === 'SELL') signals--;
    }

    if (indicators.macd) {
      totalSignals++;
      if (indicators.macd.signal === 'BUY') signals++;
      else if (indicators.macd.signal === 'SELL') signals--;
    }

    if (totalSignals === 0) return 'HOLD';

    const signalStrength = signals / totalSignals;
    if (signalStrength > 0.5) return 'BUY';
    if (signalStrength < -0.5) return 'SELL';
    return 'HOLD';
  }

  private calculateNewsSentiment(articles: any[]): number {
    if (articles.length === 0) return 0;

    const totalSentiment = articles.reduce((sum, article) => sum + (article.sentiment || 0), 0);
    return totalSentiment / articles.length;
  }

  private assessEconomicImpact(sentiment: number, newsCount: number): 'HIGH' | 'MEDIUM' | 'LOW' {
    if (Math.abs(sentiment) > 0.5 && newsCount > 5) return 'HIGH';
    if (Math.abs(sentiment) > 0.3 || newsCount > 3) return 'MEDIUM';
    return 'LOW';
  }

  private calculateDataConfidence(sources: any, fundamental: any, technical: any): number {
    let confidence = 0;
    let factors = 0;

    // Source availability (40% weight)
    const sourceCount = Object.values(sources).filter(Boolean).length;
    confidence += (sourceCount / 3) * 40;
    factors += 40;

    // Data richness (30% weight)
    if (fundamental.newsCount > 0) confidence += 15;
    if (technical.rsi !== undefined) confidence += 15;
    factors += 30;

    // Sentiment strength (30% weight)
    const sentimentStrength = Math.abs(fundamental.sentiment);
    confidence += sentimentStrength * 30;
    factors += 30;

    return Math.round((confidence / factors) * 100);
  }

  async generateComprehensiveAnalysis(symbol: string): Promise<ComprehensiveAnalysis | null> {
    const cacheKey = `comprehensive_analysis_${symbol}`;
    
    if (this.isCacheValid(cacheKey)) {
      return this.getCache(cacheKey);
    }

    console.log(`🧠 Generating comprehensive analysis for ${symbol}`);

    try {
      // Get enhanced market data
      const marketData = await this.getEnhancedMarketData(symbol);
      if (!marketData) return null;

      // Get AI analysis
      const aiAnalysis = await ultraAdvancedAI.generateUltraAdvancedAnalysis(symbol, {
        includeExternalData: true,
        enhancedMode: true
      });

      // Combine all data sources
      const reasoning: string[] = [];
      const sources: string[] = [];
      let confidence = marketData.confidence;

      // Technical analysis reasoning
      if (marketData.technicalIndicators.signal !== 'HOLD') {
        reasoning.push(
          `التحليل التقني يشير إلى ${marketData.technicalIndicators.signal === 'BUY' ? 'شراء' : 'بيع'} بناءً على RSI و MACD`
        );
        sources.push('Alpha Vantage Technical Indicators');
      }

      // Fundamental analysis reasoning
      if (Math.abs(marketData.fundamentalData.sentiment) > 0.2) {
        const sentimentType = marketData.fundamentalData.sentiment > 0 ? 'إيجابية' : 'سلبية';
        reasoning.push(
          `تحليل الأخبار الاقتصادية يُظهر مشاعر ${sentimentType} (${marketData.fundamentalData.newsCount} مقال)`
        );
        sources.push('NewsAPI + FRED Economic Data');
      }

      // AI analysis integration
      if (aiAnalysis?.ensemblePrediction) {
        reasoning.push(
          `نموذج الذكاء الاصطناعي المتقدم يتوقع ${aiAnalysis.ensemblePrediction.predictedOutcome} بثقة ${aiAnalysis.ensemblePrediction.consensusScore}%`
        );
        sources.push('Ultra-Advanced AI Analytics');
        
        // Use AI confidence if higher
        confidence = Math.max(confidence, aiAnalysis.ensemblePrediction.consensusScore);
      }

      // Determine final recommendation
      const recommendation = this.determineRecommendation(
        marketData.technicalIndicators.signal,
        marketData.fundamentalData.sentiment,
        aiAnalysis?.ensemblePrediction?.predictedOutcome
      );

      // Calculate risk metrics
      const riskLevel = this.calculateRiskLevel(marketData, aiAnalysis);
      const expectedReturn = this.calculateExpectedReturn(marketData, aiAnalysis);
      const { stopLoss, takeProfit } = this.calculateRiskManagement(marketData, recommendation);

      const analysis: ComprehensiveAnalysis = {
        symbol,
        recommendation,
        confidence: Math.round(confidence),
        reasoning,
        dataQuality: Math.round((sources.length / 3) * 100),
        sources,
        riskLevel,
        timeframe: '1-4 hours',
        expectedReturn,
        stopLoss,
        takeProfit,
        marketContext: {
          economicSentiment: marketData.fundamentalData.sentiment,
          newsSentiment: marketData.fundamentalData.sentiment,
          technicalStrength: marketData.technicalIndicators.rsi ? marketData.technicalIndicators.rsi / 100 : 0.5
        }
      };

      this.setCache(cacheKey, analysis);
      
      console.log(`✅ Comprehensive analysis for ${symbol}: ${recommendation} (${confidence}% confidence)`);
      
      return analysis;
    } catch (error) {
      console.error(`❌ Error generating comprehensive analysis for ${symbol}:`, error);
      return null;
    }
  }

  private determineRecommendation(
    technicalSignal: 'BUY' | 'SELL' | 'HOLD',
    fundamentalSentiment: number,
    aiPrediction?: string
  ): 'BUY' | 'SELL' | 'HOLD' {
    const signals = [];
    
    if (technicalSignal !== 'HOLD') signals.push(technicalSignal);
    if (fundamentalSentiment > 0.3) signals.push('BUY');
    else if (fundamentalSentiment < -0.3) signals.push('SELL');
    if (aiPrediction && aiPrediction !== 'HOLD') signals.push(aiPrediction);

    if (signals.length === 0) return 'HOLD';

    const buyCount = signals.filter(s => s === 'BUY').length;
    const sellCount = signals.filter(s => s === 'SELL').length;

    if (buyCount > sellCount) return 'BUY';
    if (sellCount > buyCount) return 'SELL';
    return 'HOLD';
  }

  private calculateRiskLevel(marketData: EnhancedMarketData, aiAnalysis: any): 'LOW' | 'MEDIUM' | 'HIGH' {
    let riskScore = 0;

    // Price volatility
    if (Math.abs(marketData.priceChangePercent) > 2) riskScore += 2;
    else if (Math.abs(marketData.priceChangePercent) > 1) riskScore += 1;

    // News impact
    if (marketData.fundamentalData.economicImpact === 'HIGH') riskScore += 2;
    else if (marketData.fundamentalData.economicImpact === 'MEDIUM') riskScore += 1;

    // AI risk assessment
    if (aiAnalysis?.ensemblePrediction?.riskMetrics?.volatility > 0.02) riskScore += 2;
    else if (aiAnalysis?.ensemblePrediction?.riskMetrics?.volatility > 0.01) riskScore += 1;

    if (riskScore >= 4) return 'HIGH';
    if (riskScore >= 2) return 'MEDIUM';
    return 'LOW';
  }

  private calculateExpectedReturn(marketData: EnhancedMarketData, aiAnalysis: any): number {
    let expectedReturn = Math.abs(marketData.priceChangePercent) * 0.5;
    
    if (aiAnalysis?.ensemblePrediction?.riskMetrics?.expectedReturn) {
      expectedReturn = (expectedReturn + aiAnalysis.ensemblePrediction.riskMetrics.expectedReturn) / 2;
    }

    return Math.round(expectedReturn * 100) / 100;
  }

  private calculateRiskManagement(marketData: EnhancedMarketData, recommendation: string): { stopLoss: number; takeProfit: number } {
    const currentPrice = marketData.realTimePrice;
    const volatility = Math.abs(marketData.priceChangePercent) / 100;
    
    let stopLossPercent = Math.max(0.5, volatility * 2); // Minimum 0.5% stop loss
    let takeProfitPercent = stopLossPercent * 2; // 2:1 risk-reward ratio

    if (recommendation === 'BUY') {
      return {
        stopLoss: Math.round((currentPrice * (1 - stopLossPercent / 100)) * 100000) / 100000,
        takeProfit: Math.round((currentPrice * (1 + takeProfitPercent / 100)) * 100000) / 100000
      };
    } else if (recommendation === 'SELL') {
      return {
        stopLoss: Math.round((currentPrice * (1 + stopLossPercent / 100)) * 100000) / 100000,
        takeProfit: Math.round((currentPrice * (1 - takeProfitPercent / 100)) * 100000) / 100000
      };
    }

    return { stopLoss: currentPrice, takeProfit: currentPrice };
  }

  async getMarketOverview(): Promise<any> {
    console.log('📈 Generating market overview from all sources');

    try {
      const [economicOverview, marketSentiment, newsHeadlines] = await Promise.allSettled([
        fredAPIService.getMarketMoodFromEconomicData(),
        newsAPIService.getMarketSentiment(),
        newsAPIService.getTopHeadlines('us', 'business')
      ]);

      return {
        economicData: economicOverview.status === 'fulfilled' ? economicOverview.value : null,
        marketSentiment: marketSentiment.status === 'fulfilled' ? marketSentiment.value : null,
        topNews: newsHeadlines.status === 'fulfilled' ? newsHeadlines.value?.slice(0, 5) : [],
        timestamp: new Date().toISOString()
      };
    } catch (error) {
      console.error('❌ Error generating market overview:', error);
      return null;
    }
  }

  async healthCheckAllSources(): Promise<any> {
    console.log('🔍 Checking health of all external data sources');

    const [alphaVantageHealth, newsAPIHealth, fredAPIHealth] = await Promise.allSettled([
      alphaVantageService.checkApiHealth(),
      newsAPIService.checkApiHealth(),
      fredAPIService.checkApiHealth()
    ]);

    return {
      alphaVantage: {
        status: alphaVantageHealth.status === 'fulfilled' ? (alphaVantageHealth.value ? 'HEALTHY' : 'ERROR') : 'ERROR',
        lastChecked: new Date().toISOString()
      },
      newsAPI: {
        status: newsAPIHealth.status === 'fulfilled' ? (newsAPIHealth.value ? 'HEALTHY' : 'ERROR') : 'ERROR',
        lastChecked: new Date().toISOString()
      },
      fredAPI: {
        status: fredAPIHealth.status === 'fulfilled' ? (fredAPIHealth.value ? 'HEALTHY' : 'ERROR') : 'ERROR',
        lastChecked: new Date().toISOString()
      }
    };
  }

  // Clean cache periodically
  cleanCache(): void {
    const now = Date.now();
    for (const [key, value] of this.cache.entries()) {
      if (now - value.timestamp > this.cacheExpiry) {
        this.cache.delete(key);
      }
    }
  }
}

export const enhancedDataIntegration = new EnhancedDataIntegrationService();
export default EnhancedDataIntegrationService;