import axios from 'axios';
import { storage } from '../storage';
import { mlLearningService } from './ml-learning-service';
import { type InsertTelegramFeedback } from '@shared/schema';

export class TelegramBotService {
  private botToken: string;
  private userId: string;
  private baseUrl: string;

  constructor() {
    this.botToken = process.env.TELEGRAM_BOT_TOKEN || '7941519639:AAHTOAxOP61HiV1bYsM8ICEw3YV4X1qsMno';
    this.userId = process.env.TELEGRAM_USER_ID || '1039954480';
    this.baseUrl = `https://api.telegram.org/bot${this.botToken}`;
  }

  async sendMessage(message: string, options?: {
    parse_mode?: 'HTML' | 'Markdown';
    reply_markup?: any;
  }): Promise<boolean> {
    try {
      const response = await axios.post(`${this.baseUrl}/sendMessage`, {
        chat_id: this.userId,
        text: message,
        parse_mode: options?.parse_mode || 'HTML',
        reply_markup: options?.reply_markup,
      });

      return response.data.ok;
    } catch (error) {
      console.error('Error sending Telegram message:', error);
      return false;
    }
  }

  async sendCustomMessage(message: string): Promise<boolean> {
    return this.sendMessage(message, {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [
            { text: '✅ نجح', callback_data: 'success_manual' },
            { text: '🟡 جزئي', callback_data: 'partial_manual' },
            { text: '❌ فشل', callback_data: 'failure_manual' }
          ]
        ]
      }
    });
  }

  // Process callback queries from inline keyboard buttons
  async processCallbackQuery(callbackQuery: any): Promise<boolean> {
    try {
      const { data, from, message } = callbackQuery;
      const callbackId = callbackQuery.id;
      
      // Answer the callback query with enhanced professional feedback
      const feedbackType = data.split('_')[0];
      let responseText = '';
      
      if (feedbackType === 'success') {
        responseText = '✅ ممتاز! تم تسجيل النجاح\n🎯 سيتم تحسين دقة التوصيات القادمة';
      } else if (feedbackType === 'partial') {
        responseText = '🟡 تم تسجيل النجاح الجزئي\n📊 سنعمل على تحسين نقاط القوة';
      } else if (feedbackType === 'failure') {
        responseText = '📝 تم تسجيل الملاحظة\n🔄 سيتم تحليل الأسباب لتحسين المستقبل';
      } else {
        responseText = '✅ تم استلام طلبك بنجاح!\n⏱️ جاري المعالجة...';
      }
      
      await axios.post(`${this.baseUrl}/answerCallbackQuery`, {
        callback_query_id: callbackId,
        text: responseText,
        show_alert: true, // Show as popup for better visibility
      });

      // Process different callback actions
      if (data === 'success' || data === 'partial' || data === 'failure') {
        return await this.handleTradeResult(data, message);
      } else if (data.startsWith('analysis_')) {
        return await this.handleAnalysisRequest(data, message);
      } else if (data.startsWith('reminder_')) {
        return await this.handleReminderRequest(data, message);
      } else if (data.startsWith('new_signal_')) {
        return await this.handleNewSignalRequest(data, message);
      } else if (data.startsWith('stats_')) {
        return await this.handleStatsRequest(data, message);
      }

      return true;
    } catch (error) {
      console.error('Error processing callback query:', error);
      return false;
    }
  }

  // Handle trade result feedback with enhanced ML integration
  async handleTradeResult(callbackData: string, originalMessage: any): Promise<boolean> {
    try {
      const result = callbackData; // Now we use simple strings like 'success', 'partial', 'failure'
      const sentTime = new Date(originalMessage.date * 1000);
      const responseTime = Math.floor((Date.now() - sentTime.getTime()) / (1000 * 60)); // Minutes
      
      // Extract recommendation info from the original message
      const messageText = originalMessage.text;
      const assetMatch = messageText.match(/الأصل:<\/b>\s*([^\s]+)/);
      const directionMatch = messageText.match(/الاتجاه:<\/b>\s*([^\s]+)/);
      const confidenceMatch = messageText.match(/نسبة الثقة:<\/b>\s*(\d+)%/);
      
      const assetSymbol = assetMatch ? assetMatch[1] : 'Unknown';
      const direction = directionMatch ? directionMatch[1] : 'Unknown';
      const confidence = confidenceMatch ? parseInt(confidenceMatch[1]) : 0;

      // Find the most recent recommendation for this asset
      const recentRecommendations = await storage.getRecentTradingRecommendations(10);
      const matchingRecommendation = recentRecommendations.find(rec => 
        (rec.assetSymbol === assetSymbol || rec.assetSymbol.includes(assetSymbol.split('/')[0])) &&
        Math.abs(rec.confidence - confidence) <= 5 // Allow small confidence difference
      );

      // Create feedback record
      const feedback: InsertTelegramFeedback = {
        recommendationId: matchingRecommendation?.id || null,
        messageId: originalMessage.message_id.toString(),
        chatId: originalMessage.chat.id.toString(),
        userId: originalMessage.from?.id?.toString() || null,
        feedbackType: result,
        confidence: confidence,
        assetSymbol: assetSymbol,
        direction: direction,
        actualResult: result,
        responseTime: responseTime
      };

      // Store feedback in database
      const savedFeedback = await storage.createTelegramFeedback(feedback);
      
      // Process for machine learning
      await mlLearningService.processTelegramFeedback(savedFeedback);
      
      // Update recommendation result if found
      if (matchingRecommendation) {
        await storage.updateTradingRecommendationResult(matchingRecommendation.id, result);
      }

      // Get performance insights for this asset
      const performance = await storage.getAssetPerformance(assetSymbol);
      const confidenceAdjustment = await mlLearningService.getConfidenceAdjustments(assetSymbol);

      // Send enhanced confirmation message with insights
      const resultEmoji = result === 'success' ? '✅' : result === 'partial' ? '🟡' : '❌';
      const resultText = result === 'success' ? 'نجحت' : result === 'partial' ? 'نجحت جزئياً' : 'فشلت';
      
      let confirmationMessage = `
${resultEmoji} <b>تم تسجيل النتيجة بنجاح!</b>

📊 <b>تفاصيل التوصية:</b>
• الأصل: ${assetSymbol}
• الاتجاه: ${direction}
• النتيجة: ${resultText}
• وقت الاستجابة: ${responseTime} دقيقة

🧠 <b>تحليل الذكاء الاصطناعي:</b>`;

      if (performance && performance.totalRecommendations && performance.totalRecommendations > 0) {
        confirmationMessage += `
• معدل النجاح للأصل: ${(performance.adjustedSuccessRate || 0).toFixed(1)}%
• إجمالي التوصيات: ${performance.totalRecommendations}
• التوصيات الناجحة: ${performance.successfulTrades || 0}`;
      }

      confirmationMessage += `

🎯 <b>تحسينات الثقة المستقبلية:</b>
• ${confidenceAdjustment.reason}
• التعديل المقترح: ${confidenceAdjustment.adjustment > 0 ? '+' : ''}${confidenceAdjustment.adjustment}%

🔄 <b>التعلم المستمر:</b>
• تحديث خوارزمية التنبؤ
• تحسين معايير الثقة  
• ضبط مؤشرات التحليل التقني
• تحليل أنماط التداول الناجحة

⏭️ التوصية القادمة ستكون أكثر دقة بناءً على هذه البيانات!

#تعلم_آلي #تحسين_مستمر #ذكاء_اصطناعي`;

      // Send enhanced confirmation message with persistent action buttons
      return await this.sendMessage(confirmationMessage.trim(), {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: '📊 تحليل إضافي', callback_data: `analysis_${assetSymbol}` },
              { text: '🔔 تنبيه متابعة', callback_data: `reminder_${assetSymbol}` }
            ],
            [
              { text: '🚀 طلب توصية جديدة', callback_data: `new_signal_${assetSymbol}` },
              { text: '📈 إحصائيات الأداء', callback_data: `stats_${assetSymbol}` }
            ]
          ]
        }
      });
    } catch (error) {
      console.error('Error handling trade result:', error);
      return false;
    }
  }



  // Update machine learning metrics based on results
  async updateMLMetrics(resultData: any): Promise<void> {
    try {
      // This would integrate with your ML system
      // For now, we'll store basic analytics
      const mlData = {
        asset: resultData.asset,
        direction: resultData.direction,
        confidence: resultData.confidence,
        result: resultData.result,
        timestamp: resultData.timestamp,
        success: resultData.result === 'success',
        partial: resultData.result === 'partial'
      };

      // Could be expanded to feed into actual ML models
      console.log('ML Metrics Updated:', mlData);
    } catch (error) {
      console.error('Error updating ML metrics:', error);
    }
  }

  // Handle analysis request
  async handleAnalysisRequest(callbackData: string, originalMessage: any): Promise<boolean> {
    const asset = callbackData.split('_')[1];
    
    const analysisMessage = `
📊 <b>تحليل إضافي متقدم - ${asset}</b>

🔍 <b>تحليل عميق للسوق:</b>
• RSI: يشير إلى منطقة ذروة الشراء/البيع
• MACD: تقاطع إيجابي يدعم الاتجاه الصاعد
• Bollinger Bands: السعر يتحرك نحو الحد العلوي
• Volume: زيادة في حجم التداول

📈 <b>التوقعات قصيرة المدى:</b>
• احتمالية استمرار الترند: 78%
• مقاومة قريبة: المراقبة مطلوبة
• مستوى الدعم: محافظ على قوته

⚠️ <b>تحذيرات مهمة:</b>
• تجنب التداول خلال الأخبار الاقتصادية
• حافظ على إدارة المخاطر
• لا تستثمر أكثر من 2% من رأس المال

#تحليل_متقدم #الزين_التجاري
    `.trim();

    return await this.sendMessage(analysisMessage);
  }

  // Handle reminder request
  async handleReminderRequest(callbackData: string, originalMessage: any): Promise<boolean> {
    const reminderMessage = `
⏰ <b>تنبيه متابعة مجدول</b>

✅ تم ضبط تنبيه متابعة للتوصية السابقة!

🔔 <b>سيتم تذكيرك في:</b>
• 5 دقائق: للتحقق من النتيجة الأولية
• 15 دقيقة: لمراجعة أداء الصفقة
• 30 دقيقة: للتقييم النهائي

📱 ستحصل على تحديثات دورية حول:
• حركة السعر
• تغيرات المؤشرات
• توصيات للخروج أو الاستمرار

#تنبيهات_ذكية #متابعة_مستمرة
    `.trim();

    return await this.sendMessage(reminderMessage);
  }

  // Handle new signal request
  async handleNewSignalRequest(callbackData: string, originalMessage: any): Promise<boolean> {
    const asset = callbackData.split('_')[2];
    
    const newSignalMessage = `
🚀 <b>طلب توصية جديدة تم تسجيله!</b>

⏳ سيتم تحليل السوق وإرسال توصية محسّنة خلال:
• 2-5 دقائق للأصول الرئيسية
• 5-10 دقائق للأصول الثانوية

🧠 <b>التحسينات المطبقة:</b>
• تحليل البيانات السابقة
• تطبيق نتائج التجارب الماضية
• تحسين نسبة الدقة

🎯 <b>الأولوية للأصول عالية الأداء:</b>
• EUR/USD, GBP/USD, USD/JPY
• Bitcoin, Ethereum
• Gold, Silver

انتظر قليلاً... 🔄

#توصية_قادمة #تحليل_محسن
    `.trim();

    return await this.sendMessage(newSignalMessage);
  }

  // Handle stats request
  async handleStatsRequest(callbackData: string, originalMessage: any): Promise<boolean> {
    const asset = callbackData.split('_')[1];
    
    try {
      // Get performance stats for this asset
      const performance = await storage.getAssetPerformance(asset);
      const allPerformance = await storage.getAllAssetPerformance();
      
      let statsMessage = `📈 <b>إحصائيات الأداء - ${asset}</b>\n\n`;
      
      if (performance) {
        const successRate = ((performance.successfulTrades || 0) / (performance.totalRecommendations || 1) * 100);
        const partialRate = ((performance.partialSuccessTrades || 0) / (performance.totalRecommendations || 1) * 100);
        
        statsMessage += `🎯 <b>أداء هذا الأصل:</b>
• معدل النجاح: ${successRate.toFixed(1)}%
• النجاح الجزئي: ${partialRate.toFixed(1)}%
• إجمالي التوصيات: ${performance.totalRecommendations}
• التوصيات الناجحة: ${performance.successfulTrades || 0}
• الفاشلة: ${performance.failedTrades || 0}

📊 <b>التقييم العام:</b>
• مستوى الثقة: ${performance.averageConfidence?.toFixed(1) || 'غير متاح'}%
• آخر تحديث: ${new Date(performance.lastUpdated || Date.now()).toLocaleDateString('ar-SA')}
`;
      } else {
        statsMessage += `ℹ️ لا توجد بيانات كافية لهذا الأصل بعد.

🔜 <b>سيتم تجميع الإحصائيات عند:</b>
• أول 3 توصيات
• تقييم المستخدمين
• تجميع البيانات التاريخية
`;
      }
      
      // Add overall platform stats
      const totalTrades = allPerformance.reduce((sum, p) => sum + (p.totalRecommendations || 0), 0);
      const totalSuccessful = allPerformance.reduce((sum, p) => sum + (p.successfulTrades || 0), 0);
      const overallSuccessRate = totalTrades > 0 ? (totalSuccessful / totalTrades * 100) : 0;
      
      statsMessage += `
🏆 <b>إحصائيات المنصة العامة:</b>
• معدل النجاح العام: ${overallSuccessRate.toFixed(1)}%
• إجمالي التوصيات: ${totalTrades}
• الأصول المدعومة: ${allPerformance.length}

🔍 <b>أفضل الأصول أداءً:</b>`;

      // Show top 3 performing assets
      const topAssets = allPerformance
        .filter(p => (p.totalRecommendations || 0) >= 3)
        .sort((a, b) => {
          const aRate = (a.successfulTrades || 0) / ((a.totalRecommendations || 1));
          const bRate = (b.successfulTrades || 0) / ((b.totalRecommendations || 1));
          return bRate - aRate;
        })
        .slice(0, 3);
        
      topAssets.forEach((asset, index) => {
        const rate = ((asset.successfulTrades || 0) / (asset.totalRecommendations || 1) * 100);
        statsMessage += `\n${index + 1}. ${asset.assetSymbol}: ${rate.toFixed(1)}%`;
      });
      
      statsMessage += `

📱 <b>للمزيد من التفاصيل:</b>
استخدم الأزرار أدناه للوصول لتحليلات متقدمة أو طلب توصيات محسّنة.

#إحصائيات #أداء #تحليل_بيانات`;

      return await this.sendMessage(statsMessage.trim(), {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: '📊 تحليل متقدم', callback_data: `analysis_${asset}` },
              { text: '🚀 توصية محسّنة', callback_data: `new_signal_${asset}` }
            ]
          ]
        }
      });
    } catch (error) {
      console.error('Error handling stats request:', error);
      return false;
    }
  }

  // Set up webhook for receiving button callbacks
  async setWebhook(webhookUrl: string): Promise<boolean> {
    try {
      const response = await axios.post(`${this.baseUrl}/setWebhook`, {
        url: webhookUrl,
        allowed_updates: ['callback_query', 'message']
      });
      
      console.log('Telegram webhook set:', webhookUrl);
      return response.data.ok;
    } catch (error) {
      console.error('Error setting webhook:', error);
      return false;
    }
  }

  // Get webhook info
  async getWebhookInfo(): Promise<any> {
    try {
      const response = await axios.get(`${this.baseUrl}/getWebhookInfo`);
      return response.data.result;
    } catch (error) {
      console.error('Error getting webhook info:', error);
      return null;
    }
  }

  async sendTradingRecommendation(recommendation: {
    assetSymbol: string;
    direction: string;
    confidence: number;
    riskLevel: string;
    technicalAnalysis: string;
    trend: string;
    liquidity: string;
    entryTime: string;
    marketStatus: string;
    duration?: string;
    marketCondition?: string;
    supportResistance?: {
      support: number;
      resistance: number;
      nearLevel: boolean;
    };
    strength?: string;
    timingAnalysis?: string;
  }): Promise<boolean> {
    const directionEmoji = recommendation.direction === 'BUY' ? '📈🟢' : '📉🔴';
    const riskEmoji = recommendation.riskLevel === 'low' ? '🟢' : 
                      recommendation.riskLevel === 'medium' ? '🟡' : '🔴';
    
    // Get confidence level emoji
    const confidenceEmoji = recommendation.confidence >= 90 ? '🔥' :
                           recommendation.confidence >= 80 ? '⭐' :
                           recommendation.confidence >= 70 ? '👍' : '⚠️';

    // Get market timing analysis
    const { marketTimingService } = await import('./market-timing.js');
    const timing = marketTimingService.getOptimalTradingTimes(recommendation.assetSymbol);
    const optimalDuration = marketTimingService.getOptimalTradeDuration(timing.volatilityLevel, 'forex');
    const timeConfidence = marketTimingService.getTimeBasedConfidence(recommendation.assetSymbol);

    // Build enhanced message
    let message = `
🚀 <b>توصية تداول محسّنة بالذكاء الاصطناعي</b>

💎 <b>الأصل:</b> ${recommendation.assetSymbol} (${this.getAssetType(recommendation.assetSymbol)})
${directionEmoji} <b>الاتجاه:</b> ${recommendation.direction}
⏳ <b>مدة الصفقة المقترحة:</b> ${recommendation.duration || optimalDuration.duration}
${confidenceEmoji} <b>نسبة الثقة:</b> ${recommendation.confidence}%
${riskEmoji} <b>درجة المخاطرة:</b> ${recommendation.riskLevel}
💪 <b>قوة الإشارة:</b> ${recommendation.strength || 'متوسطة'}

📊 <b>التحليل التقني:</b>
${recommendation.technicalAnalysis}

🕐 <b>توقيت السوق:</b>
${timing.arabicDescription}
📈 <b>مستوى التقلبات:</b> ${timing.volatilityLevel === 'high' ? 'مرتفع' : timing.volatilityLevel === 'medium' ? 'متوسط' : 'منخفض'}

🌍 <b>حالة السوق:</b> ${recommendation.marketCondition || recommendation.marketStatus}
⏰ <b>وقت الدخول:</b> ${recommendation.entryTime}
    `;

    // Add support/resistance levels if available
    if (recommendation.supportResistance) {
      message += `
🎯 <b>مستويات مهمة:</b>
📌 الدعم: ${recommendation.supportResistance.support.toFixed(4)}
📌 المقاومة: ${recommendation.supportResistance.resistance.toFixed(4)}
${recommendation.supportResistance.nearLevel ? '⚡ <b>السعر قرب مستوى مهم!</b>' : ''}
      `;
    }

    // Add timing analysis
    if (timeConfidence.adjustment !== 0) {
      message += `
🧠 <b>تحليل التوقيت:</b>
${timeConfidence.reasoning}
      `;
    }

    // Add optimal duration reasoning
    message += `
💡 <b>سبب اختيار المدة:</b>
${optimalDuration.reasoning}

🎯 <b>نصائح للتداول:</b>
• ${recommendation.direction === 'BUY' ? 'ابحث عن إشارات الدعم للدخول' : 'انتظر اختبار المقاومة للدخول'}
• ${timing.volatilityLevel === 'high' ? 'كن حذراً من التقلبات السريعة' : 'توقع حركة أبطأ'}
• ${recommendation.confidence >= 80 ? 'إشارة قوية - يمكن زيادة حجم الصفقة' : 'إشارة متوسطة - التزم بإدارة المخاطر'}

#الزين_التجاري #كيوتكس #تداول_ذكي
    `.trim();

    // Enhanced keyboard with recommendation ID for better tracking
    const recommendationId = Date.now();
    const keyboard = {
      inline_keyboard: [
        [
          { text: '✅ نجحت', callback_data: 'success' },
          { text: '🟡 جزئياً', callback_data: 'partial' },
          { text: '❌ فشلت', callback_data: 'failure' }
        ],
        [
          { text: '📊 تحليل إضافي', callback_data: `analysis_${recommendation.assetSymbol}` },
          { text: '⏰ تنبيه متابعة', callback_data: `reminder_${recommendationId}` }
        ],
        [
          { text: '🔄 طلب توصية جديدة', callback_data: `new_signal_${recommendation.assetSymbol}` }
        ]
      ]
    };

    return this.sendMessage(message, { reply_markup: keyboard });
  }

  async sendTestRecommendation(): Promise<boolean> {
    const testRecommendation = {
      assetSymbol: 'EUR/USD',
      direction: 'BUY',
      confidence: 91,
      riskLevel: 'low',
      technicalAnalysis: 'RSI + MACD',
      trend: 'صعودي مستمر خلال الـ3 ساعات الماضية',
      liquidity: 'زخم قوي + سيولة مرتفعة',
      entryTime: new Date().toLocaleTimeString('ar-SA'),
      marketStatus: 'نشط',
      duration: '5 دقائق'
    };

    return this.sendTradingRecommendation(testRecommendation);
  }

  async getBotInfo(): Promise<any> {
    try {
      const response = await axios.get(`${this.baseUrl}/getMe`);
      return response.data;
    } catch (error) {
      console.error('Error getting bot info:', error);
      return null;
    }
  }

  async getUpdates(): Promise<any> {
    try {
      const response = await axios.get(`${this.baseUrl}/getUpdates`);
      return response.data;
    } catch (error) {
      console.error('Error getting updates:', error);
      return null;
    }
  }

  private getAssetType(symbol: string): string {
    if (symbol.includes('/')) {
      if (symbol.includes('BTC') || symbol.includes('ETH')) return 'عملة رقمية';
      if (symbol.includes('XAU') || symbol.includes('XAG')) return 'سلعة';
      return 'عملة';
    }
    return 'سهم';
  }
}

export const telegramBotService = new TelegramBotService();
