import crypto from 'crypto';
import { products, licenses, commercialUsers, purchaseHistory } from '@shared/commercial-schema';
import { db } from '../db';
import { eq, and, or, desc, asc } from 'drizzle-orm';

export interface LicenseGenerationRequest {
  productId: string;
  quantity: number;
  keyType: 'trial' | 'full' | 'enterprise';
  validityDays?: number;
  maxUsageCount?: number;
  notes?: string;
  generatedBy: string;
}

export interface LicenseValidationResult {
  isValid: boolean;
  license?: any;
  product?: any;
  user?: any;
  error?: string;
  remainingUsage?: number;
  expiryDate?: Date;
}

export interface UsageLimits {
  dailySignals: number;
  monthlySignals: number;
  maxDevices: number;
  apiCalls: number;
  features: string[];
}

export class LicenseManager {
  
  async generateLicenseKeys(request: LicenseGenerationRequest): Promise<{ success: boolean; licenses?: string[]; error?: string }> {
    try {
      // Validate product exists
      const [product] = await db.select()
        .from(products)
        .where(eq(products.id, request.productId))
        .limit(1);

      if (!product) {
        return { success: false, error: 'المنتج غير موجود' };
      }

      const licenses: string[] = [];
      const validUntil = request.validityDays ? 
        new Date(Date.now() + request.validityDays * 24 * 60 * 60 * 1000) : 
        undefined;

      // Generate licenses in batch
      for (let i = 0; i < request.quantity; i++) {
        const licenseKey = this.generateLicenseKey(request.keyType);
        
        await db.insert(productKeys).values({
          productId: request.productId,
          licenseKey,
          keyType: request.keyType,
          validUntil,
          maxUsageCount: request.maxUsageCount,
          generatedBy: request.generatedBy,
          notes: request.notes,
          isValid: true,
          isActivated: false
        });

        licenses.push(licenseKey);
      }

      return { success: true, licenses };
    } catch (error) {
      console.error('License generation error:', error);
      return { success: false, error: 'فشل في إنشاء مفاتيح الترخيص' };
    }
  }

  async validateLicense(licenseKey: string, deviceFingerprint?: string): Promise<LicenseValidationResult> {
    try {
      // Find license
      const [license] = await db.select()
        .from(productKeys)
        .where(eq(productKeys.licenseKey, licenseKey))
        .limit(1);

      if (!license) {
        return { isValid: false, error: 'مفتاح الترخيص غير موجود' };
      }

      // Check if license is valid
      if (!license.isValid) {
        return { isValid: false, error: 'مفتاح الترخيص ملغي' };
      }

      // Check expiry
      if (license.validUntil && new Date() > license.validUntil) {
        return { isValid: false, error: 'مفتاح الترخيص منتهي الصلاحية' };
      }

      // Check usage limits
      if (license.maxUsageCount && license.usageCount >= license.maxUsageCount) {
        return { isValid: false, error: 'تم تجاوز حد الاستخدام للترخيص' };
      }

      // Get product details
      const [product] = await db.select()
        .from(products)
        .where(eq(products.id, license.productId))
        .limit(1);

      // Get user details if activated
      let user = null;
      if (license.userId) {
        [user] = await db.select()
          .from(commercialUsers)
          .where(eq(commercialUsers.id, license.userId))
          .limit(1);
      }

      const remainingUsage = license.maxUsageCount ? 
        license.maxUsageCount - (license.usageCount || 0) : 
        undefined;

      return {
        isValid: true,
        license,
        product,
        user,
        remainingUsage,
        expiryDate: license.validUntil
      };
    } catch (error) {
      console.error('License validation error:', error);
      return { isValid: false, error: 'فشل في التحقق من الترخيص' };
    }
  }

  async activateLicense(licenseKey: string, userId: string, deviceFingerprint?: string): Promise<{ success: boolean; error?: string }> {
    try {
      const validation = await this.validateLicense(licenseKey);
      
      if (!validation.isValid) {
        return { success: false, error: validation.error };
      }

      // Check if already activated by another user
      if (validation.license?.isActivated && validation.license?.userId !== userId) {
        return { success: false, error: 'مفتاح الترخيص مفعل بالفعل من قبل مستخدم آخر' };
      }

      // Activate license
      await db.update(productKeys)
        .set({
          isActivated: true,
          activatedAt: new Date(),
          activatedBy: userId,
          userId: userId,
          deviceFingerprint,
          usageCount: (validation.license?.usageCount || 0) + 1,
          lastUsedAt: new Date(),
          updatedAt: new Date()
        })
        .where(eq(productKeys.id, validation.license!.id));

      // Update user subscription if needed
      if (validation.product) {
        await this.updateUserSubscription(userId, validation.product);
      }

      return { success: true };
    } catch (error) {
      console.error('License activation error:', error);
      return { success: false, error: 'فشل في تفعيل الترخيص' };
    }
  }

  async revokeLicense(licenseKey: string, revokedBy: string, reason: string): Promise<{ success: boolean; error?: string }> {
    try {
      const [license] = await db.select()
        .from(productKeys)
        .where(eq(productKeys.licenseKey, licenseKey))
        .limit(1);

      if (!license) {
        return { success: false, error: 'مفتاح الترخيص غير موجود' };
      }

      await db.update(productKeys)
        .set({
          isValid: false,
          revokedAt: new Date(),
          revokedBy,
          revokeReason: reason,
          updatedAt: new Date()
        })
        .where(eq(productKeys.id, license.id));

      return { success: true };
    } catch (error) {
      console.error('License revocation error:', error);
      return { success: false, error: 'فشل في إلغاء الترخيص' };
    }
  }

  async getUserLicenses(userId: string): Promise<any[]> {
    try {
      const userLicenses = await db.select({
        license: productKeys,
        product: products
      })
      .from(productKeys)
      .leftJoin(products, eq(productKeys.productId, products.id))
      .where(eq(productKeys.userId, userId))
      .orderBy(desc(productKeys.createdAt));

      return userLicenses;
    } catch (error) {
      console.error('Error fetching user licenses:', error);
      return [];
    }
  }

  async getUsageLimits(userId: string): Promise<UsageLimits> {
    try {
      // Get user's active subscriptions/licenses
      const userLicenses = await this.getUserLicenses(userId);
      
      // Default limits for free users
      let limits: UsageLimits = {
        dailySignals: 5,
        monthlySignals: 50,
        maxDevices: 1,
        apiCalls: 100,
        features: ['basic_signals']
      };

      // Find the highest tier license
      for (const userLicense of userLicenses) {
        if (userLicense.license.isValid && userLicense.license.isActivated) {
          const productLimits = userLicense.product?.limits as any;
          if (productLimits) {
            limits = {
              dailySignals: Math.max(limits.dailySignals, productLimits.dailySignals || 0),
              monthlySignals: Math.max(limits.monthlySignals, productLimits.monthlySignals || 0),
              maxDevices: Math.max(limits.maxDevices, productLimits.maxDevices || 1),
              apiCalls: Math.max(limits.apiCalls, productLimits.apiCalls || 100),
              features: [...new Set([...limits.features, ...(productLimits.features || [])])]
            };
          }
        }
      }

      return limits;
    } catch (error) {
      console.error('Error getting usage limits:', error);
      return {
        dailySignals: 5,
        monthlySignals: 50,
        maxDevices: 1,
        apiCalls: 100,
        features: ['basic_signals']
      };
    }
  }

  async checkUsageQuota(userId: string, usageType: 'daily' | 'monthly'): Promise<{ allowed: boolean; used: number; limit: number }> {
    try {
      const [user] = await db.select()
        .from(commercialUsers)
        .where(eq(commercialUsers.id, userId))
        .limit(1);

      if (!user) {
        return { allowed: false, used: 0, limit: 0 };
      }

      const limits = await this.getUsageLimits(userId);
      
      if (usageType === 'daily') {
        const allowed = (user.dailySignalsUsed || 0) < limits.dailySignals;
        return { 
          allowed, 
          used: user.dailySignalsUsed || 0, 
          limit: limits.dailySignals 
        };
      } else {
        const allowed = (user.monthlySignalsUsed || 0) < limits.monthlySignals;
        return { 
          allowed, 
          used: user.monthlySignalsUsed || 0, 
          limit: limits.monthlySignals 
        };
      }
    } catch (error) {
      console.error('Error checking usage quota:', error);
      return { allowed: false, used: 0, limit: 0 };
    }
  }

  async incrementUsage(userId: string): Promise<void> {
    try {
      const today = new Date();
      const [user] = await db.select()
        .from(commercialUsers)
        .where(eq(commercialUsers.id, userId))
        .limit(1);

      if (!user) return;

      // Reset daily counter if it's a new day
      const lastSignalDate = user.lastSignalDate;
      const isNewDay = !lastSignalDate || 
        lastSignalDate.toDateString() !== today.toDateString();

      const dailyCount = isNewDay ? 1 : (user.dailySignalsUsed || 0) + 1;

      await db.update(commercialUsers)
        .set({
          dailySignalsUsed: dailyCount,
          monthlySignalsUsed: (user.monthlySignalsUsed || 0) + 1,
          totalSignalsUsed: (user.totalSignalsUsed || 0) + 1,
          lastSignalDate: today,
          updatedAt: new Date()
        })
        .where(eq(commercialUsers.id, userId));
    } catch (error) {
      console.error('Error incrementing usage:', error);
    }
  }

  private generateLicenseKey(keyType: string): string {
    const prefix = keyType === 'trial' ? 'TRL' : keyType === 'enterprise' ? 'ENT' : 'PRO';
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let result = prefix + '-';
    
    for (let i = 0; i < 3; i++) {
      if (i > 0) result += '-';
      for (let j = 0; j < 4; j++) {
        result += chars.charAt(Math.floor(Math.random() * chars.length));
      }
    }
    
    return result;
  }

  private async updateUserSubscription(userId: string, product: any): Promise<void> {
    try {
      const subscriptionEndDate = new Date();
      
      if (product.billingCycle === 'monthly') {
        subscriptionEndDate.setMonth(subscriptionEndDate.getMonth() + 1);
      } else if (product.billingCycle === 'yearly') {
        subscriptionEndDate.setFullYear(subscriptionEndDate.getFullYear() + 1);
      } else if (product.billingCycle === 'lifetime') {
        subscriptionEndDate.setFullYear(subscriptionEndDate.getFullYear() + 100);
      }

      await db.update(commercialUsers)
        .set({
          subscriptionStatus: 'active',
          subscriptionTier: product.category,
          subscriptionStartDate: new Date(),
          subscriptionEndDate,
          updatedAt: new Date()
        })
        .where(eq(commercialUsers.id, userId));
    } catch (error) {
      console.error('Error updating user subscription:', error);
    }
  }
}

export const licenseManager = new LicenseManager();