import { MarketAsset, TradingRecommendation, InsertTradingRecommendation } from '../../shared/schema';

interface EnhancedSignalData {
  symbol: string;
  timeframes: {
    '1m': MarketIndicators;
    '5m': MarketIndicators;
    '15m': MarketIndicators;
    '1h': MarketIndicators;
    '4h': MarketIndicators;
  };
  fundamentals: {
    economicEvents: EconomicEvent[];
    newsImpact: number;
    marketSentiment: number;
  };
  technicalScore: number;
  fundamentalScore: number;
  consensusScore: number;
}

interface MarketIndicators {
  rsi: number;
  macd: { value: number; signal: number; histogram: number };
  bollinger: { upper: number; middle: number; lower: number; position: number };
  stochastic: { k: number; d: number };
  williams: number;
  cci: number;
  momentum: number;
  volumeProfile: number;
  support: number;
  resistance: number;
  trend: 'bullish' | 'bearish' | 'neutral';
  strength: number;
}

interface EconomicEvent {
  title: string;
  impact: 'high' | 'medium' | 'low';
  actual?: number;
  forecast?: number;
  previous?: number;
  currency: string;
  time: Date;
}

export class EnhancedSignalGenerator {
  private readonly MINIMUM_CONSENSUS_SCORE = 85; // Raised from 75%
  private readonly MINIMUM_TECHNICAL_SCORE = 80;
  private readonly MINIMUM_FUNDAMENTAL_SCORE = 70;

  async generateEnhancedSignal(asset: MarketAsset): Promise<TradingRecommendation | null> {
    try {
      // 1. Multi-timeframe technical analysis
      const technicalAnalysis = await this.performMultiTimeframeAnalysis(asset.symbol);
      
      // 2. Fundamental analysis integration
      const fundamentalAnalysis = await this.performFundamentalAnalysis(asset.symbol);
      
      // 3. Sentiment analysis from news
      const sentimentAnalysis = await this.performSentimentAnalysis(asset.symbol);
      
      // 4. Market regime detection
      const marketRegime = await this.detectMarketRegime(asset.symbol);
      
      // 5. Volatility clustering analysis
      const volatilityAnalysis = await this.analyzeVolatilityClusters(asset.symbol);
      
      // 6. Support/Resistance levels
      const supportResistance = await this.calculateSupportResistance(asset.symbol);
      
      // 7. Volume profile analysis
      const volumeProfile = await this.analyzeVolumeProfile(asset.symbol);
      
      // Combine all analyses for consensus scoring
      const enhancedData: EnhancedSignalData = {
        symbol: asset.symbol,
        timeframes: technicalAnalysis,
        fundamentals: fundamentalAnalysis,
        technicalScore: this.calculateTechnicalScore(technicalAnalysis),
        fundamentalScore: this.calculateFundamentalScore(fundamentalAnalysis),
        consensusScore: 0
      };

      // Calculate consensus score from all timeframes and factors
      enhancedData.consensusScore = this.calculateConsensusScore(enhancedData, {
        marketRegime,
        volatilityAnalysis,
        supportResistance,
        volumeProfile,
        sentimentAnalysis
      });

      // Only generate signal if consensus score meets enhanced threshold
      if (enhancedData.consensusScore < this.MINIMUM_CONSENSUS_SCORE) {
        console.log(`Signal rejected for ${asset.symbol}: Consensus score ${enhancedData.consensusScore} below threshold ${this.MINIMUM_CONSENSUS_SCORE}`);
        return null;
      }

      // Generate the enhanced trading recommendation
      return this.createEnhancedRecommendation(asset, enhancedData, {
        marketRegime,
        volatilityAnalysis,
        supportResistance,
        volumeProfile,
        sentimentAnalysis
      });

    } catch (error) {
      console.error(`Error generating enhanced signal for ${asset.symbol}:`, error);
      return null;
    }
  }

  private async performMultiTimeframeAnalysis(symbol: string): Promise<EnhancedSignalData['timeframes']> {
    // Simulate real multi-timeframe analysis
    // In production, this would fetch actual OHLCV data for each timeframe
    const timeframes = ['1m', '5m', '15m', '1h', '4h'] as const;
    const analysis: any = {};

    for (const timeframe of timeframes) {
      analysis[timeframe] = await this.calculateIndicatorsForTimeframe(symbol, timeframe);
    }

    return analysis;
  }

  private async calculateIndicatorsForTimeframe(symbol: string, timeframe: string): Promise<MarketIndicators> {
    // Simulate advanced technical indicator calculations
    // In production, this would use libraries like technicalindicators or talib
    
    const mockPrice = 1.0500 + (Math.random() - 0.5) * 0.01;
    const volatility = Math.random() * 0.02;
    
    return {
      rsi: 30 + Math.random() * 40, // RSI between 30-70 for realistic signals
      macd: {
        value: (Math.random() - 0.5) * 0.001,
        signal: (Math.random() - 0.5) * 0.0008,
        histogram: (Math.random() - 0.5) * 0.0002
      },
      bollinger: {
        upper: mockPrice + volatility,
        middle: mockPrice,
        lower: mockPrice - volatility,
        position: Math.random() // 0-1 scale
      },
      stochastic: {
        k: Math.random() * 100,
        d: Math.random() * 100
      },
      williams: -100 + Math.random() * 100,
      cci: (Math.random() - 0.5) * 200,
      momentum: (Math.random() - 0.5) * 2,
      volumeProfile: Math.random(),
      support: mockPrice - volatility * Math.random(),
      resistance: mockPrice + volatility * Math.random(),
      trend: Math.random() > 0.6 ? 'bullish' : Math.random() > 0.3 ? 'bearish' : 'neutral',
      strength: Math.random()
    };
  }

  private async performFundamentalAnalysis(symbol: string): Promise<EnhancedSignalData['fundamentals']> {
    // Simulate fundamental analysis
    // In production, this would integrate with economic calendar APIs
    
    return {
      economicEvents: [
        {
          title: 'GDP Release',
          impact: 'high',
          actual: 2.1,
          forecast: 2.0,
          previous: 1.9,
          currency: symbol.split('/')[0],
          time: new Date()
        }
      ],
      newsImpact: (Math.random() - 0.5) * 2, // -1 to 1 scale
      marketSentiment: (Math.random() - 0.5) * 2 // -1 to 1 scale
    };
  }

  private async performSentimentAnalysis(symbol: string): Promise<number> {
    // Simulate sentiment analysis from news and social media
    // In production, this would use NLP APIs to analyze recent news
    return (Math.random() - 0.5) * 2; // -1 to 1 scale
  }

  private async detectMarketRegime(symbol: string): Promise<'trending' | 'ranging' | 'volatile'> {
    // Simulate market regime detection
    const regimes = ['trending', 'ranging', 'volatile'] as const;
    return regimes[Math.floor(Math.random() * regimes.length)];
  }

  private async analyzeVolatilityClusters(symbol: string): Promise<{ current: number; predicted: number }> {
    // Simulate volatility clustering analysis using GARCH models
    return {
      current: Math.random() * 0.03,
      predicted: Math.random() * 0.03
    };
  }

  private async calculateSupportResistance(symbol: string): Promise<{ support: number[]; resistance: number[] }> {
    // Simulate support/resistance calculation using pivot points and fibonacci
    const basePrice = 1.0500;
    return {
      support: [basePrice - 0.001, basePrice - 0.002, basePrice - 0.003],
      resistance: [basePrice + 0.001, basePrice + 0.002, basePrice + 0.003]
    };
  }

  private async analyzeVolumeProfile(symbol: string): Promise<{ poc: number; valueArea: { high: number; low: number } }> {
    // Simulate volume profile analysis
    const basePrice = 1.0500;
    return {
      poc: basePrice, // Point of Control
      valueArea: {
        high: basePrice + 0.0005,
        low: basePrice - 0.0005
      }
    };
  }

  private calculateTechnicalScore(timeframes: EnhancedSignalData['timeframes']): number {
    let totalScore = 0;
    let timeframeCount = 0;

    Object.values(timeframes).forEach(indicators => {
      let timeframeScore = 0;
      let indicatorCount = 0;

      // RSI scoring (30-70 range gets higher scores)
      if (indicators.rsi > 30 && indicators.rsi < 70) {
        timeframeScore += indicators.rsi > 50 ? (70 - indicators.rsi) / 20 * 100 : (indicators.rsi - 30) / 20 * 100;
      }
      indicatorCount++;

      // MACD scoring
      const macdSignal = indicators.macd.value > indicators.macd.signal ? 1 : -1;
      timeframeScore += (macdSignal + 1) * 50; // Convert -1,1 to 0,100
      indicatorCount++;

      // Bollinger Bands scoring
      timeframeScore += (1 - Math.abs(indicators.bollinger.position - 0.5) * 2) * 100;
      indicatorCount++;

      // Trend strength scoring
      timeframeScore += indicators.strength * 100;
      indicatorCount++;

      totalScore += timeframeScore / indicatorCount;
      timeframeCount++;
    });

    return totalScore / timeframeCount;
  }

  private calculateFundamentalScore(fundamentals: EnhancedSignalData['fundamentals']): number {
    let score = 50; // Base neutral score

    // Economic events impact
    fundamentals.economicEvents.forEach(event => {
      if (event.actual && event.forecast) {
        const surprise = (event.actual - event.forecast) / event.forecast;
        const impactMultiplier = event.impact === 'high' ? 3 : event.impact === 'medium' ? 2 : 1;
        score += surprise * impactMultiplier * 10;
      }
    });

    // News sentiment impact
    score += fundamentals.newsImpact * 25;

    // Market sentiment impact
    score += fundamentals.marketSentiment * 25;

    return Math.max(0, Math.min(100, score));
  }

  private calculateConsensusScore(
    data: EnhancedSignalData,
    additionalFactors: any
  ): number {
    const weights = {
      technical: 0.4,
      fundamental: 0.2,
      sentiment: 0.15,
      regime: 0.15,
      volatility: 0.1
    };

    let consensusScore = 0;

    // Technical analysis weight
    consensusScore += data.technicalScore * weights.technical;

    // Fundamental analysis weight
    consensusScore += data.fundamentalScore * weights.fundamental;

    // Sentiment analysis weight
    consensusScore += (additionalFactors.sentimentAnalysis + 1) * 50 * weights.sentiment;

    // Market regime weight
    const regimeScore = additionalFactors.marketRegime === 'trending' ? 80 : 
                       additionalFactors.marketRegime === 'ranging' ? 60 : 40;
    consensusScore += regimeScore * weights.regime;

    // Volatility weight (lower volatility gets higher score for stability)
    const volatilityScore = Math.max(0, 100 - additionalFactors.volatilityAnalysis.current * 1000);
    consensusScore += volatilityScore * weights.volatility;

    return Math.round(consensusScore);
  }

  private createEnhancedRecommendation(
    asset: MarketAsset,
    data: EnhancedSignalData,
    factors: any
  ): TradingRecommendation {
    // Determine direction based on consensus
    const direction = data.technicalScore > 60 && data.fundamentalScore > 60 ? 'BUY' : 'SELL';
    
    // Calculate confidence based on consensus score
    const confidence = Math.min(95, Math.max(75, data.consensusScore));

    // Determine risk level based on volatility and market regime
    const riskLevel = factors.volatilityAnalysis.current > 0.02 ? 'high' : 
                     factors.volatilityAnalysis.current > 0.01 ? 'medium' : 'low';

    // Enhanced analysis text with specific insights
    const analysisDetails = this.generateDetailedAnalysis(data, factors, direction);

    const recommendation: TradingRecommendation = {
      id: Date.now(),
      assetSymbol: asset.symbol,
      direction: direction as 'BUY' | 'SELL',
      confidence,
      riskLevel: riskLevel as 'low' | 'medium' | 'high',
      analysis: analysisDetails,
      createdAt: new Date(),
      result: null,
      expiresAt: new Date(Date.now() + 15 * 60 * 1000), // 15 minutes
      technicalAnalysis: JSON.stringify({
        multiTimeframe: data.timeframes,
        consensusScore: data.consensusScore,
        technicalScore: data.technicalScore,
        fundamentalScore: data.fundamentalScore,
        marketRegime: factors.marketRegime,
        volatilityCluster: factors.volatilityAnalysis,
        supportResistance: factors.supportResistance,
        volumeProfile: factors.volumeProfile
      })
    };

    return recommendation;
  }

  private generateDetailedAnalysis(data: EnhancedSignalData, factors: any, direction: string): string {
    const timeframeConsensus = Object.keys(data.timeframes).filter(tf => 
      data.timeframes[tf as keyof typeof data.timeframes].trend === (direction === 'BUY' ? 'bullish' : 'bearish')
    ).length;

    return `تحليل متعدد الإطارات الزمنية: ${timeframeConsensus}/5 إطارات زمنية تؤيد ${direction === 'BUY' ? 'الشراء' : 'البيع'}. ` +
           `نظام السوق: ${factors.marketRegime === 'trending' ? 'اتجاهي' : factors.marketRegime === 'ranging' ? 'متذبذب' : 'متقلب'}. ` +
           `النتيجة التقنية: ${data.technicalScore.toFixed(1)}%. ` +
           `النتيجة الأساسية: ${data.fundamentalScore.toFixed(1)}%. ` +
           `التقلبات المتوقعة: ${(factors.volatilityAnalysis.predicted * 100).toFixed(2)}%. ` +
           `مستوى الدعم/المقاومة: ${factors.supportResistance.support[0].toFixed(4)}/${factors.supportResistance.resistance[0].toFixed(4)}`;
  }
}

export const enhancedSignalGenerator = new EnhancedSignalGenerator();