import { TechnicalAnalysisService } from './technical-analysis.js';

interface AdvancedMarketData {
  symbol: string;
  timeframes: {
    [key: string]: {
      prices: number[];
      highs: number[];
      lows: number[];
      volumes: number[];
      opens: number[];
      timestamp: number[];
    }
  };
  currentPrice: number;
  marketSession: 'asian' | 'london' | 'newyork' | 'overlap' | 'closed';
  volatility: number;
  economicEvents: boolean;
}

interface ProfessionalSignal {
  signal: 'BUY' | 'SELL' | 'HOLD';
  confidence: number;
  strength: 'قوية جداً' | 'قوية' | 'متوسطة' | 'ضعيفة';
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH';
  entryPrice: number;
  stopLoss: number;
  takeProfit1: number;
  takeProfit2: number;
  duration: string;
  reasoning: string[];
  technicalScore: number;
  fundamentalScore: number;
  sentimentScore: number;
  timeframeAlignment: number;
  probabilityOfSuccess: number;
  supportResistance: {
    nearestSupport: number;
    nearestResistance: number;
    keyLevel: boolean;
  };
  marketStructure: {
    trend: 'صاعد قوي' | 'صاعد' | 'محايد' | 'هابط' | 'هابط قوي';
    phase: 'اختراق' | 'انسحاب' | 'توطيد' | 'انعكاس';
    momentum: 'متسارع' | 'ثابت' | 'متباطئ';
  };
  riskReward: number;
  volumeConfirmation: boolean;
  institutionalFlow: 'شراء' | 'بيع' | 'محايد';
}

export class ProfessionalTechnicalAnalysisService extends TechnicalAnalysisService {
  
  // تحليل الأطر الزمنية المتعددة المتقدم
  async generateProfessionalSignal(data: AdvancedMarketData): Promise<ProfessionalSignal> {
    const timeframes = ['1m', '5m', '15m', '1h', '4h', '1d'];
    const analyses: any[] = [];
    
    // تحليل كل إطار زمني
    for (const tf of timeframes) {
      if (data.timeframes[tf]) {
        const tfData = data.timeframes[tf];
        const analysis = this.analyzeTimeframe(tfData, tf);
        analyses.push({ timeframe: tf, ...analysis });
      }
    }
    
    // حساب التوافق بين الأطر الزمنية
    const timeframeAlignment = this.calculateTimeframeAlignment(analyses);
    
    // تحليل هيكل السوق المتقدم
    const marketStructure = this.analyzeMarketStructure(data);
    
    // تحليل السيولة والتدفق المؤسسي
    const institutionalFlow = this.analyzeInstitutionalFlow(data);
    
    // تحليل مستويات الدعم والمقاومة الاحترافية
    const supportResistance = this.analyzeProfessionalSupportResistance(data);
    
    // حساب النقاط الفنية والأساسية
    const technicalScore = this.calculateTechnicalScore(analyses);
    const fundamentalScore = this.calculateFundamentalScore(data);
    const sentimentScore = this.calculateSentimentScore(data);
    
    // تحديد الإشارة النهائية
    const finalSignal = this.determineFinalSignal(
      analyses, 
      timeframeAlignment, 
      marketStructure, 
      technicalScore,
      fundamentalScore,
      sentimentScore
    );
    
    return finalSignal;
  }
  
  private analyzeTimeframe(tfData: any, timeframe: string): any {
    const { prices, highs, lows, volumes } = tfData;
    
    // المؤشرات الفنية المتقدمة
    const rsi = this.calculateRSI(prices, 14);
    const macd = this.calculateMACD(prices);
    const bb = this.calculateBollingerBands(prices);
    const stoch = this.calculateStochastic(highs, lows, prices);
    const atr = this.calculateATR(highs, lows, prices);
    
    // مؤشرات إضافية احترافية
    const adx = this.calculateADX(highs, lows, prices);
    const cci = this.calculateCCI(highs, lows, prices);
    const roc = this.calculateROC(prices);
    const obv = this.calculateOBV(prices, volumes);
    const vwap = this.calculateVWAP(prices, volumes, highs, lows);
    
    // تحليل الموجات
    const waveAnalysis = this.analyzeWavePattern(prices);
    
    // تحليل الشموع
    const candlestickPattern = this.analyzeCandlestickPatterns(tfData);
    
    // تحليل الدعم والمقاومة
    const pivotPoints = this.calculatePivotPoints(highs, lows, prices);
    
    // حساب النقاط لهذا الإطار الزمني
    let bullishPoints = 0;
    let bearishPoints = 0;
    let strength = 0;
    
    // تحليل RSI متقدم
    if (rsi < 20) { bullishPoints += 3; strength += 25; }
    else if (rsi < 30) { bullishPoints += 2; strength += 15; }
    else if (rsi > 80) { bearishPoints += 3; strength += 25; }
    else if (rsi > 70) { bearishPoints += 2; strength += 15; }
    
    // تحليل MACD متقدم مع التباعد
    if (macd.macd > macd.signal && macd.histogram > 0) {
      bullishPoints += 2; strength += 20;
    } else if (macd.macd < macd.signal && macd.histogram < 0) {
      bearishPoints += 2; strength += 20;
    }
    
    // تحليل نطاقات بولينجر
    if (bb.position < 0.1 && bb.bandwidth > 15) {
      bullishPoints += 2; strength += 18;
    } else if (bb.position > 0.9 && bb.bandwidth > 15) {
      bearishPoints += 2; strength += 18;
    }
    
    // تحليل ADX للاتجاه
    if (adx > 25) { strength += 15; }
    if (adx > 40) { strength += 10; }
    
    // تحليل CCI
    if (cci < -100) { bullishPoints += 1; strength += 8; }
    else if (cci > 100) { bearishPoints += 1; strength += 8; }
    
    // تحليل الحجم مع VWAP
    const currentPrice = prices[prices.length - 1];
    if (currentPrice > vwap && volumes[volumes.length - 1] > this.calculateSMA(volumes, 20)) {
      bullishPoints += 1; strength += 10;
    } else if (currentPrice < vwap && volumes[volumes.length - 1] > this.calculateSMA(volumes, 20)) {
      bearishPoints += 1; strength += 10;
    }
    
    // تحليل نمط الشموع
    if (candlestickPattern.bullish.length > 0) {
      bullishPoints += candlestickPattern.bullish.length;
      strength += candlestickPattern.bullish.length * 8;
    }
    if (candlestickPattern.bearish.length > 0) {
      bearishPoints += candlestickPattern.bearish.length;
      strength += candlestickPattern.bearish.length * 8;
    }
    
    const netPoints = bullishPoints - bearishPoints;
    let signal: 'BUY' | 'SELL' | 'HOLD' = 'HOLD';
    
    if (netPoints >= 3) signal = 'BUY';
    else if (netPoints <= -3) signal = 'SELL';
    
    return {
      signal,
      bullishPoints,
      bearishPoints,
      strength,
      rsi, macd, bb, stoch, adx, cci, obv, vwap,
      waveAnalysis,
      candlestickPattern,
      pivotPoints
    };
  }
  
  // حساب مؤشر الاتجاه ADX
  private calculateADX(highs: number[], lows: number[], closes: number[], period: number = 14): number {
    const dmp: number[] = [];
    const dmn: number[] = [];
    
    for (let i = 1; i < highs.length; i++) {
      const moveUp = highs[i] - highs[i - 1];
      const moveDown = lows[i - 1] - lows[i];
      
      dmp.push(moveUp > moveDown && moveUp > 0 ? moveUp : 0);
      dmn.push(moveDown > moveUp && moveDown > 0 ? moveDown : 0);
    }
    
    const atr = this.calculateATR(highs, lows, closes, period);
    const diPlus = this.calculateSMA(dmp, period) / atr * 100;
    const diMinus = this.calculateSMA(dmn, period) / atr * 100;
    
    const dx = Math.abs(diPlus - diMinus) / (diPlus + diMinus) * 100;
    return dx;
  }
  
  // حساب مؤشر قناة السلع CCI
  private calculateCCI(highs: number[], lows: number[], closes: number[], period: number = 20): number {
    const typicalPrices = highs.map((high, i) => (high + lows[i] + closes[i]) / 3);
    const sma = this.calculateSMA(typicalPrices, period);
    const meanDeviation = typicalPrices.slice(-period)
      .reduce((sum, tp) => sum + Math.abs(tp - sma), 0) / period;
    
    const currentTP = typicalPrices[typicalPrices.length - 1];
    return (currentTP - sma) / (0.015 * meanDeviation);
  }
  
  // حساب معدل التغيير ROC
  private calculateROC(prices: number[], period: number = 12): number {
    if (prices.length < period + 1) return 0;
    const current = prices[prices.length - 1];
    const previous = prices[prices.length - 1 - period];
    return ((current - previous) / previous) * 100;
  }
  
  // حساب حجم التوازن OBV
  private calculateOBV(prices: number[], volumes: number[]): number {
    let obv = 0;
    for (let i = 1; i < prices.length; i++) {
      if (prices[i] > prices[i - 1]) obv += volumes[i];
      else if (prices[i] < prices[i - 1]) obv -= volumes[i];
    }
    return obv;
  }
  
  // حساب السعر المرجح بالحجم VWAP
  private calculateVWAP(prices: number[], volumes: number[], highs: number[], lows: number[]): number {
    let totalPV = 0;
    let totalV = 0;
    
    for (let i = 0; i < prices.length; i++) {
      const typicalPrice = (highs[i] + lows[i] + prices[i]) / 3;
      totalPV += typicalPrice * volumes[i];
      totalV += volumes[i];
    }
    
    return totalV > 0 ? totalPV / totalV : prices[prices.length - 1];
  }
  
  // تحليل نماذج الموجات
  private analyzeWavePattern(prices: number[]): any {
    const peaks: number[] = [];
    const troughs: number[] = [];
    
    // تحديد القمم والقيعان
    for (let i = 1; i < prices.length - 1; i++) {
      if (prices[i] > prices[i - 1] && prices[i] > prices[i + 1]) {
        peaks.push(i);
      } else if (prices[i] < prices[i - 1] && prices[i] < prices[i + 1]) {
        troughs.push(i);
      }
    }
    
    // تحليل نماذج الموجات
    let pattern = 'غير محدد';
    if (peaks.length >= 2 && troughs.length >= 2) {
      const lastPeaks = peaks.slice(-2);
      const lastTroughs = troughs.slice(-2);
      
      if (prices[lastPeaks[1]] > prices[lastPeaks[0]] && 
          prices[lastTroughs[1]] > prices[lastTroughs[0]]) {
        pattern = 'قمم وقيعان صاعدة';
      } else if (prices[lastPeaks[1]] < prices[lastPeaks[0]] && 
                 prices[lastTroughs[1]] < prices[lastTroughs[0]]) {
        pattern = 'قمم وقيعان هابطة';
      }
    }
    
    return { pattern, peaks: peaks.length, troughs: troughs.length };
  }
  
  // تحليل نماذج الشموع
  private analyzeCandlestickPatterns(data: any): any {
    const { opens, highs, lows, prices: closes } = data;
    const bullish: string[] = [];
    const bearish: string[] = [];
    
    if (opens.length < 3) return { bullish, bearish };
    
    const len = closes.length;
    
    // نمط المطرقة
    for (let i = 1; i < len; i++) {
      const body = Math.abs(closes[i] - opens[i]);
      const lowerShadow = opens[i] < closes[i] ? opens[i] - lows[i] : closes[i] - lows[i];
      const upperShadow = highs[i] - Math.max(opens[i], closes[i]);
      
      if (lowerShadow > body * 2 && upperShadow < body * 0.5) {
        if (closes[i] > opens[i]) bullish.push('مطرقة صاعدة');
        else bearish.push('مطرقة هابطة');
      }
    }
    
    // نمط البلع
    if (len >= 2) {
      const prev = len - 2;
      const curr = len - 1;
      
      if (opens[prev] > closes[prev] && closes[curr] > opens[curr] &&
          closes[curr] > opens[prev] && opens[curr] < closes[prev]) {
        bullish.push('نمط البلع الصاعد');
      } else if (closes[prev] > opens[prev] && opens[curr] > closes[curr] &&
                 opens[curr] > closes[prev] && closes[curr] < opens[prev]) {
        bearish.push('نمط البلع الهابط');
      }
    }
    
    return { bullish, bearish };
  }
  
  // حساب نقاط البيفوت
  private calculatePivotPoints(highs: number[], lows: number[], closes: number[]): any {
    const high = Math.max(...highs.slice(-1));
    const low = Math.min(...lows.slice(-1));
    const close = closes[closes.length - 1];
    
    const pivot = (high + low + close) / 3;
    const r1 = 2 * pivot - low;
    const s1 = 2 * pivot - high;
    const r2 = pivot + (high - low);
    const s2 = pivot - (high - low);
    
    return { pivot, r1, r2, s1, s2 };
  }
  
  // حساب توافق الأطر الزمنية
  private calculateTimeframeAlignment(analyses: any[]): number {
    const signals = analyses.map(a => a.signal);
    const buyCount = signals.filter(s => s === 'BUY').length;
    const sellCount = signals.filter(s => s === 'SELL').length;
    const total = signals.length;
    
    if (total === 0) return 0;
    
    const maxCount = Math.max(buyCount, sellCount);
    return (maxCount / total) * 100;
  }
  
  // تحليل هيكل السوق
  private analyzeMarketStructure(data: AdvancedMarketData): any {
    const prices = data.timeframes['1h']?.prices || data.timeframes['5m']?.prices || [];
    if (prices.length < 50) return { trend: 'محايد', phase: 'توطيد', momentum: 'ثابت' };
    
    const sma20 = this.calculateSMA(prices, 20);
    const sma50 = this.calculateSMA(prices, 50);
    const sma200 = this.calculateSMA(prices, 200);
    const currentPrice = data.currentPrice;
    
    let trend = 'محايد';
    if (currentPrice > sma20 && sma20 > sma50 && sma50 > sma200) {
      trend = 'صاعد قوي';
    } else if (currentPrice > sma20 && sma20 > sma50) {
      trend = 'صاعد';
    } else if (currentPrice < sma20 && sma20 < sma50 && sma50 < sma200) {
      trend = 'هابط قوي';
    } else if (currentPrice < sma20 && sma20 < sma50) {
      trend = 'هابط';
    }
    
    // تحديد مرحلة السوق
    const recentPrices = prices.slice(-20);
    const volatility = this.calculateATR(
      recentPrices, recentPrices, recentPrices
    ) / currentPrice * 100;
    
    let phase = 'توطيد';
    if (volatility > 2) phase = 'اختراق';
    else if (volatility < 0.5) phase = 'انسحاب';
    
    // تحليل الزخم
    const roc = this.calculateROC(prices, 10);
    let momentum = 'ثابت';
    if (Math.abs(roc) > 2) momentum = 'متسارع';
    else if (Math.abs(roc) < 0.5) momentum = 'متباطئ';
    
    return { trend, phase, momentum };
  }
  
  // تحليل التدفق المؤسسي
  private analyzeInstitutionalFlow(data: AdvancedMarketData): 'شراء' | 'بيع' | 'محايد' {
    const volumes = data.timeframes['1h']?.volumes || data.timeframes['5m']?.volumes || [];
    const prices = data.timeframes['1h']?.prices || data.timeframes['5m']?.prices || [];
    
    if (volumes.length < 20) return 'محايد';
    
    const avgVolume = this.calculateSMA(volumes, 20);
    const recentVolume = volumes.slice(-5).reduce((sum, v) => sum + v, 0) / 5;
    const priceChange = (prices[prices.length - 1] - prices[prices.length - 6]) / prices[prices.length - 6];
    
    if (recentVolume > avgVolume * 1.5) {
      return priceChange > 0 ? 'شراء' : 'بيع';
    }
    
    return 'محايد';
  }
  
  // تحليل الدعم والمقاومة الاحترافي
  private analyzeProfessionalSupportResistance(data: AdvancedMarketData): any {
    const highs = data.timeframes['1h']?.highs || data.timeframes['5m']?.highs || [];
    const lows = data.timeframes['1h']?.lows || data.timeframes['5m']?.lows || [];
    
    // إيجاد مستويات الدعم والمقاومة الرئيسية
    const resistanceLevels = this.findKeyLevels(highs, 'resistance');
    const supportLevels = this.findKeyLevels(lows, 'support');
    
    const currentPrice = data.currentPrice;
    const nearestResistance = resistanceLevels.find(r => r > currentPrice) || currentPrice * 1.02;
    const nearestSupport = [...supportLevels].reverse().find(s => s < currentPrice) || currentPrice * 0.98;
    
    const keyLevel = this.isAtKeyLevel(currentPrice, [...resistanceLevels, ...supportLevels]);
    
    return {
      nearestSupport,
      nearestResistance,
      keyLevel,
      resistanceLevels,
      supportLevels
    };
  }
  
  private findKeyLevels(prices: number[], type: 'resistance' | 'support'): number[] {
    const levels: number[] = [];
    const lookback = 20;
    
    for (let i = lookback; i < prices.length - lookback; i++) {
      const current = prices[i];
      const leftSide = prices.slice(i - lookback, i);
      const rightSide = prices.slice(i + 1, i + lookback + 1);
      
      if (type === 'resistance') {
        const isHighest = leftSide.every(p => p <= current) && rightSide.every(p => p <= current);
        if (isHighest) levels.push(current);
      } else {
        const isLowest = leftSide.every(p => p >= current) && rightSide.every(p => p >= current);
        if (isLowest) levels.push(current);
      }
    }
    
    return levels.sort((a, b) => b - a);
  }
  
  private isAtKeyLevel(price: number, levels: number[]): boolean {
    return levels.some(level => Math.abs(price - level) / level < 0.002);
  }
  
  // حساب النقاط الفنية
  private calculateTechnicalScore(analyses: any[]): number {
    if (analyses.length === 0) return 50;
    
    const avgStrength = analyses.reduce((sum, a) => sum + a.strength, 0) / analyses.length;
    const avgBullishPoints = analyses.reduce((sum, a) => sum + a.bullishPoints, 0) / analyses.length;
    const avgBearishPoints = analyses.reduce((sum, a) => sum + a.bearishPoints, 0) / analyses.length;
    
    const netPoints = avgBullishPoints - avgBearishPoints;
    return Math.max(0, Math.min(100, 50 + netPoints * 10 + avgStrength));
  }
  
  // حساب النقاط الأساسية
  private calculateFundamentalScore(data: AdvancedMarketData): number {
    let score = 50;
    
    // تحليل جلسة السوق
    if (data.marketSession === 'overlap') score += 15;
    else if (data.marketSession === 'london' || data.marketSession === 'newyork') score += 10;
    else if (data.marketSession === 'asian') score += 5;
    
    // تحليل الأحداث الاقتصادية
    if (data.economicEvents) score -= 20;
    
    // تحليل التقلبات
    if (data.volatility < 1) score += 10;
    else if (data.volatility > 3) score -= 15;
    
    return Math.max(0, Math.min(100, score));
  }
  
  // حساب نقاط المشاعر
  private calculateSentimentScore(data: AdvancedMarketData): number {
    // هذا يمكن أن يتكامل مع خدمة تحليل المشاعر الموجودة
    return 60; // نقطة أساسية
  }
  
  // تحديد الإشارة النهائية
  private determineFinalSignal(
    analyses: any[], 
    timeframeAlignment: number, 
    marketStructure: any,
    technicalScore: number,
    fundamentalScore: number,
    sentimentScore: number
  ): ProfessionalSignal {
    
    // حساب النقاط الإجمالية
    const overallScore = (technicalScore * 0.5) + (fundamentalScore * 0.3) + (sentimentScore * 0.2);
    
    // تحديد الإشارة بناءً على توافق الأطر الزمنية والنقاط
    let signal: 'BUY' | 'SELL' | 'HOLD' = 'HOLD';
    let confidence = 50;
    let strength: 'قوية جداً' | 'قوية' | 'متوسطة' | 'ضعيفة' = 'ضعيفة';
    
    const majoritySignal = this.getMajoritySignal(analyses);
    
    if (timeframeAlignment >= 70 && overallScore >= 70) {
      signal = majoritySignal;
      confidence = Math.min(95, 70 + (timeframeAlignment + overallScore) / 4);
      strength = confidence >= 90 ? 'قوية جداً' : confidence >= 80 ? 'قوية' : 'متوسطة';
    } else if (timeframeAlignment >= 60 && overallScore >= 60) {
      signal = majoritySignal;
      confidence = Math.min(85, 60 + (timeframeAlignment + overallScore) / 5);
      strength = confidence >= 80 ? 'قوية' : 'متوسطة';
    } else if (timeframeAlignment >= 50 && overallScore >= 50) {
      signal = majoritySignal;
      confidence = Math.min(75, 50 + (timeframeAlignment + overallScore) / 6);
      strength = 'متوسطة';
    }
    
    // تحديد مستوى المخاطر
    let riskLevel: 'LOW' | 'MEDIUM' | 'HIGH' = 'MEDIUM';
    if (confidence >= 85 && timeframeAlignment >= 80) riskLevel = 'LOW';
    else if (confidence <= 65 || timeframeAlignment <= 50) riskLevel = 'HIGH';
    
    // حساب مستويات الدخول والخروج
    const currentPrice = analyses[0]?.prices?.[analyses[0].prices.length - 1] || 100;
    const atr = analyses[0]?.atr || currentPrice * 0.001;
    
    const entryPrice = currentPrice;
    const stopLoss = signal === 'BUY' ? 
      currentPrice - (atr * 2) : 
      currentPrice + (atr * 2);
    const takeProfit1 = signal === 'BUY' ? 
      currentPrice + (atr * 1.5) : 
      currentPrice - (atr * 1.5);
    const takeProfit2 = signal === 'BUY' ? 
      currentPrice + (atr * 3) : 
      currentPrice - (atr * 3);
    
    // تحديد مدة التداول بناءً على قوة الإشارة
    const duration = confidence >= 85 ? '10 دقائق' : 
                    confidence >= 75 ? '5 دقائق' : 
                    confidence >= 65 ? '3 دقائق' : '1 دقيقة';
    
    // إنشاء التفسيرات
    const reasoning = this.generateReasoningProfessional(
      analyses, timeframeAlignment, marketStructure, overallScore
    );
    
    return {
      signal,
      confidence: Math.round(confidence),
      strength,
      riskLevel,
      entryPrice,
      stopLoss,
      takeProfit1,
      takeProfit2,
      duration,
      reasoning,
      technicalScore: Math.round(technicalScore),
      fundamentalScore: Math.round(fundamentalScore),
      sentimentScore: Math.round(sentimentScore),
      timeframeAlignment: Math.round(timeframeAlignment),
      probabilityOfSuccess: Math.round(confidence * 0.85), // تقدير أكثر واقعية
      supportResistance: {
        nearestSupport: stopLoss,
        nearestResistance: takeProfit2,
        keyLevel: Math.random() > 0.7 // سيتم تحسينها لاحقاً
      },
      marketStructure,
      riskReward: Math.abs(takeProfit1 - entryPrice) / Math.abs(entryPrice - stopLoss),
      volumeConfirmation: timeframeAlignment > 70,
      institutionalFlow: signal === 'BUY' ? 'شراء' : signal === 'SELL' ? 'بيع' : 'محايد'
    };
  }
  
  private getMajoritySignal(analyses: any[]): 'BUY' | 'SELL' | 'HOLD' {
    const signals = analyses.map(a => a.signal);
    const buyCount = signals.filter(s => s === 'BUY').length;
    const sellCount = signals.filter(s => s === 'SELL').length;
    
    if (buyCount > sellCount) return 'BUY';
    if (sellCount > buyCount) return 'SELL';
    return 'HOLD';
  }
  
  private generateReasoningProfessional(
    analyses: any[], 
    timeframeAlignment: number, 
    marketStructure: any, 
    overallScore: number
  ): string[] {
    const reasoning: string[] = [];
    
    reasoning.push(`توافق الأطر الزمنية: ${timeframeAlignment.toFixed(1)}%`);
    reasoning.push(`هيكل السوق: ${marketStructure.trend} في مرحلة ${marketStructure.phase}`);
    reasoning.push(`النقاط الإجمالية: ${overallScore.toFixed(1)}/100`);
    
    if (timeframeAlignment >= 80) {
      reasoning.push('توافق قوي جداً بين جميع الأطر الزمنية');
    } else if (timeframeAlignment >= 70) {
      reasoning.push('توافق جيد بين معظم الأطر الزمنية');
    }
    
    if (marketStructure.momentum === 'متسارع') {
      reasoning.push('زخم متسارع يدعم الاتجاه');
    }
    
    // إضافة تحليل المؤشرات الرئيسية
    const avgRSI = analyses.reduce((sum, a) => sum + (a.rsi || 50), 0) / analyses.length;
    if (avgRSI < 30) reasoning.push('RSI في منطقة التشبع البيعي');
    else if (avgRSI > 70) reasoning.push('RSI في منطقة التشبع الشرائي');
    
    return reasoning;
  }
}