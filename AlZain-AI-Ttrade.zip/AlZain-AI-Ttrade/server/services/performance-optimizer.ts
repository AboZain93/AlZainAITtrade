import { LRUCache } from 'lru-cache';

interface CacheOptions {
  maxSize?: number;
  maxAge?: number; // in milliseconds
}

interface PerformanceMetrics {
  apiResponseTimes: Map<string, number[]>;
  cacheHitRates: Map<string, { hits: number; misses: number }>;
  memoryUsage: NodeJS.MemoryUsage;
  activeConnections: number;
  requestCount: number;
  errorCount: number;
  lastUpdated: Date;
}

export class PerformanceOptimizer {
  private caches: Map<string, LRUCache<string, any>> = new Map();
  private metrics: PerformanceMetrics;
  private compressionEnabled = true;
  private requestTimes: Map<string, Date> = new Map();

  constructor() {
    this.metrics = {
      apiResponseTimes: new Map(),
      cacheHitRates: new Map(),
      memoryUsage: process.memoryUsage(),
      activeConnections: 0,
      requestCount: 0,
      errorCount: 0,
      lastUpdated: new Date()
    };

    // Initialize common caches
    this.createCache('market-data', { maxSize: 1000, maxAge: 30 * 1000 }); // 30 seconds
    this.createCache('technical-indicators', { maxSize: 500, maxAge: 60 * 1000 }); // 1 minute
    this.createCache('recommendations', { maxSize: 200, maxAge: 5 * 60 * 1000 }); // 5 minutes
    this.createCache('user-sessions', { maxSize: 1000, maxAge: 30 * 60 * 1000 }); // 30 minutes
    this.createCache('api-responses', { maxSize: 2000, maxAge: 10 * 1000 }); // 10 seconds

    // Start metrics collection
    this.startMetricsCollection();
  }

  // Cache Management
  createCache(name: string, options: CacheOptions = {}): void {
    const cache = new LRUCache<string, any>({
      max: options.maxSize || 500,
      ttl: options.maxAge || 5 * 60 * 1000, // 5 minutes default
      updateAgeOnGet: true,
      allowStale: false
    });

    this.caches.set(name, cache);
    this.metrics.cacheHitRates.set(name, { hits: 0, misses: 0 });
  }

  // Enhanced caching with compression for large objects
  set(cacheName: string, key: string, value: any, ttl?: number): boolean {
    const cache = this.caches.get(cacheName);
    if (!cache) return false;

    try {
      // Compress large objects
      let compressedValue = value;
      if (this.compressionEnabled && this.shouldCompress(value)) {
        compressedValue = this.compressData(value);
      }

      if (ttl) {
        cache.set(key, compressedValue, { ttl });
      } else {
        cache.set(key, compressedValue);
      }
      
      return true;
    } catch (error) {
      console.error(`Cache set error for ${cacheName}:${key}:`, error);
      return false;
    }
  }

  get(cacheName: string, key: string): any {
    const cache = this.caches.get(cacheName);
    if (!cache) return null;

    const hitMissTracker = this.metrics.cacheHitRates.get(cacheName);
    if (!hitMissTracker) return null;

    const value = cache.get(key);
    
    if (value !== undefined) {
      hitMissTracker.hits++;
      
      // Decompress if needed
      if (this.isCompressed(value)) {
        return this.decompressData(value);
      }
      return value;
    } else {
      hitMissTracker.misses++;
      return null;
    }
  }

  // Batch operations for better performance
  mget(cacheName: string, keys: string[]): Map<string, any> {
    const results = new Map<string, any>();
    
    for (const key of keys) {
      const value = this.get(cacheName, key);
      if (value !== null) {
        results.set(key, value);
      }
    }
    
    return results;
  }

  mset(cacheName: string, entries: Map<string, any>, ttl?: number): boolean {
    let allSuccess = true;
    
    for (const [key, value] of entries) {
      if (!this.set(cacheName, key, value, ttl)) {
        allSuccess = false;
      }
    }
    
    return allSuccess;
  }

  // Cache invalidation patterns
  invalidatePattern(cacheName: string, pattern: string): number {
    const cache = this.caches.get(cacheName);
    if (!cache) return 0;

    let deleted = 0;
    const regex = new RegExp(pattern);
    
    for (const key of cache.keys()) {
      if (regex.test(key)) {
        cache.delete(key);
        deleted++;
      }
    }
    
    return deleted;
  }

  // Response time tracking
  startRequest(requestId: string): void {
    this.requestTimes.set(requestId, new Date());
    this.metrics.requestCount++;
    this.metrics.activeConnections++;
  }

  endRequest(requestId: string, endpoint?: string): number {
    const startTime = this.requestTimes.get(requestId);
    if (!startTime) return 0;

    const endTime = new Date();
    const responseTime = endTime.getTime() - startTime.getTime();
    
    this.requestTimes.delete(requestId);
    this.metrics.activeConnections = Math.max(0, this.metrics.activeConnections - 1);

    // Track response times per endpoint
    if (endpoint) {
      if (!this.metrics.apiResponseTimes.has(endpoint)) {
        this.metrics.apiResponseTimes.set(endpoint, []);
      }
      
      const times = this.metrics.apiResponseTimes.get(endpoint)!;
      times.push(responseTime);
      
      // Keep only last 100 measurements
      if (times.length > 100) {
        times.splice(0, times.length - 100);
      }
    }

    return responseTime;
  }

  recordError(endpoint?: string): void {
    this.metrics.errorCount++;
  }

  // Memory and performance monitoring
  getPerformanceMetrics(): PerformanceMetrics {
    this.metrics.memoryUsage = process.memoryUsage();
    this.metrics.lastUpdated = new Date();
    return { ...this.metrics };
  }

  getCacheStats(): Map<string, any> {
    const stats = new Map();
    
    for (const [name, cache] of this.caches) {
      const hitMiss = this.metrics.cacheHitRates.get(name);
      const totalRequests = hitMiss ? hitMiss.hits + hitMiss.misses : 0;
      const hitRate = totalRequests > 0 ? (hitMiss!.hits / totalRequests) * 100 : 0;
      
      stats.set(name, {
        size: cache.size,
        maxSize: cache.max,
        hitRate: hitRate.toFixed(2),
        hits: hitMiss?.hits || 0,
        misses: hitMiss?.misses || 0
      });
    }
    
    return stats;
  }

  // Memory optimization
  optimizeMemory(): void {
    // Force garbage collection if available
    if (global.gc) {
      global.gc();
    }

    // Clear old cache entries
    for (const cache of this.caches.values()) {
      cache.purgeStale();
    }

    // Clear old request tracking
    const now = Date.now();
    for (const [requestId, startTime] of this.requestTimes) {
      if (now - startTime.getTime() > 60000) { // 1 minute timeout
        this.requestTimes.delete(requestId);
      }
    }

    console.log('Memory optimization completed');
  }

  // Data compression utilities
  private shouldCompress(data: any): boolean {
    const size = JSON.stringify(data).length;
    return size > 1024; // Compress if larger than 1KB
  }

  private compressData(data: any): { compressed: boolean; data: string } {
    try {
      const zlib = require('zlib');
      const compressed = zlib.deflateSync(JSON.stringify(data));
      return {
        compressed: true,
        data: compressed.toString('base64')
      };
    } catch (error) {
      console.error('Compression error:', error);
      return { compressed: false, data };
    }
  }

  private decompressData(compressedData: { compressed: boolean; data: any }): any {
    if (!compressedData.compressed) {
      return compressedData.data;
    }

    try {
      const zlib = require('zlib');
      const buffer = Buffer.from(compressedData.data, 'base64');
      const decompressed = zlib.inflateSync(buffer);
      return JSON.parse(decompressed.toString());
    } catch (error) {
      console.error('Decompression error:', error);
      return null;
    }
  }

  private isCompressed(data: any): boolean {
    return typeof data === 'object' && data.hasOwnProperty('compressed') && data.compressed === true;
  }

  // Metrics collection
  private startMetricsCollection(): void {
    setInterval(() => {
      this.metrics.memoryUsage = process.memoryUsage();
      this.metrics.lastUpdated = new Date();
      
      // Auto-optimize memory every 5 minutes
      if (this.metrics.memoryUsage.heapUsed > 100 * 1024 * 1024) { // 100MB threshold
        this.optimizeMemory();
      }
    }, 30000); // Every 30 seconds
  }

  // Cleanup and shutdown
  cleanup(): void {
    for (const cache of this.caches.values()) {
      cache.clear();
    }
    this.caches.clear();
    this.requestTimes.clear();
    console.log('Performance optimizer cleaned up');
  }
}

// Singleton instance
export const performanceOptimizer = new PerformanceOptimizer();

// Express middleware for automatic performance tracking
export function performanceMiddleware() {
  return (req: any, res: any, next: any) => {
    const requestId = `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    req.requestId = requestId;
    
    performanceOptimizer.startRequest(requestId);
    
    // Override res.end to capture response time
    const originalEnd = res.end;
    res.end = function(chunk: any, encoding: any) {
      const responseTime = performanceOptimizer.endRequest(requestId, req.path);
      
      // Add performance headers only if response hasn't been sent yet
      if (!res.headersSent) {
        try {
          res.setHeader('X-Response-Time', `${responseTime}ms`);
          res.setHeader('X-Cache-Status', res.fromCache ? 'HIT' : 'MISS');
        } catch (error) {
          // Headers already sent, ignore
        }
      }
      
      originalEnd.call(this, chunk, encoding);
    };
    
    next();
  };
}