import { storage } from '../storage';

interface UltraAdvancedAnalysis {
  marketRegime: 'bull' | 'bear' | 'sideways' | 'volatile' | 'trending';
  volatilityCluster: boolean;
  momentumStrength: number;
  supportResistanceLevels: number[];
  marketSentiment: 'extreme_fear' | 'fear' | 'neutral' | 'greed' | 'extreme_greed';
  timeframeSynergy: number;
  probabilityDistribution: {
    winProbability: number;
    expectedReturn: number;
    maxDrawdown: number;
    sharpeRatio: number;
  };
  riskMetrics: {
    varAtRisk: number;
    expectedShortfall: number;
    riskRewardRatio: number;
  };
}

interface AdvancedSignalQuality {
  overallScore: number;
  technicalScore: number;
  fundamentalScore: number;
  sentimentScore: number;
  momentumScore: number;
  qualityGrade: 'A+' | 'A' | 'B+' | 'B' | 'C+' | 'C' | 'D';
  recommendationStrength: 'VERY_STRONG' | 'STRONG' | 'MODERATE' | 'WEAK' | 'VERY_WEAK';
}

export class UltraAdvancedAISystem {
  private static instance: UltraAdvancedAISystem;
  private learningDatabase: Map<string, any> = new Map();
  private modelAccuracy: Map<string, number> = new Map();
  private adaptiveThresholds: Map<string, number> = new Map();

  constructor() {
    this.initializeAdaptiveSystem();
  }

  static getInstance(): UltraAdvancedAISystem {
    if (!UltraAdvancedAISystem.instance) {
      UltraAdvancedAISystem.instance = new UltraAdvancedAISystem();
    }
    return UltraAdvancedAISystem.instance;
  }

  private async initializeAdaptiveSystem() {
    // Initialize adaptive thresholds based on historical performance
    this.adaptiveThresholds.set('confidence_threshold', 75);
    this.adaptiveThresholds.set('quality_threshold', 80);
    this.adaptiveThresholds.set('risk_threshold', 0.3);
    this.adaptiveThresholds.set('momentum_threshold', 0.6);
    
    // Load historical learning data
    await this.loadLearningData();
  }

  private async loadLearningData() {
    try {
      // Load ML training data to improve model
      const trainingData = await storage.getAllMlTrainingData(1000);
      const feedbackData = await storage.getAllTelegramFeedback(1000);
      
      // Process learning data
      this.processLearningData(trainingData, feedbackData);
    } catch (error) {
      console.log('🤖 Initializing fresh learning database');
    }
  }

  private processLearningData(trainingData: any[], feedbackData: any[]) {
    // Analyze successful patterns
    const successPatterns = trainingData.filter(data => data.result === 'success');
    const failurePatterns = trainingData.filter(data => data.result === 'failure');
    
    // Update adaptive thresholds based on success rates
    if (successPatterns.length > 0) {
      const avgSuccessConfidence = successPatterns.reduce((sum, pattern) => 
        sum + (pattern.confidence || 0), 0) / successPatterns.length;
      
      if (avgSuccessConfidence > 80) {
        this.adaptiveThresholds.set('confidence_threshold', Math.max(80, avgSuccessConfidence - 5));
      }
    }

    // Process Telegram feedback for sentiment analysis
    const positiveFeedback = feedbackData.filter(fb => fb.feedbackType === 'success');
    const negativeFeedback = feedbackData.filter(fb => fb.feedbackType === 'failure');
    
    if (positiveFeedback.length > 0 && negativeFeedback.length > 0) {
      const successRate = positiveFeedback.length / (positiveFeedback.length + negativeFeedback.length);
      
      // Adjust quality threshold based on user feedback
      if (successRate > 0.75) {
        this.adaptiveThresholds.set('quality_threshold', 85);
      } else if (successRate < 0.60) {
        this.adaptiveThresholds.set('quality_threshold', 90);
      }
    }

    console.log('🧠 Learning system updated with', trainingData.length, 'training samples and', feedbackData.length, 'feedback points');
  }

  async performUltraAdvancedAnalysis(
    symbol: string,
    marketData: any,
    technicalIndicators: any
  ): Promise<UltraAdvancedAnalysis> {
    // Import economic news analyzer for fundamental analysis
    let newsImpact = null;
    try {
      const { economicNewsAnalyzer } = await import('./economic-news-analyzer');
      newsImpact = await economicNewsAnalyzer.getNewsImpactForAsset(symbol);
    } catch (error) {
      console.log('Economic news analyzer not available, proceeding without news impact');
    }
    
    // Multi-dimensional market regime detection
    const marketRegime = this.detectMarketRegime(marketData, technicalIndicators);
    
    // Advanced volatility clustering analysis
    const volatilityCluster = this.detectVolatilityCluster(marketData);
    
    // Momentum strength calculation using multiple timeframes
    const momentumStrength = this.calculateMomentumStrength(technicalIndicators);
    
    // Dynamic support/resistance levels
    const supportResistanceLevels = this.calculateDynamicLevels(marketData);
    
    // Market sentiment analysis (enhanced with news data)
    const marketSentiment = this.analyzeSentiment(symbol, marketData, newsImpact);
    
    // Timeframe synergy analysis
    const timeframeSynergy = this.analyzeTimeframeSynergy(technicalIndicators);
    
    // Advanced probability distribution (enhanced with news impact)
    const probabilityDistribution = await this.calculateProbabilityDistribution(
      symbol, marketData, technicalIndicators, newsImpact
    );
    
    // Risk metrics calculation
    const riskMetrics = this.calculateAdvancedRiskMetrics(
      marketData, probabilityDistribution
    );

    return {
      marketRegime,
      volatilityCluster,
      momentumStrength,
      supportResistanceLevels,
      marketSentiment,
      timeframeSynergy,
      probabilityDistribution,
      riskMetrics
    };
  }

  private detectMarketRegime(marketData: any, technicalIndicators: any): UltraAdvancedAnalysis['marketRegime'] {
    const price = marketData.price;
    const rsi = technicalIndicators.rsi || 50;
    const macd = technicalIndicators.macd || 0;
    const adx = technicalIndicators.adx || 25;
    
    // Advanced regime detection algorithm
    if (adx > 30) {
      if (macd > 0 && rsi > 55) return 'bull';
      if (macd < 0 && rsi < 45) return 'bear';
      return 'trending';
    }
    
    if (rsi > 70 || rsi < 30) return 'volatile';
    return 'sideways';
  }

  private detectVolatilityCluster(marketData: any): boolean {
    // Simplified volatility clustering detection
    const priceChange = Math.abs((marketData.price - marketData.previousPrice || marketData.price) / marketData.price);
    return priceChange > 0.01; // 1% threshold
  }

  private calculateMomentumStrength(technicalIndicators: any): number {
    const rsi = technicalIndicators.rsi || 50;
    const macd = technicalIndicators.macd || 0;
    const adx = technicalIndicators.adx || 25;
    
    // Combine multiple momentum indicators
    const rsiMomentum = Math.abs(rsi - 50) / 50;
    const macdMomentum = Math.min(Math.abs(macd) * 100, 1);
    const adxMomentum = Math.min(adx / 100, 1);
    
    return (rsiMomentum + macdMomentum + adxMomentum) / 3;
  }

  private calculateDynamicLevels(marketData: any): number[] {
    const price = marketData.price;
    
    // Calculate dynamic support and resistance levels
    const levels = [];
    levels.push(price * 0.995); // Support 1
    levels.push(price * 0.99);  // Support 2
    levels.push(price * 1.005); // Resistance 1
    levels.push(price * 1.01);  // Resistance 2
    
    return levels;
  }

  private analyzeSentiment(symbol: string, marketData: any, newsImpact?: any): UltraAdvancedAnalysis['marketSentiment'] {
    // Base sentiment from price action
    const priceChange = (marketData.price - (marketData.previousPrice || marketData.price)) / marketData.price;
    
    let baseSentiment: UltraAdvancedAnalysis['marketSentiment'] = 'neutral';
    if (priceChange > 0.03) baseSentiment = 'extreme_greed';
    else if (priceChange > 0.01) baseSentiment = 'greed';
    else if (priceChange < -0.03) baseSentiment = 'extreme_fear';
    else if (priceChange < -0.01) baseSentiment = 'fear';
    
    // Enhance with news sentiment if available
    if (newsImpact) {
      const newsWeight = this.getNewsImpactWeight(newsImpact.impact);
      
      if (newsImpact.sentiment === 'positive' && newsWeight > 0.3) {
        // Positive news can push sentiment towards greed
        if (baseSentiment === 'neutral') return 'greed';
        if (baseSentiment === 'fear') return 'neutral';
        if (baseSentiment === 'greed') return 'extreme_greed';
      } else if (newsImpact.sentiment === 'negative' && newsWeight > 0.3) {
        // Negative news can push sentiment towards fear
        if (baseSentiment === 'neutral') return 'fear';
        if (baseSentiment === 'greed') return 'neutral';
        if (baseSentiment === 'fear') return 'extreme_fear';
      }
    }
    
    return baseSentiment;
  }

  private getNewsImpactWeight(impact: string): number {
    switch (impact) {
      case 'high': return 0.6;
      case 'medium': return 0.4;
      case 'low': return 0.2;
      default: return 0;
    }
  }

  private analyzeTimeframeSynergy(technicalIndicators: any): number {
    // Analyze alignment across multiple timeframes
    const indicators = [
      technicalIndicators.rsi,
      technicalIndicators.macd,
      technicalIndicators.adx,
      technicalIndicators.stochastic
    ].filter(Boolean);
    
    if (indicators.length === 0) return 0.5;
    
    // Calculate synergy score
    const avgIndicator = indicators.reduce((sum, ind) => sum + ind, 0) / indicators.length;
    const variance = indicators.reduce((sum, ind) => sum + Math.pow(ind - avgIndicator, 2), 0) / indicators.length;
    
    return Math.max(0, Math.min(1, 1 - (variance / 1000)));
  }

  private async calculateProbabilityDistribution(
    symbol: string,
    marketData: any,
    technicalIndicators: any,
    newsImpact?: any
  ): Promise<UltraAdvancedAnalysis['probabilityDistribution']> {
    
    // Get historical performance data
    const assetPerformance = await storage.getAssetPerformance(symbol);
    const historicalAccuracy = assetPerformance?.accuracy || 70;
    
    // Calculate win probability based on current conditions (enhanced with news)
    const baseWinProb = historicalAccuracy / 100;
    const momentumBonus = this.calculateMomentumStrength(technicalIndicators) * 0.1;
    const sentimentBonus = this.getSentimentBonus(this.analyzeSentiment(symbol, marketData, newsImpact));
    
    // Add news impact bonus
    let newsBonus = 0;
    if (newsImpact) {
      const newsWeight = this.getNewsImpactWeight(newsImpact.impact);
      if (newsImpact.sentiment === 'positive') {
        newsBonus = newsWeight * 0.1; // Up to 6% boost for high impact positive news
      } else if (newsImpact.sentiment === 'negative') {
        newsBonus = -newsWeight * 0.1; // Up to 6% reduction for high impact negative news
      }
    }
    
    const winProbability = Math.min(0.95, Math.max(0.1, baseWinProb + momentumBonus + sentimentBonus + newsBonus));
    
    // Calculate expected metrics
    const expectedReturn = winProbability * 0.8 - (1 - winProbability) * 1; // 80% win, 100% loss
    const maxDrawdown = Math.max(0.1, 1 - winProbability);
    const sharpeRatio = expectedReturn / Math.max(0.1, maxDrawdown);
    
    return {
      winProbability: winProbability * 100,
      expectedReturn: expectedReturn * 100,
      maxDrawdown: maxDrawdown * 100,
      sharpeRatio
    };
  }

  private getSentimentBonus(sentiment: UltraAdvancedAnalysis['marketSentiment']): number {
    const bonusMap = {
      'extreme_greed': -0.05,  // Contrarian
      'greed': -0.02,
      'neutral': 0,
      'fear': 0.02,
      'extreme_fear': 0.05     // Contrarian
    };
    return bonusMap[sentiment] || 0;
  }

  private calculateAdvancedRiskMetrics(
    marketData: any,
    probabilityDistribution: UltraAdvancedAnalysis['probabilityDistribution']
  ): UltraAdvancedAnalysis['riskMetrics'] {
    
    const winProb = probabilityDistribution.winProbability / 100;
    const expectedReturn = probabilityDistribution.expectedReturn / 100;
    
    // Value at Risk (95% confidence)
    const varAtRisk = (1 - winProb) * 100;
    
    // Expected Shortfall
    const expectedShortfall = varAtRisk * 1.2;
    
    // Risk-Reward Ratio
    const riskRewardRatio = Math.abs(expectedReturn) / Math.max(0.1, varAtRisk / 100);
    
    return {
      varAtRisk,
      expectedShortfall,
      riskRewardRatio
    };
  }

  async evaluateSignalQuality(
    analysis: UltraAdvancedAnalysis,
    confidence: number,
    symbol: string
  ): Promise<AdvancedSignalQuality> {
    
    // Technical analysis score
    const technicalScore = this.calculateTechnicalScore(analysis);
    
    // Fundamental score (simplified)
    const fundamentalScore = this.calculateFundamentalScore(analysis);
    
    // Sentiment score
    const sentimentScore = this.calculateSentimentScore(analysis);
    
    // Momentum score
    const momentumScore = analysis.momentumStrength * 100;
    
    // Overall score calculation
    const overallScore = (
      technicalScore * 0.4 +
      fundamentalScore * 0.2 +
      sentimentScore * 0.2 +
      momentumScore * 0.2
    );
    
    // Quality grade assignment
    const qualityGrade = this.assignQualityGrade(overallScore);
    
    // Recommendation strength
    const recommendationStrength = this.determineRecommendationStrength(
      overallScore, analysis.probabilityDistribution.winProbability
    );
    
    // Store quality metrics for learning
    await this.storeLearningData(symbol, {
      overallScore,
      technicalScore,
      confidence,
      qualityGrade,
      recommendationStrength,
      timestamp: new Date()
    });
    
    return {
      overallScore,
      technicalScore,
      fundamentalScore,
      sentimentScore,
      momentumScore,
      qualityGrade,
      recommendationStrength
    };
  }

  private calculateTechnicalScore(analysis: UltraAdvancedAnalysis): number {
    let score = 50; // Base score
    
    // Market regime bonus
    if (analysis.marketRegime === 'trending' || analysis.marketRegime === 'bull' || analysis.marketRegime === 'bear') {
      score += 15;
    }
    
    // Momentum bonus
    score += analysis.momentumStrength * 20;
    
    // Timeframe synergy bonus
    score += analysis.timeframeSynergy * 15;
    
    // Volatility adjustment
    if (analysis.volatilityCluster) {
      score += 10; // High volatility can be good for short-term trades
    }
    
    return Math.min(100, Math.max(0, score));
  }

  private calculateFundamentalScore(analysis: UltraAdvancedAnalysis): number {
    let score = 60; // Base score
    
    // Market sentiment adjustment
    const sentimentMap = {
      'extreme_fear': 80,    // Contrarian opportunity
      'fear': 70,
      'neutral': 60,
      'greed': 50,
      'extreme_greed': 40    // Dangerous territory
    };
    
    score = sentimentMap[analysis.marketSentiment] || 60;
    
    // Risk-reward adjustment
    if (analysis.riskMetrics.riskRewardRatio > 2) {
      score += 15;
    } else if (analysis.riskMetrics.riskRewardRatio > 1.5) {
      score += 10;
    }
    
    return Math.min(100, Math.max(0, score));
  }

  private calculateSentimentScore(analysis: UltraAdvancedAnalysis): number {
    const sentimentScores = {
      'extreme_fear': 85,    // Great contrarian opportunity
      'fear': 75,
      'neutral': 50,
      'greed': 35,
      'extreme_greed': 20    // Very risky
    };
    
    return sentimentScores[analysis.marketSentiment] || 50;
  }

  private assignQualityGrade(score: number): AdvancedSignalQuality['qualityGrade'] {
    if (score >= 90) return 'A+';
    if (score >= 85) return 'A';
    if (score >= 80) return 'B+';
    if (score >= 75) return 'B';
    if (score >= 70) return 'C+';
    if (score >= 60) return 'C';
    return 'D';
  }

  private determineRecommendationStrength(
    overallScore: number,
    winProbability: number
  ): AdvancedSignalQuality['recommendationStrength'] {
    if (overallScore >= 85 && winProbability >= 80) return 'VERY_STRONG';
    if (overallScore >= 80 && winProbability >= 75) return 'STRONG';
    if (overallScore >= 70 && winProbability >= 65) return 'MODERATE';
    if (overallScore >= 60 && winProbability >= 55) return 'WEAK';
    return 'VERY_WEAK';
  }

  private async storeLearningData(symbol: string, data: any) {
    try {
      await storage.createMlTrainingData({
        assetSymbol: symbol,
        features: JSON.stringify(data),
        target: data.qualityGrade,
        confidence: data.confidence,
        result: null, // Will be updated later based on actual results
        createdAt: new Date()
      });
    } catch (error) {
      console.log('Error storing learning data:', error);
    }
  }

  async shouldAcceptSignal(
    analysis: UltraAdvancedAnalysis,
    quality: AdvancedSignalQuality,
    confidence: number
  ): Promise<{ accept: boolean; reason: string }> {
    
    const dynamicThreshold = this.adaptiveThresholds.get('confidence_threshold') || 75;
    const qualityThreshold = this.adaptiveThresholds.get('quality_threshold') || 80;
    
    // Multi-criteria acceptance logic
    if (confidence < dynamicThreshold) {
      return { accept: false, reason: `Low confidence (${confidence}%) - threshold: ${dynamicThreshold}%` };
    }
    
    if (quality.overallScore < qualityThreshold) {
      return { accept: false, reason: `Low quality score (${quality.overallScore.toFixed(1)}) - threshold: ${qualityThreshold}` };
    }
    
    if (analysis.probabilityDistribution.winProbability < 65) {
      return { accept: false, reason: `Low win probability (${analysis.probabilityDistribution.winProbability.toFixed(1)}%)` };
    }
    
    if (analysis.riskMetrics.riskRewardRatio < 1.2) {
      return { accept: false, reason: `Poor risk/reward ratio (${analysis.riskMetrics.riskRewardRatio.toFixed(2)})` };
    }
    
    if (quality.recommendationStrength === 'VERY_WEAK' || quality.recommendationStrength === 'WEAK') {
      return { accept: false, reason: `Weak recommendation strength (${quality.recommendationStrength})` };
    }
    
    // All criteria passed
    return { 
      accept: true, 
      reason: `High-quality signal: ${quality.qualityGrade} grade, ${quality.recommendationStrength} strength` 
    };
  }

  async adaptiveLearn(symbol: string, actualResult: 'success' | 'failure', confidence: number) {
    // Update adaptive thresholds based on results
    const currentThreshold = this.adaptiveThresholds.get('confidence_threshold') || 75;
    
    if (actualResult === 'failure' && confidence >= currentThreshold) {
      // If high confidence signal failed, increase threshold
      const newThreshold = Math.min(95, currentThreshold + 2);
      this.adaptiveThresholds.set('confidence_threshold', newThreshold);
      console.log(`🧠 Adaptive learning: Confidence threshold increased to ${newThreshold}%`);
    } else if (actualResult === 'success' && confidence < currentThreshold) {
      // If low confidence signal succeeded, maybe decrease threshold slightly
      const newThreshold = Math.max(65, currentThreshold - 1);
      this.adaptiveThresholds.set('confidence_threshold', newThreshold);
      console.log(`🧠 Adaptive learning: Confidence threshold adjusted to ${newThreshold}%`);
    }
    
    // Update model accuracy tracking
    const assetKey = `${symbol}_accuracy`;
    const currentAccuracy = this.modelAccuracy.get(assetKey) || 70;
    const newAccuracy = actualResult === 'success' ? 
      Math.min(95, currentAccuracy + 1) : 
      Math.max(30, currentAccuracy - 2);
    
    this.modelAccuracy.set(assetKey, newAccuracy);
    
    // Store learning result in database
    try {
      const trainingData = await storage.getMlTrainingDataByAsset(symbol, 1);
      if (trainingData.length > 0) {
        const latestData = trainingData[0];
        // Update the result - Note: This is simplified, in real implementation you'd need update method
        console.log(`🎯 Learning result stored: ${symbol} - ${actualResult} (confidence: ${confidence}%)`);
      }
    } catch (error) {
      console.log('Error updating learning result:', error);
    }
  }

  getSystemStats() {
    return {
      adaptiveThresholds: Object.fromEntries(this.adaptiveThresholds),
      modelAccuracies: Object.fromEntries(this.modelAccuracy),
      learningDataPoints: this.learningDatabase.size,
      systemVersion: '2.0-Ultra'
    };
  }
}

export const ultraAdvancedAI = UltraAdvancedAISystem.getInstance();