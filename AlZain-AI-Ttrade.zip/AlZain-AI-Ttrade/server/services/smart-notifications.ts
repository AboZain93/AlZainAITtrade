// Smart notification system for trading recommendations
export class SmartNotificationService {
  
  // Analyze recommendation quality and provide intelligent suggestions
  analyzeRecommendationQuality(data: {
    confidence: number;
    indicators: any[];
    marketCondition: string;
    timing: any;
    assetType: string;
  }): {
    qualityScore: number;
    improvements: string[];
    warnings: string[];
    optimizations: string[];
    arabicSummary: string;
  } {
    let qualityScore = 0;
    const improvements: string[] = [];
    const warnings: string[] = [];
    const optimizations: string[] = [];

    // Confidence analysis
    if (data.confidence >= 85) {
      qualityScore += 25;
      optimizations.push('نسبة ثقة ممتازة - يمكن زيادة حجم الصفقة');
    } else if (data.confidence >= 70) {
      qualityScore += 15;
      improvements.push('نسبة ثقة جيدة - انتظر تأكيدات إضافية');
    } else {
      qualityScore += 5;
      warnings.push('نسبة ثقة منخفضة - تداول بحذر شديد');
    }

    // Indicator analysis
    const indicatorCount = data.indicators.length;
    if (indicatorCount >= 5) {
      qualityScore += 20;
      optimizations.push('تحليل شامل بمؤشرات متعددة');
    } else if (indicatorCount >= 3) {
      qualityScore += 15;
      improvements.push('إضافة مؤشرات أخرى يحسن الدقة');
    } else {
      qualityScore += 5;
      warnings.push('عدد المؤشرات قليل - قد تكون الإشارة غير مؤكدة');
    }

    // Market timing analysis
    if (data.timing.optimal) {
      qualityScore += 20;
      optimizations.push('توقيت ممتاز للتداول');
    } else if (data.timing.volatility === 'high') {
      qualityScore += 10;
      warnings.push('تقلبات عالية - احذر من التحركات المفاجئة');
    } else {
      qualityScore += 5;
      improvements.push('انتظر توقيت أفضل للدخول');
    }

    // Market condition analysis
    if (data.marketCondition === 'متفائلة' || data.marketCondition === 'bullish') {
      qualityScore += 15;
      optimizations.push('ظروف السوق مواتية');
    } else if (data.marketCondition === 'متقلبة' || data.marketCondition === 'volatile') {
      qualityScore += 5;
      warnings.push('السوق متقلب - استخدم وقف خسارة ضيق');
    }

    // Asset type specific analysis
    if (data.assetType === 'forex') {
      qualityScore += 10;
      optimizations.push('زوج عملات نشط - سيولة جيدة');
    } else if (data.assetType === 'crypto') {
      warnings.push('العملات الرقمية عالية المخاطر');
    }

    const arabicSummary = this.generateQualitySummary(qualityScore, improvements, warnings, optimizations);

    return {
      qualityScore: Math.min(100, qualityScore),
      improvements,
      warnings,
      optimizations,
      arabicSummary
    };
  }

  // Generate personalized trading advice
  generatePersonalizedAdvice(userProfile: {
    experienceLevel: 'beginner' | 'intermediate' | 'advanced';
    riskTolerance: 'low' | 'medium' | 'high';
    preferredAssets: string[];
    successRate: number;
    averageConfidence: number;
  }, recommendation: any): {
    advice: string[];
    positionSize: string;
    riskManagement: string[];
    arabicAdvice: string;
  } {
    const advice: string[] = [];
    const riskManagement: string[] = [];
    let positionSize = 'متوسط';

    // Experience-based advice
    if (userProfile.experienceLevel === 'beginner') {
      advice.push('ابدأ بمبلغ صغير لتعلم إدارة المخاطر');
      advice.push('راقب الصفقة باستمرار ولا تتركها بدون مراقبة');
      positionSize = 'صغير جداً';
      riskManagement.push('استخدم وقف خسارة لا يتجاوز 2% من رأس المال');
      riskManagement.push('لا تدخل أكثر من صفقة واحدة في نفس الوقت');
    } else if (userProfile.experienceLevel === 'intermediate') {
      advice.push('يمكنك زيادة حجم الصفقة قليلاً مع هذه النسبة');
      advice.push('فكر في تطبيق استراتيجية متدرجة للدخول');
      positionSize = recommendation.confidence >= 80 ? 'متوسط إلى كبير' : 'متوسط';
      riskManagement.push('وقف الخسارة 3-5% حسب التقلبات');
      riskManagement.push('يمكن إدارة 2-3 صفقات متزامنة');
    } else {
      advice.push('إشارة قوية - يمكن استغلالها بحجم أكبر');
      advice.push('فكر في استراتيجيات التحوط المناسبة');
      positionSize = recommendation.confidence >= 85 ? 'كبير' : 'متوسط إلى كبير';
      riskManagement.push('إدارة مخاطر متقدمة حسب تحليلك');
      riskManagement.push('يمكن إدارة محفظة متنوعة');
    }

    // Risk tolerance adjustments
    if (userProfile.riskTolerance === 'low') {
      positionSize = 'صغير';
      riskManagement.push('التزم بنسبة مخاطرة لا تتجاوز 1% من المحفظة');
    } else if (userProfile.riskTolerance === 'high' && recommendation.confidence >= 80) {
      riskManagement.push('يمكن زيادة المخاطرة إلى 5% مع هذه الإشارة القوية');
    }

    // Performance-based advice
    if (userProfile.successRate < 60) {
      advice.push('معدل نجاحك يحتاج تحسين - ركز على جودة الإشارات');
      advice.push('راجع استراتيجيتك وطور مهاراتك في التحليل');
    } else if (userProfile.successRate >= 80) {
      advice.push('معدل نجاح ممتاز - يمكنك الثقة أكثر في قراراتك');
    }

    const arabicAdvice = `
🎯 نصائح شخصية لك:
${advice.map(item => `• ${item}`).join('\n')}

💰 حجم الصفقة المقترح: ${positionSize}

🛡️ إدارة المخاطر:
${riskManagement.map(item => `• ${item}`).join('\n')}
    `.trim();

    return {
      advice,
      positionSize,
      riskManagement,
      arabicAdvice
    };
  }

  // Market sentiment analysis
  analyzeMoodAndSentiment(): {
    mood: 'متفائل' | 'محايد' | 'متشائم' | 'مختلط';
    sentiment: string;
    marketFactors: string[];
    recommendation: string;
  } {
    const now = new Date();
    const hour = now.getHours();
    const day = now.getDay();
    
    let mood: 'متفائل' | 'محايد' | 'متشائم' | 'مختلط' = 'محايد';
    const marketFactors: string[] = [];
    let recommendation = '';

    // Time-based sentiment
    if (hour >= 9 && hour <= 11) {
      marketFactors.push('بداية اليوم - نشاط مرتفع عادة');
      mood = 'متفائل';
    } else if (hour >= 14 && hour <= 16) {
      marketFactors.push('وقت الذروة الأوروبية');
      mood = 'متفائل';
    } else if (hour >= 21 || hour <= 2) {
      marketFactors.push('ساعات هادئة - سيولة منخفضة');
      mood = 'محايد';
    }

    // Day-based sentiment
    if (day === 1) { // Monday
      marketFactors.push('بداية الأسبوع - قد تحدث فجوات سعرية');
      mood = 'مختلط';
    } else if (day === 5) { // Friday
      marketFactors.push('نهاية الأسبوع - تقييم المراكز');
      mood = 'محايد';
    }

    // Generate recommendation
    switch (mood) {
      case 'متفائل':
        recommendation = 'وقت مناسب للبحث عن فرص جديدة بثقة معقولة';
        break;
      case 'متشائم':
        recommendation = 'كن حذراً إضافياً وتجنب المخاطرة العالية';
        break;
      case 'مختلط':
        recommendation = 'انتظر تأكيدات قوية قبل الدخول في صفقات جديدة';
        break;
      default:
        recommendation = 'تداول عادي مع مراعاة إدارة المخاطر';
    }

    return {
      mood,
      sentiment: this.getMoodDescription(mood),
      marketFactors,
      recommendation
    };
  }

  // Generate educational content based on recommendation
  generateEducationalContent(recommendation: any): {
    concepts: string[];
    tips: string[];
    resources: string[];
    arabicExplanation: string;
  } {
    const concepts: string[] = [];
    const tips: string[] = [];
    const resources: string[] = [];

    // Technical analysis concepts
    if (recommendation.technicalAnalysis.includes('RSI')) {
      concepts.push('مؤشر RSI يقيس قوة الزخم - أقل من 30 يعني تشبع بيعي');
      tips.push('استخدم RSI مع مؤشرات أخرى لتأكيد الإشارة');
    }

    if (recommendation.technicalAnalysis.includes('MACD')) {
      concepts.push('مؤشر MACD يظهر تقارب وتباعد المتوسطات المتحركة');
      tips.push('عندما يعبر خط MACD فوق خط الإشارة = إشارة شراء محتملة');
    }

    if (recommendation.technicalAnalysis.includes('Bollinger')) {
      concepts.push('نطاقات بولينجر تظهر مستويات التقلبات والدعم/المقاومة');
      tips.push('السعر قرب النطاق السفلي قد يعني فرصة شراء');
    }

    // Risk management education
    tips.push('لا تخاطر بأكثر من 2-3% من رأس مالك في صفقة واحدة');
    tips.push('حدد نقطة وقف الخسارة قبل الدخول في الصفقة');
    tips.push('تابع الأخبار الاقتصادية التي تؤثر على أصلك');

    // Educational resources
    resources.push('كتاب "التحليل الفني للأسواق المالية" - جون مورفي');
    resources.push('مؤشرات TradingView للتحليل المتقدم');
    resources.push('أكاديمية الزين التجارية - الدروس التفاعلية');

    const arabicExplanation = `
📚 شرح مفصل للتوصية:

🔍 المفاهيم الأساسية:
${concepts.map(item => `• ${item}`).join('\n')}

💡 نصائح للتطبيق:
${tips.map(item => `• ${item}`).join('\n')}

📖 مصادر للتعلم:
${resources.map(item => `• ${item}`).join('\n')}
    `.trim();

    return {
      concepts,
      tips,
      resources,
      arabicExplanation
    };
  }

  private generateQualitySummary(score: number, improvements: string[], warnings: string[], optimizations: string[]): string {
    let summary = '';
    
    if (score >= 80) {
      summary = '🟢 توصية عالية الجودة - ';
    } else if (score >= 60) {
      summary = '🟡 توصية متوسطة الجودة - ';
    } else {
      summary = '🔴 توصية تحتاج حذر - ';
    }

    if (optimizations.length > 0) {
      summary += `نقاط القوة: ${optimizations.join(', ')}. `;
    }
    if (warnings.length > 0) {
      summary += `تحذيرات: ${warnings.join(', ')}. `;
    }
    if (improvements.length > 0) {
      summary += `تحسينات مقترحة: ${improvements.join(', ')}.`;
    }

    return summary;
  }

  private getMoodDescription(mood: string): string {
    switch (mood) {
      case 'متفائل': return 'السوق يظهر إشارات إيجابية ونشاط جيد';
      case 'متشائم': return 'حذر من ظروف السوق الحالية وتقلباته';
      case 'مختلط': return 'السوق يرسل إشارات متضاربة';
      default: return 'ظروف السوق عادية دون تطرف';
    }
  }
}

export const smartNotificationService = new SmartNotificationService();