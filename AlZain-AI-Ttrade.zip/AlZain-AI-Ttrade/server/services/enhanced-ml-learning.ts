import { storage } from '../storage';

interface AdvancedMLFeatures {
  technicalIndicators: {
    rsi: number;
    macd: number;
    bollinger_position: number;
    stochastic: number;
    adx: number;
    cci: number;
    williams_r: number;
    volume_strength: number;
  };
  marketContext: {
    session: string;
    volatility: number;
    trend_strength: number;
    liquidity_score: number;
    news_sentiment: number;
  };
  timeframeSynergy: {
    tf_1m: number;
    tf_5m: number;
    tf_15m: number;
    tf_1h: number;
    tf_4h: number;
    alignment_score: number;
  };
  riskFactors: {
    economic_events: boolean;
    market_hours: string;
    weekend_proximity: number;
    volatility_spike: boolean;
  };
}

interface MLPredictionResult {
  baseConfidence: number;
  adjustedConfidence: number;
  qualityScore: number;
  riskAdjustment: number;
  timeframeBonus: number;
  patternRecognition: number;
  marketConditionScore: number;
  reasoning: string[];
  recommendations: string[];
  nextOptimizations: string[];
}

export class EnhancedMLLearningService {
  private modelWeights: Map<string, number>;
  private successPatterns: Map<string, any>;
  private failurePatterns: Map<string, any>;
  private adaptiveThresholds: Map<string, number>;
  
  constructor() {
    this.modelWeights = new Map([
      ['technical_analysis', 0.35],
      ['market_context', 0.25],
      ['timeframe_synergy', 0.20],
      ['pattern_recognition', 0.15],
      ['risk_assessment', 0.05]
    ]);
    
    this.successPatterns = new Map();
    this.failurePatterns = new Map();
    this.adaptiveThresholds = new Map([
      ['min_confidence', 75],
      ['max_risk_tolerance', 0.7],
      ['timeframe_alignment_threshold', 0.6]
    ]);
    
    this.initializeFromHistoricalData();
  }
  
  private async initializeFromHistoricalData(): Promise<void> {
    try {
      const historicalData = await storage.getAllMlTrainingData(500);
      const feedbackData = await storage.getAllTelegramFeedback(200);
      
      // تحليل الأنماط الناجحة والفاشلة
      this.analyzeSuccessPatterns(historicalData, feedbackData);
      this.updateAdaptiveThresholds(historicalData);
      
      console.log('🧠 Enhanced ML initialized with historical patterns');
    } catch (error) {
      console.error('ML initialization error:', error);
    }
  }
  
  // التحليل المتقدم للثقة مع تعلم آلي محسن
  async calculateAdvancedConfidence(
    symbol: string,
    signal: string,
    baseConfidence: number,
    technicalData: any,
    marketFeatures?: AdvancedMLFeatures
  ): Promise<MLPredictionResult> {
    
    // جمع البيانات التاريخية للأصل
    const assetHistory = await this.getAssetPerformanceHistory(symbol);
    
    // تحليل الأنماط السابقة
    const patternAnalysis = await this.analyzeHistoricalPatterns(symbol, signal, technicalData);
    
    // تحليل السياق السوقي الحالي
    const contextAnalysis = this.analyzeCurrentMarketContext(marketFeatures);
    
    // تحليل توافق الأطر الزمنية
    const timeframeAnalysis = this.analyzeTimeframeSynergy(marketFeatures?.timeframeSynergy);
    
    // تقييم المخاطر المتقدم
    const riskAssessment = this.assessAdvancedRisk(symbol, marketFeatures);
    
    // تطبيق نموذج التعلم الآلي المتطور
    const mlResult = this.applyAdvancedMLModel({
      baseConfidence,
      signal,
      assetHistory,
      patternAnalysis,
      contextAnalysis,
      timeframeAnalysis,
      riskAssessment,
      technicalData
    });
    
    // حفظ النتائج للتعلم المستقبلي
    await this.saveMLPrediction(symbol, signal, mlResult);
    
    return mlResult;
  }
  
  private async getAssetPerformanceHistory(symbol: string): Promise<any> {
    const recommendations = await storage.getAllTradingRecommendations();
    const assetRecommendations = recommendations.filter(r => r.assetSymbol === symbol);
    
    const successRate = assetRecommendations.length > 0 
      ? assetRecommendations.filter(r => r.result === 'success').length / assetRecommendations.length 
      : 0.5;
    
    const avgConfidence = assetRecommendations.length > 0
      ? assetRecommendations.reduce((sum, r) => sum + r.confidence, 0) / assetRecommendations.length
      : 70;
    
    const recentPerformance = assetRecommendations
      .slice(-10)
      .map(r => ({ result: r.result, confidence: r.confidence, direction: r.direction }));
    
    return {
      totalSignals: assetRecommendations.length,
      successRate,
      avgConfidence,
      recentPerformance,
      strongDirections: this.findStrongDirections(assetRecommendations)
    };
  }
  
  private async analyzeHistoricalPatterns(symbol: string, signal: string, technicalData: any): Promise<any> {
    const mlData = await storage.getMlTrainingDataByAsset(symbol, 50);
    
    if (mlData.length < 5) {
      return {
        confidence: 0.5,
        similarPatterns: 0,
        patternStrength: 'weak',
        historicalAccuracy: 50
      };
    }
    
    // البحث عن أنماط مشابهة
    const similarPatterns = mlData.filter(data => {
      return Math.abs(data.originalConfidence - technicalData.rsi) < 15 &&
             data.direction === signal;
    });
    
    const patternSuccessRate = similarPatterns.length > 0
      ? similarPatterns.filter(p => p.successScore > 0.6).length / similarPatterns.length
      : 0.5;
    
    return {
      confidence: patternSuccessRate,
      similarPatterns: similarPatterns.length,
      patternStrength: patternSuccessRate > 0.7 ? 'strong' : patternSuccessRate > 0.5 ? 'medium' : 'weak',
      historicalAccuracy: patternSuccessRate * 100
    };
  }
  
  private analyzeCurrentMarketContext(features?: AdvancedMLFeatures): any {
    if (!features?.marketContext) {
      return {
        score: 0.6,
        factors: ['بيانات السياق محدودة'],
        sessionOptimal: false
      };
    }
    
    const context = features.marketContext;
    let score = 0.5;
    const factors = [];
    
    // تحليل جلسة التداول
    if (context.session === 'london' || context.session === 'newyork') {
      score += 0.15;
      factors.push('جلسة تداول نشطة');
    } else if (context.session === 'overlap') {
      score += 0.25;
      factors.push('تداخل الجلسات - سيولة عالية');
    }
    
    // تحليل التقلبات
    if (context.volatility < 1) {
      score += 0.1;
      factors.push('تقلبات منخفضة - استقرار');
    } else if (context.volatility > 3) {
      score -= 0.15;
      factors.push('تقلبات عالية - حذر');
    }
    
    // تحليل قوة الاتجاه
    if (context.trend_strength > 70) {
      score += 0.2;
      factors.push('اتجاه قوي');
    } else if (context.trend_strength < 30) {
      score -= 0.1;
      factors.push('اتجاه ضعيف');
    }
    
    // تحليل المشاعر
    if (context.news_sentiment > 60) {
      score += 0.1;
      factors.push('مشاعر إيجابية');
    } else if (context.news_sentiment < 40) {
      score -= 0.1;
      factors.push('مشاعر سلبية');
    }
    
    return {
      score: Math.max(0, Math.min(1, score)),
      factors,
      sessionOptimal: context.session === 'overlap' || context.session === 'london'
    };
  }
  
  private analyzeTimeframeSynergy(synergy?: any): any {
    if (!synergy) {
      return {
        alignment: 0.5,
        strength: 'medium',
        optimalTimeframes: ['5m', '15m']
      };
    }
    
    const timeframes = [synergy.tf_1m, synergy.tf_5m, synergy.tf_15m, synergy.tf_1h, synergy.tf_4h];
    const alignment = synergy.alignment_score || 0.5;
    
    let strength = 'weak';
    if (alignment > 0.8) strength = 'very_strong';
    else if (alignment > 0.7) strength = 'strong';
    else if (alignment > 0.6) strength = 'medium';
    
    const optimalTimeframes = [];
    if (synergy.tf_5m > 70) optimalTimeframes.push('5m');
    if (synergy.tf_15m > 70) optimalTimeframes.push('15m');
    if (synergy.tf_1h > 70) optimalTimeframes.push('1h');
    
    return {
      alignment,
      strength,
      optimalTimeframes: optimalTimeframes.length > 0 ? optimalTimeframes : ['5m', '15m']
    };
  }
  
  private assessAdvancedRisk(symbol: string, features?: AdvancedMLFeatures): any {
    let riskScore = 0.3; // مخاطر أساسية
    const riskFactors = [];
    
    if (features?.riskFactors) {
      const risks = features.riskFactors;
      
      if (risks.economic_events) {
        riskScore += 0.3;
        riskFactors.push('أحداث اقتصادية مهمة');
      }
      
      if (risks.volatility_spike) {
        riskScore += 0.2;
        riskFactors.push('ارتفاع مفاجئ في التقلبات');
      }
      
      if (risks.weekend_proximity > 0.8) {
        riskScore += 0.15;
        riskFactors.push('قرب نهاية الأسبوع');
      }
      
      if (risks.market_hours === 'low_liquidity') {
        riskScore += 0.25;
        riskFactors.push('ساعات سيولة منخفضة');
      }
    }
    
    // تحليل المخاطر التاريخية للأصل
    const historicalRisk = this.getHistoricalRisk(symbol);
    riskScore += historicalRisk * 0.2;
    
    return {
      score: Math.min(1, riskScore),
      level: riskScore > 0.7 ? 'HIGH' : riskScore > 0.4 ? 'MEDIUM' : 'LOW',
      factors: riskFactors,
      recommendation: riskScore > 0.7 ? 'تجنب التداول' : riskScore > 0.4 ? 'تداول بحذر' : 'مناسب للتداول'
    };
  }
  
  private applyAdvancedMLModel(inputs: any): MLPredictionResult {
    const {
      baseConfidence,
      signal,
      assetHistory,
      patternAnalysis,
      contextAnalysis,
      timeframeAnalysis,
      riskAssessment,
      technicalData
    } = inputs;
    
    // حساب التعديلات المختلفة
    const historyBonus = this.calculateHistoryBonus(assetHistory, signal);
    const patternBonus = this.calculatePatternBonus(patternAnalysis);
    const contextBonus = this.calculateContextBonus(contextAnalysis);
    const timeframeBonus = this.calculateTimeframeBonus(timeframeAnalysis);
    const riskPenalty = this.calculateRiskPenalty(riskAssessment);
    
    // تطبيق النموذج المرجح
    let adjustedConfidence = baseConfidence;
    adjustedConfidence += historyBonus;
    adjustedConfidence += patternBonus;
    adjustedConfidence += contextBonus;
    adjustedConfidence += timeframeBonus;
    adjustedConfidence -= riskPenalty;
    
    // تطبيق حدود واقعية
    adjustedConfidence = Math.max(30, Math.min(95, adjustedConfidence));
    
    // حساب نقاط الجودة
    const qualityScore = this.calculateQualityScore({
      patternAnalysis,
      contextAnalysis,
      timeframeAnalysis,
      riskAssessment
    });
    
    // إنتاج الاستدلال
    const reasoning = this.generateAdvancedReasoning({
      historyBonus,
      patternBonus,
      contextBonus,
      timeframeBonus,
      riskPenalty,
      assetHistory,
      patternAnalysis,
      contextAnalysis,
      riskAssessment
    });
    
    return {
      baseConfidence,
      adjustedConfidence: Math.round(adjustedConfidence),
      qualityScore: Math.round(qualityScore * 100) / 100,
      riskAdjustment: riskPenalty,
      timeframeBonus,
      patternRecognition: patternBonus,
      marketConditionScore: contextBonus,
      reasoning,
      recommendations: this.generateRecommendations(adjustedConfidence, riskAssessment),
      nextOptimizations: this.suggestOptimizations(inputs)
    };
  }
  
  private calculateHistoryBonus(history: any, signal: string): number {
    if (history.totalSignals < 5) return -5; // عدم وجود بيانات كافية
    
    let bonus = 0;
    
    // مكافأة معدل النجاح العالي
    if (history.successRate > 0.7) bonus += 8;
    else if (history.successRate > 0.6) bonus += 5;
    else if (history.successRate < 0.4) bonus -= 8;
    
    // تحليل الاتجاهات القوية
    if (history.strongDirections[signal] > 0.7) bonus += 5;
    
    // تحليل الأداء الأخير
    const recentSuccess = history.recentPerformance
      .filter(r => r.result === 'success').length / Math.max(1, history.recentPerformance.length);
    
    if (recentSuccess > 0.7) bonus += 6;
    else if (recentSuccess < 0.3) bonus -= 6;
    
    return bonus;
  }
  
  private calculatePatternBonus(pattern: any): number {
    if (pattern.similarPatterns < 3) return -3;
    
    let bonus = 0;
    
    if (pattern.patternStrength === 'strong') bonus += 10;
    else if (pattern.patternStrength === 'medium') bonus += 5;
    else bonus -= 2;
    
    // مكافأة الدقة التاريخية
    if (pattern.historicalAccuracy > 80) bonus += 8;
    else if (pattern.historicalAccuracy > 70) bonus += 5;
    else if (pattern.historicalAccuracy < 50) bonus -= 5;
    
    return bonus;
  }
  
  private calculateContextBonus(context: any): number {
    let bonus = (context.score - 0.5) * 20; // تحويل إلى مقياس -10 إلى +10
    
    if (context.sessionOptimal) bonus += 5;
    
    return bonus;
  }
  
  private calculateTimeframeBonus(timeframe: any): number {
    let bonus = 0;
    
    if (timeframe.strength === 'very_strong') bonus += 12;
    else if (timeframe.strength === 'strong') bonus += 8;
    else if (timeframe.strength === 'medium') bonus += 4;
    
    // مكافأة الأطر الزمنية المثلى
    if (timeframe.optimalTimeframes.length >= 3) bonus += 5;
    
    return bonus;
  }
  
  private calculateRiskPenalty(risk: any): number {
    let penalty = risk.score * 15; // تحويل إلى عقوبة
    
    if (risk.level === 'HIGH') penalty += 10;
    else if (risk.level === 'MEDIUM') penalty += 5;
    
    return penalty;
  }
  
  private calculateQualityScore(components: any): number {
    const scores = [
      components.patternAnalysis.confidence,
      components.contextAnalysis.score,
      components.timeframeAnalysis.alignment,
      1 - components.riskAssessment.score // عكس المخاطر
    ];
    
    return scores.reduce((sum, score) => sum + score, 0) / scores.length;
  }
  
  private generateAdvancedReasoning(analysis: any): string[] {
    const reasoning = [];
    
    // تحليل التاريخ
    if (analysis.historyBonus > 5) {
      reasoning.push(`أداء تاريخي ممتاز للأصل (معدل نجاح ${(analysis.assetHistory.successRate * 100).toFixed(1)}%)`);
    } else if (analysis.historyBonus < -3) {
      reasoning.push(`أداء تاريخي ضعيف يتطلب حذر إضافي`);
    }
    
    // تحليل الأنماط
    if (analysis.patternBonus > 8) {
      reasoning.push(`أنماط تاريخية قوية تدعم الإشارة (${analysis.patternAnalysis.similarPatterns} نمط مشابه)`);
    } else if (analysis.patternBonus < 0) {
      reasoning.push(`أنماط تاريخية محدودة أو متناقضة`);
    }
    
    // تحليل السياق
    if (analysis.contextBonus > 5) {
      reasoning.push(`ظروف السوق مثالية: ${analysis.contextAnalysis.factors.slice(0, 2).join(', ')}`);
    } else if (analysis.contextBonus < -5) {
      reasoning.push(`ظروف السوق صعبة تتطلب حذر`);
    }
    
    // تحليل المخاطر
    if (analysis.riskPenalty > 15) {
      reasoning.push(`مستوى مخاطر مرتفع: ${analysis.riskAssessment.factors.join(', ')}`);
    } else if (analysis.riskPenalty < 5) {
      reasoning.push(`بيئة تداول مناسبة مع مخاطر منخفضة`);
    }
    
    return reasoning.slice(0, 4); // الحد الأقصى 4 أسباب
  }
  
  private generateRecommendations(confidence: number, risk: any): string[] {
    const recommendations = [];
    
    if (confidence > 85) {
      recommendations.push('إشارة عالية الجودة - مناسبة لحجم مركز أكبر');
    } else if (confidence > 75) {
      recommendations.push('إشارة جيدة - حجم مركز متوسط مناسب');
    } else {
      recommendations.push('إشارة متوسطة - استخدم حجم مركز صغير');
    }
    
    if (risk.level === 'HIGH') {
      recommendations.push('مخاطر عالية - فكر في تجنب التداول');
    } else if (risk.level === 'MEDIUM') {
      recommendations.push('مخاطر متوسطة - استخدم إدارة مخاطر صارمة');
    }
    
    return recommendations;
  }
  
  private suggestOptimizations(inputs: any): string[] {
    const optimizations = [];
    
    if (inputs.assetHistory.totalSignals < 10) {
      optimizations.push('جمع المزيد من البيانات التاريخية للأصل');
    }
    
    if (inputs.timeframeAnalysis.alignment < 0.6) {
      optimizations.push('انتظار توافق أفضل بين الأطر الزمنية');
    }
    
    if (inputs.riskAssessment.score > 0.6) {
      optimizations.push('انتظار تحسن الظروف السوقية');
    }
    
    return optimizations;
  }
  
  // دوال مساعدة
  private findStrongDirections(recommendations: any[]): any {
    const directions = { BUY: 0, SELL: 0 };
    const successful = recommendations.filter(r => r.result === 'success');
    
    successful.forEach(r => {
      if (directions[r.direction] !== undefined) {
        directions[r.direction]++;
      }
    });
    
    const total = successful.length;
    return {
      BUY: total > 0 ? directions.BUY / total : 0.5,
      SELL: total > 0 ? directions.SELL / total : 0.5
    };
  }
  
  private getHistoricalRisk(symbol: string): number {
    // محاكاة تحليل المخاطر التاريخية
    const riskScores = {
      'EUR/USD': 0.2,
      'GBP/USD': 0.3,
      'USD/JPY': 0.25,
      'BTC': 0.6,
      'ETH': 0.5,
      'GOLD': 0.3
    };
    
    return riskScores[symbol] || 0.35;
  }
  
  private async saveMLPrediction(symbol: string, signal: string, result: MLPredictionResult): Promise<void> {
    try {
      await storage.createMlTrainingData({
        assetSymbol: symbol,
        direction: signal,
        originalConfidence: result.baseConfidence,
        actualResult: 'pending',
        successScore: result.qualityScore,
        features: JSON.stringify({
          adjustedConfidence: result.adjustedConfidence,
          riskAdjustment: result.riskAdjustment,
          timeframeBonus: result.timeframeBonus,
          reasoning: result.reasoning
        })
      });
    } catch (error) {
      console.error('Error saving ML prediction:', error);
    }
  }
  
  private analyzeSuccessPatterns(historicalData: any[], feedbackData: any[]): void {
    // تحليل الأنماط الناجحة والفاشلة (يمكن تطويرها أكثر)
    console.log(`Analyzing ${historicalData.length} historical records and ${feedbackData.length} feedback entries`);
  }
  
  private updateAdaptiveThresholds(data: any[]): void {
    // تحديث العتبات التكيفية بناءً على الأداء (يمكن تطويرها أكثر)
    if (data.length > 0) {
      const avgSuccess = data.reduce((sum, d) => sum + d.successScore, 0) / data.length;
      if (avgSuccess > 0.8) {
        this.adaptiveThresholds.set('min_confidence', 70);
      } else if (avgSuccess < 0.6) {
        this.adaptiveThresholds.set('min_confidence', 80);
      }
    }
  }
}

export const enhancedMLLearning = new EnhancedMLLearningService();