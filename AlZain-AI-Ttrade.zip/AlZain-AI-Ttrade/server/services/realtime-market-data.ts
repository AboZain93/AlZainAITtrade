import WebSocket from 'ws';
import axios from 'axios';
import { createClient } from 'redis';
import cron from 'node-cron';
import { storage } from '../storage';
import type { InsertMarketData } from '../../shared/schema';

interface MarketDataProvider {
  name: string;
  priority: number;
  isActive: boolean;
  getPrice(symbol: string): Promise<number | null>;
  subscribe?(symbol: string, callback: (price: number) => void): void;
}

interface MarketTick {
  symbol: string;
  price: number;
  timestamp: Date;
  volume?: number;
  change?: number;
  changePercent?: number;
}

class RealTimeMarketDataService {
  private providers: MarketDataProvider[] = [];
  private activeConnections: Map<string, WebSocket> = new Map();
  private redisClient: any;
  private subscribers: Map<string, Set<(data: MarketTick) => void>> = new Map();
  private lastPrices: Map<string, number> = new Map();
  private isInitialized = false;

  constructor() {
    this.initializeProviders();
    this.initializeRedis();
  }

  private async initializeRedis() {
    try {
      // Initialize Redis for caching (if available)
      if (process.env.REDIS_URL) {
        this.redisClient = createClient({ url: process.env.REDIS_URL });
        await this.redisClient.connect();
        console.log('✅ Redis connected for market data caching');
      }
    } catch (error) {
      console.log('⚠️ Redis not available, using memory cache');
    }
  }

  private initializeProviders() {
    // Provider 1: TwelveData API (Primary)
    this.providers.push({
      name: 'TwelveData',
      priority: 1,
      isActive: true,
      getPrice: async (symbol: string) => {
        try {
          const apiKey = process.env.TWELVEDATA_API_KEY || '2e1c65e781874c26ae9c4de25f42747d';
          const response = await axios.get(`https://api.twelvedata.com/price`, {
            params: {
              symbol: symbol,
              apikey: apiKey
            },
            timeout: 5000
          });
          
          if (response.data && response.data.price) {
            return parseFloat(response.data.price);
          }
          return null;
        } catch (error) {
          console.error(`TwelveData error for ${symbol}:`, error.message);
          return null;
        }
      }
    });

    // Provider 2: Yahoo Finance (Secondary)
    this.providers.push({
      name: 'YahooFinance',
      priority: 2,
      isActive: true,
      getPrice: async (symbol: string) => {
        try {
          const yahooSymbol = this.convertToYahooSymbol(symbol);
          const response = await axios.get(`https://query1.finance.yahoo.com/v8/finance/chart/${yahooSymbol}`, {
            timeout: 5000
          });
          
          const result = response.data?.chart?.result?.[0];
          if (result?.meta?.regularMarketPrice) {
            return result.meta.regularMarketPrice;
          }
          return null;
        } catch (error) {
          console.error(`Yahoo Finance error for ${symbol}:`, error.message);
          return null;
        }
      }
    });

    // Provider 3: Finnhub (Tertiary)
    this.providers.push({
      name: 'Finnhub',
      priority: 3,
      isActive: true,
      getPrice: async (symbol: string) => {
        try {
          const apiKey = process.env.FINNHUB_API_KEY;
          if (!apiKey) return null;
          
          const response = await axios.get(`https://finnhub.io/api/v1/quote`, {
            params: {
              symbol: symbol,
              token: apiKey
            },
            timeout: 5000
          });
          
          if (response.data && response.data.c) {
            return response.data.c; // Current price
          }
          return null;
        } catch (error) {
          console.error(`Finnhub error for ${symbol}:`, error.message);
          return null;
        }
      }
    });
  }

  private convertToYahooSymbol(symbol: string): string {
    // Convert trading symbols to Yahoo Finance format
    const conversions: { [key: string]: string } = {
      'EURUSD': 'EURUSD=X',
      'GBPUSD': 'GBPUSD=X',
      'USDJPY': 'USDJPY=X',
      'AUDUSD': 'AUDUSD=X',
      'USDCAD': 'USDCAD=X',
      'USDCHF': 'USDCHF=X',
      'NZDUSD': 'NZDUSD=X',
      'BTCUSD': 'BTC-USD',
      'ETHUSD': 'ETH-USD',
      'XAUUSD': 'GC=F', // Gold
      'XAGUSD': 'SI=F', // Silver
      'WTIUSD': 'CL=F', // Oil
    };
    
    return conversions[symbol] || symbol;
  }

  async initialize() {
    if (this.isInitialized) return;
    
    console.log('🚀 Initializing Real-Time Market Data Service...');
    
    // Start background data collection
    this.startDataCollection();
    
    // Initialize WebSocket connections for real-time data
    this.initializeWebSocketConnections();
    
    this.isInitialized = true;
    console.log('✅ Real-Time Market Data Service initialized');
  }

  private startDataCollection() {
    // Collect data every 30 seconds
    cron.schedule('*/30 * * * * *', async () => {
      await this.collectMarketData();
    });

    // Major update every 5 minutes
    cron.schedule('*/5 * * * *', async () => {
      await this.performMajorUpdate();
    });
  }

  private async collectMarketData() {
    const symbols = [
      'EURUSD', 'GBPUSD', 'USDJPY', 'AUDUSD', 'USDCAD', 'USDCHF', 'NZDUSD',
      'BTCUSD', 'ETHUSD', 'XAUUSD', 'XAGUSD', 'WTIUSD'
    ];

    for (const symbol of symbols) {
      try {
        const price = await this.getBestPrice(symbol);
        if (price) {
          await this.updateMarketData(symbol, price);
          this.notifySubscribers(symbol, price);
        }
      } catch (error) {
        console.error(`Error collecting data for ${symbol}:`, error);
      }
    }
  }

  private async getBestPrice(symbol: string): Promise<number | null> {
    // Try providers in priority order
    const sortedProviders = this.providers
      .filter(p => p.isActive)
      .sort((a, b) => a.priority - b.priority);

    for (const provider of sortedProviders) {
      try {
        const price = await provider.getPrice(symbol);
        if (price && price > 0) {
          // Cache the result
          if (this.redisClient) {
            await this.redisClient.setEx(`price:${symbol}`, 60, price.toString());
          }
          return price;
        }
      } catch (error) {
        console.error(`Provider ${provider.name} failed for ${symbol}:`, error);
        continue;
      }
    }

    // Fallback to cache
    if (this.redisClient) {
      try {
        const cached = await this.redisClient.get(`price:${symbol}`);
        if (cached) {
          return parseFloat(cached);
        }
      } catch (error) {
        console.error('Redis cache error:', error);
      }
    }

    return null;
  }

  private async updateMarketData(symbol: string, price: number) {
    try {
      const lastPrice = this.lastPrices.get(symbol) || price;
      const change = price - lastPrice;
      const changePercent = lastPrice > 0 ? (change / lastPrice) * 100 : 0;

      const marketData: InsertMarketData = {
        symbol,
        price,
        change,
        changePercent,
        volume: 0, // Volume data would come from specific providers
        high: price,
        low: price,
        open: lastPrice,
        timestamp: new Date()
      };

      await storage.createMarketData(marketData);
      this.lastPrices.set(symbol, price);
    } catch (error) {
      console.error(`Error updating market data for ${symbol}:`, error);
    }
  }

  private notifySubscribers(symbol: string, price: number) {
    const subscribers = this.subscribers.get(symbol);
    if (subscribers) {
      const tick: MarketTick = {
        symbol,
        price,
        timestamp: new Date()
      };

      subscribers.forEach(callback => {
        try {
          callback(tick);
        } catch (error) {
          console.error('Subscriber callback error:', error);
        }
      });
    }
  }

  private initializeWebSocketConnections() {
    // Initialize WebSocket connections for real-time feeds
    // This would connect to actual WebSocket feeds from providers
    console.log('📡 WebSocket connections ready for real-time feeds');
  }

  private async performMajorUpdate() {
    console.log('🔄 Performing major market data update...');
    
    // Update provider status
    await this.checkProviderHealth();
    
    // Clean old data
    await this.cleanOldData();
    
    console.log('✅ Major market data update completed');
  }

  private async checkProviderHealth() {
    for (const provider of this.providers) {
      try {
        const testPrice = await provider.getPrice('EURUSD');
        provider.isActive = testPrice !== null;
      } catch (error) {
        provider.isActive = false;
        console.warn(`Provider ${provider.name} health check failed`);
      }
    }
  }

  private async cleanOldData() {
    // Clean data older than 24 hours from cache
    try {
      if (this.redisClient) {
        const keys = await this.redisClient.keys('price:*');
        for (const key of keys) {
          const ttl = await this.redisClient.ttl(key);
          if (ttl === -1) { // No expiration set
            await this.redisClient.expire(key, 3600); // Set 1 hour expiration
          }
        }
      }
    } catch (error) {
      console.error('Error cleaning old data:', error);
    }
  }

  // Public API
  async getLatestPrice(symbol: string): Promise<number | null> {
    return await this.getBestPrice(symbol);
  }

  subscribe(symbol: string, callback: (data: MarketTick) => void): () => void {
    if (!this.subscribers.has(symbol)) {
      this.subscribers.set(symbol, new Set());
    }
    
    this.subscribers.get(symbol)!.add(callback);
    
    // Return unsubscribe function
    return () => {
      const symbolSubscribers = this.subscribers.get(symbol);
      if (symbolSubscribers) {
        symbolSubscribers.delete(callback);
        if (symbolSubscribers.size === 0) {
          this.subscribers.delete(symbol);
        }
      }
    };
  }

  getProviderStatus() {
    return this.providers.map(p => ({
      name: p.name,
      priority: p.priority,
      isActive: p.isActive
    }));
  }

  async getMarketSummary() {
    const symbols = ['EURUSD', 'GBPUSD', 'USDJPY', 'BTCUSD', 'ETHUSD', 'XAUUSD'];
    const summary = [];
    
    for (const symbol of symbols) {
      const price = await this.getLatestPrice(symbol);
      const lastPrice = this.lastPrices.get(symbol);
      
      if (price) {
        summary.push({
          symbol,
          price,
          change: lastPrice ? price - lastPrice : 0,
          changePercent: lastPrice && lastPrice > 0 ? ((price - lastPrice) / lastPrice) * 100 : 0
        });
      }
    }
    
    return summary;
  }
}

export const realTimeMarketDataService = new RealTimeMarketDataService();