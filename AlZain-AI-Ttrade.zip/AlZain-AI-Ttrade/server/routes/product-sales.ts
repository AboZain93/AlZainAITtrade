import type { Express } from "express";
import { z } from "zod";
import { productSalesManager } from "../services/product-sales-manager";
import { requireCommercialAuth } from "./commercial";
import { commercialStorage } from "../commercial-storage";

const createProductSchema = z.object({
  name: z.string().min(1, "اسم المنتج مطلوب"),
  nameAr: z.string().min(1, "الاسم باللغة العربية مطلوب"),
  description: z.string().min(1, "الوصف مطلوب"),
  descriptionAr: z.string().min(1, "الوصف باللغة العربية مطلوب"),
  productType: z.enum(["subscription", "license", "one-time"]),
  category: z.string().min(1, "الفئة مطلوبة"),
  priceUsd: z.number().min(0, "السعر يجب أن يكون أكبر من صفر"),
  originalPriceUsd: z.number().optional(),
  billingCycle: z.enum(["monthly", "yearly", "lifetime"]).optional(),
  features: z.array(z.string()),
  limits: z.any(),
  trialDays: z.number().min(0, "أيام التجربة يجب أن تكون أكبر من أو تساوي صفر"),
  trialTrades: z.number().min(0, "عدد صفقات التجربة يجب أن يكون أكبر من أو تساوي صفر"),
  maxDevicesAllowed: z.number().min(1, "عدد الأجهزة المسموحة يجب أن يكون على الأقل 1"),
});

const generateTrialSchema = z.object({
  productId: z.number().min(1, "معرف المنتج مطلوب"),
  customSettings: z.object({
    durationDays: z.number().optional(),
    maxTrades: z.number().optional(),
    maxDevices: z.number().optional(),
  }).optional(),
});

const purchaseSchema = z.object({
  productId: z.number().min(1, "معرف المنتج مطلوب"),
  paymentMethod: z.string().min(1, "طريقة الدفع مطلوبة"),
  paymentId: z.string().min(1, "معرف الدفع مطلوب"),
  amount: z.number().min(0, "المبلغ يجب أن يكون أكبر من صفر"),
  currency: z.string().default("USD"),
});

const validateLicenseSchema = z.object({
  licenseKey: z.string().min(1, "مفتاح الترخيص مطلوب"),
});

const revokeLicenseSchema = z.object({
  licenseKey: z.string().min(1, "مفتاح الترخيص مطلوب"),
  reason: z.string().min(1, "سبب الإلغاء مطلوب"),
});

export function registerProductSalesRoutes(app: Express) {
  
  // جلب جميع المنتجات النشطة
  app.get("/api/sales/products", async (req, res) => {
    try {
      const products = await productSalesManager.getActiveProducts();
      res.json({ 
        success: true,
        products 
      });
    } catch (error: any) {
      console.error("خطأ في جلب المنتجات:", error);
      res.status(500).json({ 
        success: false,
        message: "خطأ في جلب المنتجات",
        error: error.message 
      });
    }
  });

  // جلب منتج محدد
  app.get("/api/sales/products/:id", async (req, res) => {
    try {
      const productId = parseInt(req.params.id);
      if (isNaN(productId)) {
        return res.status(400).json({ 
          success: false,
          message: "معرف المنتج غير صحيح" 
        });
      }

      const product = await productSalesManager.getProductById(productId);
      if (!product) {
        return res.status(404).json({ 
          success: false,
          message: "المنتج غير موجود" 
        });
      }

      res.json({ 
        success: true,
        product 
      });
    } catch (error: any) {
      console.error("خطأ في جلب المنتج:", error);
      res.status(500).json({ 
        success: false,
        message: "خطأ في جلب المنتج",
        error: error.message 
      });
    }
  });

  // إنشاء منتج جديد (للمشرفين فقط)
  app.post("/api/sales/products", requireCommercialAuth, async (req: any, res) => {
    try {
      // التحقق من صلاحيات المشرف
      const user = req.commercialUser;
      if (user.subscriptionTier !== "admin") {
        return res.status(403).json({ 
          success: false,
          message: "صلاحيات المشرف مطلوبة" 
        });
      }

      const validatedData = createProductSchema.parse(req.body);
      const product = await productSalesManager.createProduct(validatedData);
      
      res.status(201).json({ 
        success: true,
        message: "تم إنشاء المنتج بنجاح",
        product 
      });
    } catch (error: any) {
      console.error("خطأ في إنشاء المنتج:", error);
      
      if (error.name === "ZodError") {
        return res.status(400).json({
          success: false,
          message: "بيانات غير صحيحة",
          errors: error.errors
        });
      }
      
      res.status(500).json({ 
        success: false,
        message: "خطأ في إنشاء المنتج",
        error: error.message 
      });
    }
  });

  // توليد ترخيص تجريبي
  app.post("/api/sales/generate-trial", requireCommercialAuth, async (req: any, res) => {
    try {
      const validatedData = generateTrialSchema.parse(req.body);
      const userId = req.commercialUser.id;

      // التحقق من الأهلية للفترة التجريبية
      const eligibility = await productSalesManager.checkTrialEligibility(userId, validatedData.productId);
      if (!eligibility.isEligible) {
        return res.status(400).json({ 
          success: false,
          message: eligibility.reason || "غير مؤهل للفترة التجريبية",
          eligibility 
        });
      }

      const license = await productSalesManager.createTrialAccess(
        userId, 
        validatedData.productId, 
        validatedData.customSettings
      );
      
      res.status(201).json({ 
        success: true,
        message: "تم إنشاء الترخيص التجريبي بنجاح",
        license,
        licenseKey: license.licenseKey
      });
    } catch (error: any) {
      console.error("خطأ في توليد الترخيص التجريبي:", error);
      
      if (error.name === "ZodError") {
        return res.status(400).json({
          success: false,
          message: "بيانات غير صحيحة",
          errors: error.errors
        });
      }
      
      res.status(500).json({ 
        success: false,
        message: "خطأ في توليد الترخيص التجريبي",
        error: error.message 
      });
    }
  });

  // شراء ترخيص مدفوع
  app.post("/api/sales/purchase", requireCommercialAuth, async (req: any, res) => {
    try {
      const validatedData = purchaseSchema.parse(req.body);
      const userId = req.commercialUser.id;

      const license = await productSalesManager.generatePaidLicense(userId, validatedData.productId, {
        paymentMethod: validatedData.paymentMethod,
        paymentId: validatedData.paymentId,
        amount: validatedData.amount,
        currency: validatedData.currency,
      });
      
      res.status(201).json({ 
        success: true,
        message: "تم شراء الترخيص بنجاح",
        license,
        licenseKey: license.licenseKey
      });
    } catch (error: any) {
      console.error("خطأ في شراء الترخيص:", error);
      
      if (error.name === "ZodError") {
        return res.status(400).json({
          success: false,
          message: "بيانات غير صحيحة",
          errors: error.errors
        });
      }
      
      res.status(500).json({ 
        success: false,
        message: "خطأ في شراء الترخيص",
        error: error.message 
      });
    }
  });

  // التحقق من صحة الترخيص
  app.post("/api/sales/validate-license", async (req, res) => {
    try {
      const validatedData = validateLicenseSchema.parse(req.body);
      const validation = await productSalesManager.validateLicense(validatedData.licenseKey);
      
      res.json({ 
        success: true,
        validation 
      });
    } catch (error: any) {
      console.error("خطأ في التحقق من الترخيص:", error);
      
      if (error.name === "ZodError") {
        return res.status(400).json({
          success: false,
          message: "بيانات غير صحيحة",
          errors: error.errors
        });
      }
      
      res.status(500).json({ 
        success: false,
        message: "خطأ في التحقق من الترخيص",
        error: error.message 
      });
    }
  });

  // جلب إحصائيات المبيعات (للمشرفين فقط)
  app.get("/api/sales/analytics", requireCommercialAuth, async (req: any, res) => {
    try {
      // التحقق من صلاحيات المشرف
      const user = req.commercialUser;
      if (user.subscriptionTier !== "admin") {
        return res.status(403).json({ 
          success: false,
          message: "صلاحيات المشرف مطلوبة" 
        });
      }

      const productId = req.query.productId ? parseInt(req.query.productId as string) : undefined;
      const analytics = await productSalesManager.getSalesAnalytics(productId);
      
      res.json({ 
        success: true,
        analytics 
      });
    } catch (error: any) {
      console.error("خطأ في جلب إحصائيات المبيعات:", error);
      res.status(500).json({ 
        success: false,
        message: "خطأ في جلب إحصائيات المبيعات",
        error: error.message 
      });
    }
  });

  // جلب إحصائيات استخدام الترخيص
  app.get("/api/sales/license-stats/:licenseKey", requireCommercialAuth, async (req: any, res) => {
    try {
      const licenseKey = req.params.licenseKey;
      const stats = await productSalesManager.getLicenseUsageStats(licenseKey);
      
      res.json({ 
        success: true,
        stats 
      });
    } catch (error: any) {
      console.error("خطأ في جلب إحصائيات الترخيص:", error);
      res.status(500).json({ 
        success: false,
        message: "خطأ في جلب إحصائيات الترخيص",
        error: error.message 
      });
    }
  });

  // إلغاء ترخيص (للمشرفين فقط)
  app.post("/api/sales/revoke-license", requireCommercialAuth, async (req: any, res) => {
    try {
      // التحقق من صلاحيات المشرف
      const user = req.commercialUser;
      if (user.subscriptionTier !== "admin") {
        return res.status(403).json({ 
          success: false,
          message: "صلاحيات المشرف مطلوبة" 
        });
      }

      const validatedData = revokeLicenseSchema.parse(req.body);
      await productSalesManager.revokeLicense(
        validatedData.licenseKey, 
        validatedData.reason, 
        user.id
      );
      
      res.json({ 
        success: true,
        message: "تم إلغاء الترخيص بنجاح" 
      });
    } catch (error: any) {
      console.error("خطأ في إلغاء الترخيص:", error);
      
      if (error.name === "ZodError") {
        return res.status(400).json({
          success: false,
          message: "بيانات غير صحيحة",
          errors: error.errors
        });
      }
      
      res.status(500).json({ 
        success: false,
        message: "خطأ في إلغاء الترخيص",
        error: error.message 
      });
    }
  });

  // التحقق من أهلية الفترة التجريبية
  app.get("/api/sales/trial-eligibility/:productId", requireCommercialAuth, async (req: any, res) => {
    try {
      const productId = parseInt(req.params.productId);
      if (isNaN(productId)) {
        return res.status(400).json({ 
          success: false,
          message: "معرف المنتج غير صحيح" 
        });
      }

      const userId = req.commercialUser.id;
      const eligibility = await productSalesManager.checkTrialEligibility(userId, productId);
      
      res.json({ 
        success: true,
        eligibility 
      });
    } catch (error: any) {
      console.error("خطأ في التحقق من أهلية التجربة:", error);
      res.status(500).json({ 
        success: false,
        message: "خطأ في التحقق من أهلية التجربة",
        error: error.message 
      });
    }
  });

  // جلب تراخيص المستخدم
  app.get("/api/sales/my-licenses", requireCommercialAuth, async (req: any, res) => {
    try {
      const userId = req.commercialUser.id;
      const licenses = await commercialStorage.getUserLicenses(userId);
      
      // إضافة معلومات إضافية لكل ترخيص
      const enhancedLicenses = await Promise.all(
        licenses.map(async (license) => {
          try {
            const stats = await productSalesManager.getLicenseUsageStats(license.licenseKey);
            const product = await productSalesManager.getProductById(license.productId!);
            return {
              ...license,
              stats,
              product,
            };
          } catch (error) {
            return license;
          }
        })
      );
      
      res.json({ 
        success: true,
        licenses: enhancedLicenses 
      });
    } catch (error: any) {
      console.error("خطأ في جلب تراخيص المستخدم:", error);
      res.status(500).json({ 
        success: false,
        message: "خطأ في جلب تراخيص المستخدم",
        error: error.message 
      });
    }
  });
}