import { Router } from "express";
import { licenseManager } from "../services/license-manager";
import { productManager } from "../services/product-manager";
import { userManager } from "../services/user-manager";

const router = Router();

// Middleware to get user from session
const getUserFromSession = async (req: any, res: any, next: any) => {
  try {
    const sessionToken = req.cookies.sessionToken || req.headers.authorization?.replace('Bearer ', '');
    
    if (!sessionToken) {
      return res.status(401).json({
        success: false,
        message: "Authentication required"
      });
    }

    const session = await userManager.getUserSessionByToken?.(sessionToken);
    if (!session || !session.isActive) {
      return res.status(401).json({
        success: false,
        message: "Invalid session"
      });
    }

    req.userId = session.userId;
    next();
  } catch (error) {
    res.status(401).json({
      success: false,
      message: "Authentication failed"
    });
  }
};

// Get all products
router.get("/products", async (req, res) => {
  try {
    const products = await productManager.getActiveProducts();
    
    res.json({
      success: true,
      products
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      message: error.message || "Failed to fetch products"
    });
  }
});

// Get product by ID
router.get("/products/:id", async (req, res) => {
  try {
    const productId = parseInt(req.params.id);
    const product = await productManager.getProduct(productId);
    
    if (!product) {
      return res.status(404).json({
        success: false,
        message: "Product not found"
      });
    }
    
    res.json({
      success: true,
      product
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      message: error.message || "Failed to fetch product"
    });
  }
});

// Start trial
router.post("/trial/:productId", getUserFromSession, async (req: any, res) => {
  try {
    const productId = parseInt(req.params.productId);
    const userAgent = req.get('User-Agent') || '';
    const ipAddress = req.ip || req.connection.remoteAddress || '';
    
    // Check if user already has an active trial for this product
    const hasActiveTrial = await licenseManager.hasActiveTrial(req.userId, productId);
    if (hasActiveTrial) {
      return res.status(400).json({
        success: false,
        message: "You already have an active trial for this product"
      });
    }
    
    const deviceFingerprint = licenseManager.generateDeviceFingerprint(userAgent, ipAddress);
    const license = await licenseManager.createTrialLicense(req.userId, productId, deviceFingerprint);
    
    res.json({
      success: true,
      message: "Trial started successfully",
      license: {
        licenseKey: license.licenseKey,
        licenseType: license.licenseType,
        maxTrades: license.maxTrades,
        tradesUsed: license.tradesUsed,
        trialEndsAt: license.trialEndsAt,
        status: license.status
      }
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      message: error.message || "Failed to start trial"
    });
  }
});

// Purchase license
router.post("/purchase/:productId", getUserFromSession, async (req: any, res) => {
  try {
    const productId = parseInt(req.params.productId);
    const { paymentId } = req.body; // This would come from payment processor
    const userAgent = req.get('User-Agent') || '';
    const ipAddress = req.ip || req.connection.remoteAddress || '';
    
    if (!paymentId) {
      return res.status(400).json({
        success: false,
        message: "Payment ID is required"
      });
    }
    
    const deviceFingerprint = licenseManager.generateDeviceFingerprint(userAgent, ipAddress);
    const license = await licenseManager.createPaidLicense(req.userId, productId, paymentId, deviceFingerprint);
    
    res.json({
      success: true,
      message: "License purchased successfully",
      license: {
        licenseKey: license.licenseKey,
        licenseType: license.licenseType,
        maxTrades: license.maxTrades,
        tradesUsed: license.tradesUsed,
        expiresAt: license.expiresAt,
        status: license.status
      }
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      message: error.message || "Failed to purchase license"
    });
  }
});

// Validate license
router.post("/validate", async (req, res) => {
  try {
    const { licenseKey } = req.body;
    const userAgent = req.get('User-Agent') || '';
    const ipAddress = req.ip || req.connection.remoteAddress || '';
    
    if (!licenseKey) {
      return res.status(400).json({
        success: false,
        message: "License key is required"
      });
    }
    
    const deviceFingerprint = licenseManager.generateDeviceFingerprint(userAgent, ipAddress);
    const validation = await licenseManager.validateLicense(licenseKey, deviceFingerprint);
    
    res.json({
      success: validation.valid,
      message: validation.message,
      license: validation.license ? {
        licenseKey: validation.license.licenseKey,
        licenseType: validation.license.licenseType,
        maxTrades: validation.license.maxTrades,
        tradesUsed: validation.license.tradesUsed,
        status: validation.license.status,
        expiresAt: validation.license.expiresAt,
        trialEndsAt: validation.license.trialEndsAt
      } : null
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      message: error.message || "Failed to validate license"
    });
  }
});

// Use trade
router.post("/use-trade", async (req, res) => {
  try {
    const { licenseKey } = req.body;
    
    if (!licenseKey) {
      return res.status(400).json({
        success: false,
        message: "License key is required"
      });
    }
    
    const success = await licenseManager.useTrade(licenseKey);
    
    if (!success) {
      return res.status(400).json({
        success: false,
        message: "Trade limit exceeded or invalid license"
      });
    }
    
    res.json({
      success: true,
      message: "Trade recorded successfully"
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      message: error.message || "Failed to record trade"
    });
  }
});

// Get user licenses
router.get("/my-licenses", getUserFromSession, async (req: any, res) => {
  try {
    const licenses = await licenseManager.getUserActiveLicenses(req.userId);
    
    res.json({
      success: true,
      licenses: licenses.map(license => ({
        licenseKey: license.licenseKey,
        licenseType: license.licenseType,
        maxTrades: license.maxTrades,
        tradesUsed: license.tradesUsed,
        status: license.status,
        expiresAt: license.expiresAt,
        trialEndsAt: license.trialEndsAt,
        activatedAt: license.activatedAt,
        productId: license.productId
      }))
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      message: error.message || "Failed to fetch licenses"
    });
  }
});

// Get license statistics
router.get("/stats/:licenseKey", async (req, res) => {
  try {
    const { licenseKey } = req.params;
    
    const stats = await licenseManager.getLicenseStats(licenseKey);
    
    res.json({
      success: true,
      stats
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      message: error.message || "Failed to fetch license stats"
    });
  }
});

// Admin routes
router.post("/admin/suspend/:licenseKey", getUserFromSession, async (req: any, res) => {
  try {
    // Check if user is admin
    const user = await userManager.getUserProfile(req.userId);
    if (!user || user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: "Admin access required"
      });
    }
    
    const { licenseKey } = req.params;
    const { reason } = req.body;
    
    await licenseManager.suspendLicense(licenseKey, reason || 'Suspended by admin');
    
    res.json({
      success: true,
      message: "License suspended successfully"
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      message: error.message || "Failed to suspend license"
    });
  }
});

router.post("/admin/reactivate/:licenseKey", getUserFromSession, async (req: any, res) => {
  try {
    // Check if user is admin
    const user = await userManager.getUserProfile(req.userId);
    if (!user || user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: "Admin access required"
      });
    }
    
    const { licenseKey } = req.params;
    
    await licenseManager.reactivateLicense(licenseKey);
    
    res.json({
      success: true,
      message: "License reactivated successfully"
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      message: error.message || "Failed to reactivate license"
    });
  }
});

export default router;