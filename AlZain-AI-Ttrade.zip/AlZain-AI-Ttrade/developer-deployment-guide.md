# دليل نشر التطبيق للمطور

## كيفية الوصول للتطبيق كمطور بعد النشر

### 1. الوصول المباشر للوحة تحكم المطور

#### الرابط الأساسي:
```
https://your-domain.com/developer-admin?devKey=dev-2025-alzain-trade
```

#### أمثلة للروابط:
- **Replit Deployment**: `https://your-repl-name.your-username.repl.co/developer-admin?devKey=dev-2025-alzain-trade`
- **Vercel**: `https://your-app.vercel.app/developer-admin?devKey=dev-2025-alzain-trade`
- **Netlify**: `https://your-app.netlify.app/developer-admin?devKey=dev-2025-alzain-trade`
- **Custom Domain**: `https://yourdomain.com/developer-admin?devKey=dev-2025-alzain-trade`

### 2. API للوصول المبرمج

#### Headers المطلوبة:
```http
x-dev-key: dev-2025-alzain-trade
Content-Type: application/json
```

#### أمثلة لاستخدام API:

##### إنشاء منتج جديد:
```bash
curl -X POST https://your-domain.com/api/developer/products \
  -H "x-dev-key: dev-2025-alzain-trade" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Premium Trading Plan",
    "nameAr": "خطة التداول المتقدمة",
    "priceUsd": 4999,
    "productType": "subscription",
    "features": ["إشارات غير محدودة", "دعم مباشر"],
    "trialDays": 7,
    "trialTrades": 10
  }'
```

##### إنشاء تراخيص:
```bash
curl -X POST https://your-domain.com/api/developer/licenses \
  -H "x-dev-key: dev-2025-alzain-trade" \
  -H "Content-Type: application/json" \
  -d '{
    "productId": 1,
    "licenseType": "trial",
    "quantity": 100
  }'
```

##### عرض الإحصائيات:
```bash
curl https://your-domain.com/api/developer/stats?devKey=dev-2025-alzain-trade
```

### 3. أدوات إدارة التطبيق

#### ملف JavaScript للإدارة:
```javascript
// developer-manager.js
const DEV_KEY = 'dev-2025-alzain-trade';
const BASE_URL = 'https://your-domain.com';

class DeveloperManager {
  constructor(baseUrl, devKey) {
    this.baseUrl = baseUrl;
    this.devKey = devKey;
  }

  async request(endpoint, options = {}) {
    const url = `${this.baseUrl}${endpoint}`;
    const config = {
      ...options,
      headers: {
        'x-dev-key': this.devKey,
        'Content-Type': 'application/json',
        ...options.headers
      }
    };
    
    const response = await fetch(url, config);
    return response.json();
  }

  // إنشاء منتج
  async createProduct(productData) {
    return this.request('/api/developer/products', {
      method: 'POST',
      body: JSON.stringify(productData)
    });
  }

  // إنشاء تراخيص
  async createLicenses(licenseData) {
    return this.request('/api/developer/licenses', {
      method: 'POST',
      body: JSON.stringify(licenseData)
    });
  }

  // عرض الإحصائيات
  async getStats() {
    return this.request('/api/developer/stats');
  }

  // عرض جميع التراخيص
  async getAllLicenses() {
    return this.request('/api/developer/licenses');
  }

  // تصدير التراخيص
  async exportLicenses() {
    const response = await fetch(`${this.baseUrl}/api/developer/licenses/export?devKey=${this.devKey}`);
    return response.text();
  }
}

// الاستخدام
const manager = new DeveloperManager(BASE_URL, DEV_KEY);

// مثال لإنشاء منتج وتراخيص
async function setupNewProduct() {
  // إنشاء المنتج
  const product = await manager.createProduct({
    name: 'Basic Plan',
    nameAr: 'الخطة الأساسية',
    priceUsd: 1999,
    productType: 'subscription',
    features: ['10 إشارات يومية'],
    trialDays: 7
  });

  // إنشاء 50 ترخيص تجريبي
  const licenses = await manager.createLicenses({
    productId: product.product.id,
    licenseType: 'trial',
    quantity: 50
  });

  console.log('تم إنشاء المنتج والتراخيص بنجاح');
}
```

### 4. تكامل مع أنظمة إدارة المحتوى

#### WordPress Plugin:
```php
<?php
// alzain-trade-manager.php
class AlzainTradeManager {
    private $devKey = 'dev-2025-alzain-trade';
    private $baseUrl = 'https://your-domain.com';

    public function createLicense($productId, $type = 'trial') {
        $data = [
            'productId' => $productId,
            'licenseType' => $type,
            'quantity' => 1
        ];

        $response = wp_remote_post($this->baseUrl . '/api/developer/licenses', [
            'headers' => [
                'x-dev-key' => $this->devKey,
                'Content-Type' => 'application/json'
            ],
            'body' => json_encode($data)
        ]);

        return json_decode(wp_remote_retrieve_body($response), true);
    }

    public function getStats() {
        $response = wp_remote_get($this->baseUrl . '/api/developer/stats?devKey=' . $this->devKey);
        return json_decode(wp_remote_retrieve_body($response), true);
    }
}

// إنشاء ترخيص عند شراء المنتج
add_action('woocommerce_order_status_completed', function($order_id) {
    $manager = new AlzainTradeManager();
    $license = $manager->createLicense(1, 'paid');
    
    // إرسال الترخيص للعميل
    $order = wc_get_order($order_id);
    $order->add_order_note('License Key: ' . $license['licenses'][0]['licenseKey']);
});
?>
```

### 5. مراقبة النظام

#### سكريبت مراقبة:
```bash
#!/bin/bash
# monitor-system.sh

DEV_KEY="dev-2025-alzain-trade"
DOMAIN="https://your-domain.com"

# فحص حالة النظام
check_system() {
    echo "فحص حالة النظام..."
    
    # فحص الإحصائيات
    STATS=$(curl -s "${DOMAIN}/api/developer/stats?devKey=${DEV_KEY}")
    echo "الإحصائيات: $STATS"
    
    # فحص عدد التراخيص النشطة
    LICENSES=$(curl -s "${DOMAIN}/api/developer/licenses?devKey=${DEV_KEY}")
    ACTIVE_COUNT=$(echo "$LICENSES" | jq '[.[] | select(.isValid == true)] | length')
    echo "التراخيص النشطة: $ACTIVE_COUNT"
    
    # إرسال تنبيه إذا كان العدد منخفض
    if [ "$ACTIVE_COUNT" -lt 10 ]; then
        echo "تحذير: عدد التراخيص النشطة منخفض ($ACTIVE_COUNT)"
        # يمكن إضافة إرسال إيميل أو رسالة
    fi
}

# تشغيل الفحص كل ساعة
while true; do
    check_system
    sleep 3600
done
```

### 6. نسخ احتياطية للبيانات

#### سكريبت النسخ الاحتياطي:
```bash
#!/bin/bash
# backup-data.sh

DEV_KEY="dev-2025-alzain-trade"
DOMAIN="https://your-domain.com"
BACKUP_DIR="/backups/alzain-trade"

# إنشاء مجلد النسخ الاحتياطية
mkdir -p "$BACKUP_DIR"

# تاريخ اليوم
DATE=$(date +%Y%m%d_%H%M%S)

# تصدير التراخيص
echo "تصدير التراخيص..."
curl -s "${DOMAIN}/api/developer/licenses/export?devKey=${DEV_KEY}" > "${BACKUP_DIR}/licenses_${DATE}.csv"

# تصدير الإحصائيات
echo "تصدير الإحصائيات..."
curl -s "${DOMAIN}/api/developer/stats?devKey=${DEV_KEY}" > "${BACKUP_DIR}/stats_${DATE}.json"

# تصدير المنتجات
echo "تصدير المنتجات..."
curl -s "${DOMAIN}/api/developer/products?devKey=${DEV_KEY}" > "${BACKUP_DIR}/products_${DATE}.json"

# تصدير المستخدمين
echo "تصدير المستخدمين..."
curl -s "${DOMAIN}/api/developer/users?devKey=${DEV_KEY}" > "${BACKUP_DIR}/users_${DATE}.json"

echo "تم الانتهاء من النسخ الاحتياطي: $DATE"

# حذف النسخ القديمة (أكثر من 30 يوم)
find "$BACKUP_DIR" -name "*.csv" -o -name "*.json" -mtime +30 -delete
```

### 7. أمان التطبيق

#### تحديث مفتاح المطور:
1. قم بتحديث المفتاح في ملف البيئة:
```bash
DEV_KEY=your-new-secure-key-2025
```

2. أو قم بتحديثه في الكود:
```javascript
// في server/routes/developer-routes.ts
const isDeveloper = (req: any, res: any, next: any) => {
  const devKey = req.headers['x-dev-key'] || req.query.devKey;
  if (devKey !== 'your-new-secure-key-2025') {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  next();
};
```

### 8. نشر التطبيق

#### متغيرات البيئة المطلوبة:
```env
DATABASE_URL=postgresql://...
JWT_SECRET=your-jwt-secret
DEV_KEY=dev-2025-alzain-trade
TELEGRAM_BOT_TOKEN=your-bot-token
TELEGRAM_CHAT_ID=your-chat-id
```

#### خطوات النشر على Replit:
1. ارفع الكود إلى Replit
2. اضبط متغيرات البيئة في Secrets
3. اضغط "Deploy" 
4. استخدم الرابط: `https://your-repl.your-username.repl.co/developer-admin?devKey=dev-2025-alzain-trade`

#### خطوات النشر على Vercel:
1. ربط Repository بـ Vercel
2. اضبط متغيرات البيئة
3. Deploy
4. استخدم الرابط: `https://your-app.vercel.app/developer-admin?devKey=dev-2025-alzain-trade`

هذا الدليل يوفر لك كل ما تحتاجه للوصول والتحكم بالتطبيق كمطور بعد نشره كتطبيق ويب.