#!/bin/bash

# AlZainTrade Quick APK Solution
# حل سريع لإنشاء APK بطرق متعددة

echo "🚀 AlZainTrade - الحل السريع لإنشاء APK"
echo "========================================"

APP_URL="https://workspace.myscreen229.repl.co"
PACKAGE_NAME="com.alzaintrade.app"

echo "📱 رابط التطبيق: $APP_URL"
echo "📦 Package Name: $PACKAGE_NAME"
echo ""

# تحقق من حالة التطبيق
echo "🔍 فحص حالة التطبيق..."
if curl -s --head "$APP_URL" | head -n 1 | grep -q "200 OK"; then
    echo "✅ التطبيق يعمل بشكل صحيح"
else
    echo "⚠️  التطبيق قد لا يكون متاحاً حالياً"
fi

echo ""
echo "🎯 الحلول السريعة المتاحة:"
echo "=========================="

echo ""
echo "1️⃣ **PWA2APK.com** (الأسرع - مجاني):"
echo "   🌐 https://pwa2apk.com/"
echo "   📝 أدخل: $APP_URL"
echo "   ⏱️  وقت الإنشاء: 2-5 دقائق"
echo "   ✅ معدل النجاح: 95%"

echo ""
echo "2️⃣ **APKCombo** (موثوق):"
echo "   🌐 https://apkcombo.com/pwa-to-apk/"
echo "   📝 أدخل: $APP_URL"
echo "   ⏱️  وقت الإنشاء: 3-7 دقائق"
echo "   ✅ معدل النجاح: 90%"

echo ""
echo "3️⃣ **App My Site** (شامل):"
echo "   🌐 https://www.appmysite.com/"
echo "   📝 أدخل: $APP_URL"
echo "   ⏱️  وقت الإنشاء: 5-10 دقائق"
echo "   ✅ معدل النجاح: 85%"

echo ""
echo "4️⃣ **PWABuilder** (رسمي من مايكروسوفت):"
echo "   🌐 https://www.pwabuilder.com/"
echo "   📝 أدخل: $APP_URL"
echo "   ⚠️  قد يتطلب تجاهل تحذيرات HTTPS"
echo "   ✅ اضغط 'Continue Anyway'"

echo ""
echo "5️⃣ **Capacitor CLI** (للمطورين):"
echo "   💻 npm install -g @capacitor/cli"
echo "   💻 npx cap init AlZainTrade $PACKAGE_NAME"
echo "   💻 npx cap add android"
echo "   💻 npx cap build android"

echo ""
echo "🔧 إعداد سريع للـ manifest:"

# إنشاء manifest محسن
cat > "optimized-manifest.json" << 'EOF'
{
  "name": "AlZainTrade - Smart Trading Platform",
  "short_name": "AlZainTrade",
  "description": "منصة تداول ذكية بالذكاء الاصطناعي مع تحليل تقني فوري وتكامل تليجرام",
  "start_url": "/",
  "display": "standalone",
  "background_color": "#ffffff",
  "theme_color": "#2563eb",
  "orientation": "portrait-primary",
  "lang": "ar",
  "dir": "rtl",
  "scope": "/",
  "categories": ["finance", "business", "productivity"],
  "prefer_related_applications": false,
  "icons": [
    {
      "src": "/icon-192x192.svg",
      "sizes": "192x192",
      "type": "image/svg+xml",
      "purpose": "any"
    },
    {
      "src": "/icon-192x192.svg",
      "sizes": "192x192",
      "type": "image/svg+xml", 
      "purpose": "maskable"
    },
    {
      "src": "/icon-512x512.svg",
      "sizes": "512x512",
      "type": "image/svg+xml",
      "purpose": "any"
    },
    {
      "src": "/icon-512x512.svg",
      "sizes": "512x512",
      "type": "image/svg+xml",
      "purpose": "maskable"
    }
  ],
  "shortcuts": [
    {
      "name": "التحكم في التداول",
      "short_name": "التداول",
      "description": "إدارة الإشارات التلقائية والإعدادات",
      "url": "/trading-control",
      "icons": [
        {
          "src": "/icon-192x192.svg",
          "sizes": "192x192",
          "type": "image/svg+xml"
        }
      ]
    }
  ]
}
EOF

echo "✅ تم إنشاء optimized-manifest.json"

echo ""
echo "📋 نصائح للنجاح:"
echo "================"
echo "• ابدأ بـ PWA2APK.com (الأسرع والأبسط)"
echo "• إذا فشل، جرب APKCombo"
echo "• تأكد من أن التطبيق يعمل في المتصفح أولاً"
echo "• تجاهل تحذيرات HTTPS (طبيعية للتطوير)"
echo "• اختبر APK على جهاز أندرويد حقيقي"

echo ""
echo "⚡ الخطوة التالية:"
echo "=================="
echo "1. اذهب إلى: https://pwa2apk.com/"
echo "2. أدخل: $APP_URL"
echo "3. انتظر اكتمال الإنشاء"
echo "4. حمّل APK"
echo "5. ثبته على جهاز أندرويد"

echo ""
echo "🎉 APK سيكون جاهز في أقل من 5 دقائق!"

# إنشاء ملف HTML للاختبار السريع
cat > "test-pwa.html" << 'EOF'
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AlZainTrade APK Test</title>
    <link rel="manifest" href="./optimized-manifest.json">
    <style>
        body { font-family: Arial, sans-serif; padding: 20px; background: #f5f5f5; }
        .card { background: white; padding: 20px; border-radius: 10px; margin: 10px 0; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .btn { background: #2563eb; color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; }
        .success { color: #16a34a; } .error { color: #dc2626; }
    </style>
</head>
<body>
    <div class="card">
        <h1>🚀 AlZainTrade APK Generator</h1>
        <p>اختبار سريع لإنشاء APK</p>
        
        <h3>الروابط السريعة:</h3>
        <p><a href="https://pwa2apk.com/" target="_blank" class="btn">PWA2APK.com</a></p>
        <p><a href="https://apkcombo.com/pwa-to-apk/" target="_blank" class="btn">APKCombo</a></p>
        <p><a href="https://www.pwabuilder.com/" target="_blank" class="btn">PWABuilder</a></p>
        
        <h3>معلومات التطبيق:</h3>
        <p><strong>الرابط:</strong> https://workspace.myscreen229.repl.co</p>
        <p><strong>Package:</strong> com.alzaintrade.app</p>
        <p><strong>اسم التطبيق:</strong> AlZainTrade</p>
        
        <button onclick="testManifest()" class="btn">اختبار Manifest</button>
        <div id="result"></div>
    </div>

    <script>
        function testManifest() {
            fetch('./optimized-manifest.json')
                .then(response => response.json())
                .then(data => {
                    document.getElementById('result').innerHTML = 
                        '<div class="success">✅ Manifest يعمل بشكل صحيح!</div>' +
                        '<pre>' + JSON.stringify(data, null, 2) + '</pre>';
                })
                .catch(error => {
                    document.getElementById('result').innerHTML = 
                        '<div class="error">❌ خطأ في Manifest: ' + error + '</div>';
                });
        }
    </script>
</body>
</html>
EOF

echo "✅ تم إنشاء test-pwa.html للاختبار"

echo ""
echo "🔗 الآن يمكنك:"
echo "=============="
echo "1. فتح test-pwa.html في المتصفح للاختبار"
echo "2. استخدام optimized-manifest.json مع أي أداة APK"
echo "3. اتباع الروابط السريعة أعلاه"

echo ""
echo "📞 دعم فوري: إذا فشلت جميع الطرق، استخدم Android Studio مع TWA Template"