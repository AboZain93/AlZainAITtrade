import {
  pgTable,
  text,
  varchar,
  integer,
  boolean,
  timestamp,
  jsonb,
  serial,
  primaryKey,
  unique,
  index,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Commercial Users Table
export const commercialUsers = pgTable("commercial_users", {
  id: varchar("id").primaryKey().notNull().$defaultFn(() => `user_${Date.now()}_${Math.random().toString(36).substring(2)}`),
  username: varchar("username", { length: 50 }).unique().notNull(),
  email: varchar("email", { length: 255 }).unique().notNull(),
  passwordHash: varchar("password_hash").notNull(),
  firstName: varchar("first_name", { length: 100 }),
  lastName: varchar("last_name", { length: 100 }),
  phoneNumber: varchar("phone_number", { length: 20 }),
  countryCode: varchar("country_code", { length: 10 }),
  companyName: varchar("company_name", { length: 200 }),
  isActive: boolean("is_active").default(true).notNull(),
  emailVerified: boolean("email_verified").default(false).notNull(),
  phoneVerified: boolean("phone_verified").default(false).notNull(),
  subscriptionStatus: varchar("subscription_status", { length: 50 }).default("free").notNull(),
  subscriptionTier: varchar("subscription_tier", { length: 50 }).default("basic").notNull(),
  subscriptionStartDate: timestamp("subscription_start_date"),
  subscriptionEndDate: timestamp("subscription_end_date"),
  trialEndDate: timestamp("trial_end_date"),
  dailySignalsUsed: integer("daily_signals_used").default(0).notNull(),
  monthlySignalsUsed: integer("monthly_signals_used").default(0).notNull(),
  totalSignalsUsed: integer("total_signals_used").default(0).notNull(),
  lastSignalDate: timestamp("last_signal_date"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
  lastLogin: timestamp("last_login"),
  loginAttempts: integer("login_attempts").default(0).notNull(),
  lockedUntil: timestamp("locked_until"),
}, (table) => [
  index("idx_commercial_users_email").on(table.email),
  index("idx_commercial_users_username").on(table.username),
  index("idx_commercial_users_subscription").on(table.subscriptionStatus),
]);

// Products Table
export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 200 }).notNull(),
  nameAr: varchar("name_ar", { length: 200 }),
  description: text("description"),
  descriptionAr: text("description_ar"),
  productType: varchar("product_type", { length: 50 }).notNull(), // subscription, license, one-time
  category: varchar("category", { length: 100 }).notNull(),
  priceUsd: integer("price_usd").notNull(), // Price in cents
  originalPriceUsd: integer("original_price_usd"),
  billingCycle: varchar("billing_cycle", { length: 50 }), // monthly, yearly, lifetime
  features: jsonb("features").notNull().$type<string[]>(),
  limits: jsonb("limits").notNull(),
  trialDays: integer("trial_days").default(7).notNull(), // فترة التجربة بالأيام
  trialTrades: integer("trial_trades").default(10).notNull(), // عدد الصفقات المجانية للتجربة
  maxDevicesAllowed: integer("max_devices_allowed").default(1).notNull(), // عدد الأجهزة المسموحة
  autoGenerateTrialKey: boolean("auto_generate_trial_key").default(true).notNull(), // توليد مفتاح تجريبي تلقائي
  isPopular: boolean("is_popular").default(false).notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  sortOrder: integer("sort_order").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => [
  index("idx_products_active").on(table.isActive),
  index("idx_products_category").on(table.category),
  index("idx_products_sort").on(table.sortOrder),
  index("idx_products_trial").on(table.autoGenerateTrialKey),
]);

// Licenses Table
export const licenses = pgTable("licenses", {
  id: serial("id").primaryKey(),
  productId: integer("product_id").references(() => products.id).notNull(),
  userId: varchar("user_id").references(() => commercialUsers.id).notNull(),
  licenseKey: varchar("license_key", { length: 255 }).unique().notNull(),
  licenseType: varchar("license_type", { length: 50 }).notNull(), // trial, paid, lifetime
  maxTrades: integer("max_trades"), // حد الصفقات للفترة التجريبية
  maxDevices: integer("max_devices").default(1).notNull(),
  trialDurationDays: integer("trial_duration_days"), // مدة التجربة بالأيام
  trialTradesRemaining: integer("trial_trades_remaining"), // الصفقات المتبقية للتجربة
  isActivated: boolean("is_activated").default(false).notNull(),
  isValid: boolean("is_valid").default(true).notNull(),
  isRevoked: boolean("is_revoked").default(false).notNull(),
  isTrial: boolean("is_trial").default(false).notNull(), // هل هذا ترخيص تجريبي
  activatedAt: timestamp("activated_at"),
  expiresAt: timestamp("expires_at"),
  trialStartDate: timestamp("trial_start_date"), // تاريخ بداية التجربة
  trialEndDate: timestamp("trial_end_date"), // تاريخ انتهاء التجربة
  deviceFingerprint: varchar("device_fingerprint"),
  activationCount: integer("activation_count").default(0).notNull(),
  usageCount: integer("usage_count").default(0).notNull(),
  tradesUsed: integer("trades_used").default(0).notNull(), // عدد الصفقات المستخدمة
  lastUsed: timestamp("last_used"),
  notes: text("notes"),
  revokedAt: timestamp("revoked_at"),
  revokedBy: integer("revoked_by"),
  revokedReason: text("revoked_reason"),
  generatedBy: integer("generated_by"),
  cancellationReason: text("cancellation_reason"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => [
  index("idx_licenses_user").on(table.userId),
  index("idx_licenses_product").on(table.productId),
  index("idx_licenses_key").on(table.licenseKey),
  index("idx_licenses_status").on(table.isValid, table.isRevoked),
  index("idx_licenses_trial").on(table.isTrial),
  index("idx_licenses_expiry").on(table.expiresAt),
]);

// User Sessions Table
export const userSessions = pgTable("user_sessions", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => commercialUsers.id).notNull(),
  sessionToken: varchar("session_token", { length: 255 }).unique().notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  deviceInfo: varchar("device_info"),
  ipAddress: varchar("ip_address", { length: 45 }),
  userAgent: text("user_agent"),
  lastActivity: timestamp("last_activity").defaultNow(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => [
  index("idx_sessions_token").on(table.sessionToken),
  index("idx_sessions_user").on(table.userId),
  index("idx_sessions_active").on(table.isActive),
]);

// Purchase History Table
export const purchaseHistory = pgTable("purchase_history", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => commercialUsers.id).notNull(),
  productId: integer("product_id").references(() => products.id).notNull(),
  licenseId: integer("license_id").references(() => licenses.id),
  amount: integer("amount").notNull(), // Amount in cents
  currency: varchar("currency", { length: 3 }).default("USD").notNull(),
  paymentMethod: varchar("payment_method", { length: 50 }).notNull(),
  paymentId: varchar("payment_id").notNull(), // Stripe payment intent ID
  status: varchar("status", { length: 50 }).notNull(), // pending, completed, failed, refunded
  metadata: jsonb("metadata"),
  refundedAt: timestamp("refunded_at"),
  refundAmount: integer("refund_amount"),
  refundReason: text("refund_reason"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => [
  index("idx_purchases_user").on(table.userId),
  index("idx_purchases_product").on(table.productId),
  index("idx_purchases_status").on(table.status),
  index("idx_purchases_payment").on(table.paymentId),
]);

// Audit Logs Table
export const auditLogs = pgTable("audit_logs", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => commercialUsers.id),
  action: varchar("action", { length: 100 }).notNull(),
  description: text("description"),
  ipAddress: varchar("ip_address", { length: 45 }),
  userAgent: text("user_agent"),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => [
  index("idx_audit_user").on(table.userId),
  index("idx_audit_action").on(table.action),
  index("idx_audit_created").on(table.createdAt),
]);

// Email Verification Tokens Table
export const emailVerificationTokens = pgTable("email_verification_tokens", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => commercialUsers.id).notNull(),
  token: varchar("token", { length: 255 }).unique().notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  used: boolean("used").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => [
  index("idx_email_tokens_user").on(table.userId),
  index("idx_email_tokens_token").on(table.token),
]);

// Password Reset Tokens Table
export const passwordResetTokens = pgTable("password_reset_tokens", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => commercialUsers.id).notNull(),
  token: varchar("token", { length: 255 }).unique().notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  used: boolean("used").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => [
  index("idx_reset_tokens_user").on(table.userId),
  index("idx_reset_tokens_token").on(table.token),
]);

// Device Management Table
export const userDevices = pgTable("user_devices", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => commercialUsers.id).notNull(),
  licenseId: integer("license_id").references(() => licenses.id),
  deviceFingerprint: varchar("device_fingerprint").notNull(),
  deviceName: varchar("device_name"),
  deviceType: varchar("device_type", { length: 50 }),
  platform: varchar("platform", { length: 50 }),
  isActive: boolean("is_active").default(true).notNull(),
  lastUsed: timestamp("last_used"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => [
  index("idx_devices_user").on(table.userId),
  index("idx_devices_license").on(table.licenseId),
  index("idx_devices_fingerprint").on(table.deviceFingerprint),
  unique("unique_user_device").on(table.userId, table.deviceFingerprint),
]);

// Notifications Table
export const userNotifications = pgTable("user_notifications", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => commercialUsers.id).notNull(),
  type: varchar("type", { length: 50 }).notNull(),
  title: varchar("title", { length: 200 }).notNull(),
  message: text("message").notNull(),
  data: jsonb("data"),
  read: boolean("read").default(false).notNull(),
  readAt: timestamp("read_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => [
  index("idx_notifications_user").on(table.userId),
  index("idx_notifications_read").on(table.read),
  index("idx_notifications_type").on(table.type),
]);

// Zod Schemas for validation
export const insertCommercialUserSchema = createInsertSchema(commercialUsers).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertProductSchema = createInsertSchema(products).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertLicenseSchema = createInsertSchema(licenses).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertPurchaseSchema = createInsertSchema(purchaseHistory).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Types
export type CommercialUser = typeof commercialUsers.$inferSelect;
export type InsertCommercialUser = z.infer<typeof insertCommercialUserSchema>;

export type Product = typeof products.$inferSelect;
export type InsertProduct = z.infer<typeof insertProductSchema>;

export type License = typeof licenses.$inferSelect;
export type InsertLicense = z.infer<typeof insertLicenseSchema>;

export type UserSession = typeof userSessions.$inferSelect;
export type PurchaseHistory = typeof purchaseHistory.$inferSelect;
export type InsertPurchase = z.infer<typeof insertPurchaseSchema>;

export type AuditLog = typeof auditLogs.$inferSelect;
export type UserNotification = typeof userNotifications.$inferSelect;
export type UserDevice = typeof userDevices.$inferSelect;