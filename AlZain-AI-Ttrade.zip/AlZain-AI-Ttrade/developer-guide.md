# دليل المطور - نظام التحكم الكامل

## كيفية الوصول لنظام التحكم

### 1. الوصول للوحة تحكم المطور
- اذهب إلى: `http://localhost:5000/developer-admin`
- استخدم مفتاح المطور: `dev-2025-alzain-trade`
- يمكن إضافة المفتاح كمعامل في الرابط: `?devKey=dev-2025-alzain-trade`

### 2. API الخاص بالمطور
جميع endpoints تحتاج header أو query parameter:
```
x-dev-key: dev-2025-alzain-trade
```

## إدارة المنتجات

### إنشاء منتج جديد
```bash
curl -X POST http://localhost:5000/api/developer/products \
  -H "x-dev-key: dev-2025-alzain-trade" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Premium Trading Signals",
    "nameAr": "إشارات التداول المتقدمة",
    "description": "Advanced AI-powered trading signals",
    "descriptionAr": "إشارات تداول بالذكاء الاصطناعي",
    "priceUsd": 2999,
    "originalPriceUsd": 4999,
    "productType": "subscription",
    "category": "trading",
    "billingCycle": "monthly",
    "features": ["إشارات غير محدودة", "دعم متقدم", "تحليل فني"],
    "limits": {
      "dailySignals": 100,
      "monthlySignals": 3000,
      "devices": 3
    },
    "trialDays": 7,
    "trialTrades": 10,
    "maxDevicesAllowed": 3,
    "isPopular": true,
    "isActive": true
  }'
```

### عرض جميع المنتجات
```bash
curl http://localhost:5000/api/developer/products?devKey=dev-2025-alzain-trade
```

## إدارة التراخيص

### إنشاء تراخيص تجريبية
```bash
curl -X POST http://localhost:5000/api/developer/licenses \
  -H "x-dev-key: dev-2025-alzain-trade" \
  -H "Content-Type: application/json" \
  -d '{
    "productId": 1,
    "licenseType": "trial",
    "maxTrades": 10,
    "trialDurationDays": 7,
    "quantity": 10
  }'
```

### إنشاء تراخيص مدفوعة
```bash
curl -X POST http://localhost:5000/api/developer/licenses \
  -H "x-dev-key: dev-2025-alzain-trade" \
  -H "Content-Type: application/json" \
  -d '{
    "productId": 1,
    "licenseType": "paid",
    "maxTrades": 1000,
    "trialDurationDays": 30,
    "quantity": 5
  }'
```

### عرض جميع التراخيص
```bash
curl http://localhost:5000/api/developer/licenses?devKey=dev-2025-alzain-trade
```

### إلغاء ترخيص
```bash
curl -X POST http://localhost:5000/api/developer/licenses/revoke \
  -H "x-dev-key: dev-2025-alzain-trade" \
  -H "Content-Type: application/json" \
  -d '{
    "licenseKey": "AZT-XXXX-XXXX-XXXX",
    "reason": "License violated terms"
  }'
```

### تصدير التراخيص (CSV)
```bash
curl http://localhost:5000/api/developer/licenses/export?devKey=dev-2025-alzain-trade > licenses.csv
```

## إدارة المستخدمين

### عرض جميع المستخدمين
```bash
curl http://localhost:5000/api/developer/users?devKey=dev-2025-alzain-trade
```

### عرض تفاصيل مستخدم معين
```bash
curl http://localhost:5000/api/developer/users/USER_ID?devKey=dev-2025-alzain-trade
```

### تحديث مستخدم
```bash
curl -X PUT http://localhost:5000/api/developer/users/USER_ID \
  -H "x-dev-key: dev-2025-alzain-trade" \
  -H "Content-Type: application/json" \
  -d '{
    "subscriptionStatus": "active",
    "subscriptionTier": "premium"
  }'
```

## توليد مفاتيح ترخيص

### توليد مفاتيح جديدة
```bash
curl -X POST http://localhost:5000/api/developer/licenses/generate \
  -H "x-dev-key: dev-2025-alzain-trade" \
  -H "Content-Type: application/json" \
  -d '{
    "count": 100,
    "prefix": "AZT"
  }'
```

## الإحصائيات والتحليلات

### عرض إحصائيات النظام
```bash
curl http://localhost:5000/api/developer/stats?devKey=dev-2025-alzain-trade
```

## أمثلة عملية

### 1. إنشاء منتج وتراخيص كاملة
```bash
# إنشاء منتج
PRODUCT_RESPONSE=$(curl -s -X POST http://localhost:5000/api/developer/products \
  -H "x-dev-key: dev-2025-alzain-trade" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Basic Trading Plan",
    "nameAr": "الخطة الأساسية",
    "priceUsd": 1999,
    "productType": "subscription",
    "features": ["10 إشارات يومية", "دعم أساسي"],
    "trialDays": 7,
    "trialTrades": 5
  }')

# استخراج ID المنتج
PRODUCT_ID=$(echo $PRODUCT_RESPONSE | jq -r '.product.id')

# إنشاء 50 ترخيص تجريبي
curl -X POST http://localhost:5000/api/developer/licenses \
  -H "x-dev-key: dev-2025-alzain-trade" \
  -H "Content-Type: application/json" \
  -d "{
    \"productId\": $PRODUCT_ID,
    \"licenseType\": \"trial\",
    \"quantity\": 50
  }"
```

### 2. إدارة دورة حياة المنتج الكاملة
```bash
# 1. إنشاء المنتج
# 2. إنشاء تراخيص تجريبية ومدفوعة
# 3. مراقبة الاستخدام
# 4. إدارة المستخدمين
# 5. تحليل الأداء
```

## نصائح مهمة

### 1. حفظ مفاتيح التراخيص
- احتفظ بنسخة من جميع المفاتيح المولدة
- استخدم CSV export بانتظام للنسخ الاحتياطي

### 2. مراقبة الاستخدام
- راقب إحصائيات النظام يومياً
- تتبع أداء المنتجات والتراخيص

### 3. أمان النظام
- غير مفتاح المطور بانتظام
- راقب محاولات الوصول غير المصرح بها

### 4. إدارة قاعدة البيانات
- أنشئ نسخ احتياطية منتظمة
- راقب حجم البيانات والأداء

## متغيرات البيئة المطلوبة

```bash
DATABASE_URL=postgresql://...
JWT_SECRET=your-secret-key
DEV_KEY=dev-2025-alzain-trade  # اختياري
```

## هيكل قاعدة البيانات

### الجداول الرئيسية:
- `commercial_users` - المستخدمين
- `products` - المنتجات
- `licenses` - التراخيص
- `user_sessions` - جلسات المستخدمين
- `purchase_history` - تاريخ المشتريات
- `audit_logs` - سجل النشاطات

## الدعم والصيانة

### مراقبة النظام
- تحقق من logs الخادم بانتظام
- راقب استهلاك الموارد
- تتبع أخطاء API

### النسخ الاحتياطي
- نسخ احتياطي يومي لقاعدة البيانات
- حفظ ملفات التكوين
- نسخ احتياطي للتراخيص المولدة

هذا الدليل يوفر لك التحكم الكامل في النظام التجاري كمطور. استخدم هذه الأدوات لإدارة منتجاتك وتراخيصك بكفاءة عالية.