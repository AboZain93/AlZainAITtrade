#!/bin/bash

# إعداد Cordova لإنشاء APK

echo "📱 إعداد Cordova..."

# تثبيت Cordova
npm install -g cordova

# إنشاء مشروع جديد
cordova create alzaintrade com.alzaintrade.app "AlZainTrade"
cd alzaintrade

# إضافة منصة الأندرويد
cordova platform add android

# نسخ ملفات التطبيق
echo "📂 نسخ ملفات PWA..."

# تحديث config.xml
cat > config.xml << 'EOF'
<?xml version='1.0' encoding='utf-8'?>
<widget id="com.alzaintrade.app" version="1.0.0" xmlns="http://www.w3.org/ns/widgets" xmlns:cdv="http://cordova.apache.org/ns/1.0">
    <name>AlZainTrade</name>
    <description>منصة تداول ذكية بالذكاء الاصطناعي</description>
    <author email="support@alzaintrade.com" href="https://alzaintrade.com">AlZainTrade Team</author>
    <content src="https://workspace.myscreen229.repl.co" />
    <allow-navigation href="https://workspace.myscreen229.repl.co/*" />
    <allow-intent href="http://*/*" />
    <allow-intent href="https://*/*" />
    <platform name="android">
        <allow-intent href="market:*" />
        <icon density="ldpi" src="res/icon/android/ldpi.png" />
        <icon density="mdpi" src="res/icon/android/mdpi.png" />
        <icon density="hdpi" src="res/icon/android/hdpi.png" />
        <icon density="xhdpi" src="res/icon/android/xhdpi.png" />
        <icon density="xxhdpi" src="res/icon/android/xxhdpi.png" />
        <icon density="xxxhdpi" src="res/icon/android/xxxhdpi.png" />
    </platform>
</widget>
EOF

# بناء APK
cordova build android

echo "🎉 APK جاهز في: platforms/android/app/build/outputs/apk/debug/"
