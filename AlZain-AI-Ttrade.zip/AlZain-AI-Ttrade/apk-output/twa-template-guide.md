# Trusted Web Activity (TWA) Template

## المتطلبات:
- Android Studio
- Java Development Kit (JDK) 8+

## الخطوات:

1. **تحميل Template**:
   ```bash
   git clone https://github.com/GoogleChromeLabs/android-browser-helper.git
   cd android-browser-helper/demos/twa-basic
   ```

2. **تحديث build.gradle**:
   ```gradle
   android {
       compileSdkVersion 33
       defaultConfig {
           applicationId "com.alzaintrade.app"
           minSdkVersion 21
           targetSdkVersion 33
           versionCode 1
           versionName "1.0"
       }
   }
   ```

3. **تحديث strings.xml**:
   ```xml
   <string name="app_name">AlZainTrade</string>
   <string name="twa_url">https://workspace.myscreen229.repl.co</string>
   <string name="twa_host">workspace.myscreen229.repl.co</string>
   ```

4. **Build APK**:
   ```bash
   ./gradlew assembleDebug
   ```
