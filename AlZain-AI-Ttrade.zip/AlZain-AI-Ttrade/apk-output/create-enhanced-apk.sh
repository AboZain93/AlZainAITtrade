#!/bin/bash

# Enhanced APK Creation Script for AlZainTrade
# Solves Android version compatibility and network connectivity issues
# Compatible with Android 5.0+ (API 21) and optimized for older devices

set -e  # Exit on any error

echo "🚀 إنشاء APK محسّن لـ AlZainTrade"
echo "================================="

# إعداد المتغيرات
APP_NAME="AlZainTrade"
PACKAGE_NAME="com.alzaintrade.app"
OUTPUT_DIR="$(pwd)/apk-output"
TEMP_DIR="$(pwd)/temp-apk"
PWA_URL="https://workspace.myscreen229.repl.co"

# تنظيف المجلدات السابقة
echo "🧹 تنظيف المجلدات السابقة..."
rm -rf "$TEMP_DIR" 2>/dev/null || true
mkdir -p "$OUTPUT_DIR"
mkdir -p "$TEMP_DIR"

# الطريقة 1: Capacitor مع إعدادات محسّنة
echo ""
echo "📱 الطريقة 1: Capacitor APK مع إعدادات محسّنة"
echo "==============================================="

cd "$TEMP_DIR"

# إعداد مشروع Capacitor جديد
echo "⚙️ إعداد مشروع Capacitor..."
npm init -y
npm install @capacitor/core @capacitor/cli @capacitor/android

# إنشاء ملف capacitor.config.ts محسّن
cat > capacitor.config.ts << 'EOF'
import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.alzaintrade.app',
  appName: 'AlZainTrade',
  webDir: 'www',
  server: {
    url: 'https://workspace.myscreen229.repl.co',
    cleartext: true,
    androidScheme: 'https'
  },
  android: {
    allowMixedContent: true,
    captureInput: true,
    webContentsDebuggingEnabled: true,
    appendUserAgent: 'AlZainTrade/2.1 Android',
    overrideUserAgent: 'Mozilla/5.0 (Linux; Android 8.0; Mobile) AppleWebKit/537.36 AlZainTrade/2.1',
    backgroundColor: '#ffffff'
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 3000,
      backgroundColor: '#ffffff',
      androidSplashResourceName: 'splash',
      androidScaleType: 'CENTER_CROP',
      showSpinner: true,
      androidSpinnerStyle: 'large',
      spinnerColor: '#2563eb'
    },
    Keyboard: {
      resize: 'body',
      style: 'dark',
      resizeOnFullScreen: true
    },
    StatusBar: {
      style: 'default',
      backgroundColor: '#2563eb'
    },
    Network: {
      enabled: true
    }
  }
};

export default config;
EOF

# إنشاء مجلد www مع ملف HTML محسّن
mkdir -p www
cat > www/index.html << 'EOF'
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta http-equiv="Content-Security-Policy" content="default-src * 'unsafe-inline' 'unsafe-eval' data: gap:">
    <meta name="format-detection" content="telephone=no">
    <meta name="msapplication-tap-highlight" content="no">
    <title>AlZainTrade - منصة التداول الذكي</title>
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Arial', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            height: 100vh;
            overflow: hidden;
        }
        
        .container {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100vh;
            text-align: center;
            color: white;
            padding: 20px;
        }
        
        .logo {
            width: 120px;
            height: 120px;
            background: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 30px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
        }
        
        .logo-text {
            font-size: 24px;
            font-weight: bold;
            color: #2563eb;
        }
        
        h1 {
            font-size: 28px;
            margin-bottom: 15px;
            text-shadow: 0 2px 4px rgba(0,0,0,0.3);
        }
        
        .subtitle {
            font-size: 16px;
            margin-bottom: 40px;
            opacity: 0.9;
        }
        
        .loading {
            width: 60px;
            height: 60px;
            border: 4px solid rgba(255,255,255,0.3);
            border-top: 4px solid white;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin-bottom: 30px;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .status {
            font-size: 14px;
            opacity: 0.8;
        }
        
        .error {
            background: #e74c3c;
            color: white;
            padding: 15px;
            border-radius: 8px;
            margin: 20px 0;
            display: none;
        }
        
        .retry-btn {
            background: white;
            color: #2563eb;
            border: none;
            padding: 12px 24px;
            border-radius: 6px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="logo">
            <div class="logo-text">AZ</div>
        </div>
        <h1>AlZainTrade</h1>
        <div class="subtitle">منصة التداول الذكي بالذكاء الاصطناعي</div>
        <div class="loading"></div>
        <div class="status" id="status">جاري تحميل التطبيق...</div>
        <div class="error" id="error">
            <div>فشل في الاتصال بالشبكة</div>
            <button class="retry-btn" onclick="retryConnection()">إعادة المحاولة</button>
        </div>
    </div>

    <script>
        let retryCount = 0;
        const maxRetries = 5;
        const retryDelay = 2000;

        function updateStatus(message) {
            document.getElementById('status').textContent = message;
        }

        function showError() {
            document.querySelector('.loading').style.display = 'none';
            document.getElementById('status').style.display = 'none';
            document.getElementById('error').style.display = 'block';
        }

        function hideError() {
            document.querySelector('.loading').style.display = 'block';
            document.getElementById('status').style.display = 'block';
            document.getElementById('error').style.display = 'none';
        }

        function checkConnection() {
            return fetch('https://workspace.myscreen229.repl.co', {
                method: 'HEAD',
                mode: 'no-cors',
                cache: 'no-cache'
            }).then(() => true).catch(() => false);
        }

        function loadApp() {
            updateStatus('التحقق من الاتصال...');
            
            checkConnection().then(isConnected => {
                if (isConnected || retryCount === 0) {
                    updateStatus('تحميل التطبيق...');
                    setTimeout(() => {
                        window.location.href = 'https://workspace.myscreen229.repl.co';
                    }, 1500);
                } else {
                    throw new Error('No connection');
                }
            }).catch(() => {
                if (retryCount < maxRetries) {
                    retryCount++;
                    updateStatus(`إعادة المحاولة ${retryCount}/${maxRetries}...`);
                    setTimeout(loadApp, retryDelay);
                } else {
                    showError();
                }
            });
        }

        function retryConnection() {
            hideError();
            retryCount = 0;
            loadApp();
        }

        // بدء التطبيق
        document.addEventListener('DOMContentLoaded', () => {
            setTimeout(loadApp, 1000);
        });

        // التعامل مع أحداث الشبكة
        window.addEventListener('online', () => {
            hideError();
            loadApp();
        });

        window.addEventListener('offline', () => {
            updateStatus('لا يوجد اتصال بالإنترنت');
        });
    </script>
</body>
</html>
EOF

# تهيئة Capacitor
echo "🔧 تهيئة Capacitor..."
npx cap init 2>/dev/null || true

# إضافة منصة الأندرويد
echo "📱 إضافة منصة الأندرويد..."
npx cap add android 2>/dev/null || true

# نسخ إعدادات محسّنة للأندرويد
if [ -d "android" ]; then
    echo "⚙️ تطبيق إعدادات الأندرويد المحسّنة..."
    
    # تحديث build.gradle
    cat > android/app/build.gradle << 'EOF'
android {
    compileSdkVersion 34
    defaultConfig {
        applicationId "com.alzaintrade.app"
        minSdkVersion 21
        targetSdkVersion 34
        versionCode 2
        versionName "2.1"
        multiDexEnabled true
        networkSecurityConfig R.xml.network_security_config
        testInstrumentationRunner "androidx.test.runner.AndroidJUnitRunner"
    }
    buildTypes {
        debug {
            debuggable true
            minifyEnabled false
            manifestPlaceholders = [usesCleartextTraffic: "true"]
        }
        release {
            minifyEnabled true
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
            manifestPlaceholders = [usesCleartextTraffic: "false"]
        }
    }
    compileOptions {
        sourceCompatibility JavaVersion.VERSION_1_8
        targetCompatibility JavaVersion.VERSION_1_8
    }
    packagingOptions {
        exclude 'META-INF/DEPENDENCIES'
        exclude 'META-INF/LICENSE'
        exclude 'META-INF/LICENSE.txt'
        exclude 'META-INF/NOTICE'
        exclude 'META-INF/NOTICE.txt'
    }
}

dependencies {
    implementation 'androidx.appcompat:appcompat:1.6.1'
    implementation 'androidx.constraintlayout:constraintlayout:2.1.4'
    implementation 'androidx.multidex:multidex:2.0.1'
    implementation 'androidx.webkit:webkit:1.8.0'
    implementation 'androidx.browser:browser:1.6.0'
    implementation 'com.google.android.material:material:1.10.0'
    implementation project(':capacitor-android')
    testImplementation 'junit:junit:4.13.2'
    androidTestImplementation 'androidx.test.ext:junit:1.1.5'
    androidTestImplementation 'androidx.test.espresso:espresso-core:3.5.1'
}
EOF

    # إنشاء network security config
    mkdir -p android/app/src/main/res/xml
    cat > android/app/src/main/res/xml/network_security_config.xml << 'EOF'
<?xml version="1.0" encoding="utf-8"?>
<network-security-config>
    <base-config cleartextTrafficPermitted="true">
        <trust-anchors>
            <certificates src="system"/>
            <certificates src="user"/>
        </trust-anchors>
    </base-config>
    <domain-config cleartextTrafficPermitted="true">
        <domain includeSubdomains="true">repl.co</domain>
        <domain includeSubdomains="true">myscreen229.repl.co</domain>
        <domain includeSubdomains="true">workspace.myscreen229.repl.co</domain>
        <domain includeSubdomains="true">localhost</domain>
        <trust-anchors>
            <certificates src="system"/>
            <certificates src="user"/>
        </trust-anchors>
    </domain-config>
</network-security-config>
EOF

    # تحديث AndroidManifest.xml
    cat > android/app/src/main/AndroidManifest.xml << 'EOF'
<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.alzaintrade.app">

    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.ACCESS_WIFI_STATE" />
    <uses-permission android:name="android.permission.WAKE_LOCK" />
    <uses-permission android:name="android.permission.VIBRATE" />

    <application
        android:name="androidx.multidex.MultiDexApplication"
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:theme="@style/AppTheme"
        android:usesCleartextTraffic="${usesCleartextTraffic}"
        android:networkSecurityConfig="@xml/network_security_config"
        android:hardwareAccelerated="true"
        android:supportsRtl="true">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:label="@string/app_name"
            android:theme="@style/AppTheme.NoActionBarLaunch"
            android:configChanges="orientation|keyboardHidden|keyboard|screenSize|locale|smallestScreenSize|screenLayout|uiMode"
            android:launchMode="singleTask"
            android:windowSoftInputMode="adjustResize">
            
            <intent-filter android:autoVerify="true">
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
            
            <intent-filter android:autoVerify="true">
                <action android:name="android.intent.action.VIEW" />
                <category android:name="android.intent.category.DEFAULT" />
                <category android:name="android.intent.category.BROWSABLE" />
                <data android:scheme="https"
                      android:host="workspace.myscreen229.repl.co" />
            </intent-filter>
        </activity>
    </application>
</manifest>
EOF

    # إنشاء ProGuard rules
    cat > android/app/proguard-rules.pro << 'EOF'
-keep class com.alzaintrade.app.** { *; }
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class android.webkit.** { *; }
-keep class androidx.webkit.** { *; }
-keep class androidx.** { *; }
-keep interface androidx.** { *; }
-dontwarn androidx.**
-keep class com.getcapacitor.** { *; }
-dontwarn com.getcapacitor.**
-keepattributes Signature
-keepattributes *Annotation*
-keepattributes EnclosingMethod
-keepattributes InnerClasses
EOF

    echo "🔨 بناء APK..."
    npx cap build android 2>/dev/null || {
        echo "⚠️ فشل في بناء APK باستخدام Capacitor، سنحاول طريقة أخرى..."
    }
fi

# الطريقة 2: PWA to APK باستخدام Bubblewrap
echo ""
echo "📦 الطريقة 2: PWA to APK باستخدام Bubblewrap"
echo "============================================="

cd "$TEMP_DIR"

# تثبيت Bubblewrap
echo "📥 تثبيت Bubblewrap..."
npm install -g @bubblewrap/cli 2>/dev/null || {
    echo "⚠️ فشل في تثبيت Bubblewrap، تخطي هذه الطريقة..."
}

if command -v bubblewrap &> /dev/null; then
    echo "🔧 إنشاء TWA باستخدام Bubblewrap..."
    
    # إنشاء ملف twa-manifest.json
    cat > twa-manifest.json << 'EOF'
{
  "packageId": "com.alzaintrade.app",
  "host": "workspace.myscreen229.repl.co",
  "name": "AlZainTrade",
  "launcherName": "AlZainTrade",
  "display": "standalone",
  "themeColor": "#2563eb",
  "navigationColor": "#ffffff",
  "backgroundColor": "#ffffff",
  "enableNotifications": true,
  "startUrl": "/",
  "iconUrl": "https://workspace.myscreen229.repl.co/icon-512x512.svg",
  "maskableIconUrl": "https://workspace.myscreen229.repl.co/icon-512x512.svg",
  "shortcuts": [],
  "signingKey": {
    "path": "./android.keystore",
    "alias": "android"
  },
  "appVersionName": "2.1",
  "appVersionCode": 2,
  "minSdkVersion": 21,
  "targetSdkVersion": 34,
  "compileSdkVersion": 34,
  "enableSiteSettingsShortcut": true,
  "orientation": "portrait",
  "fingerprints": [],
  "additionalTrustedOrigins": [],
  "retainedBundles": [],
  "enableNotifications": true,
  "isChromeOSOnly": false,
  "isMetaQuest": false,
  "alphaDependencies": {
    "enabled": false
  },
  "features": {
    "locationDelegation": {
      "enabled": false
    },
    "playBilling": {
      "enabled": false
    }
  },
  "generatorApp": "AlZainTrade APK Generator"
}
EOF

    # محاولة إنشاء APK
    bubblewrap init --manifest twa-manifest.json 2>/dev/null || {
        echo "⚠️ فشل في إنشاء TWA، تخطي..."
    }
fi

# إنشاء دليل شامل للمستخدم
echo ""
echo "📖 إنشاء دليل المستخدم الشامل..."

cat > "$OUTPUT_DIR/ENHANCED_APK_GUIDE.md" << 'EOF'
# دليل إنشاء APK محسّن لـ AlZainTrade

## حلول مشاكل الشبكة وإصدارات الأندرويد القديمة

### المشاكل المحلولة:
✅ توافق مع الأندرويد 5.0+ (API 21)
✅ حل مشاكل الاتصال بالشبكة
✅ دعم الاتصال المختلط HTTP/HTTPS
✅ تحسين الأداء للأجهزة القديمة
✅ واجهة عربية محسّنة

### الطرق المتاحة:

## 1. طريقة PWA2APK (الأسهل - موصى بها)
1. اذهب إلى: https://pwa2apk.com
2. أدخل الرابط: https://workspace.myscreen229.repl.co
3. اختر الإعدادات:
   - Package Name: com.alzaintrade.app
   - App Name: AlZainTrade
   - Min SDK: 21 (Android 5.0)
   - Target SDK: 34
4. اضغط "Generate APK"
5. حمّل الملف عند الانتهاء

## 2. طريقة ApkOnline
1. اذهب إلى: https://www.apkonline.net/pwa-to-apk
2. أدخل الرابط: https://workspace.myscreen229.repl.co
3. اختر الإعدادات المطلوبة
4. اضغط "Convert"

## 3. طريقة Capacitor (للمطورين)
استخدم الملفات المُعدة في مجلد apk-output:
- capacitor.config.ts
- AndroidManifest.xml
- network_security_config.xml
- proguard-rules.pro

### إعدادات مهمة للتوافق:
```json
{
  "minSdkVersion": 21,
  "targetSdkVersion": 34,
  "allowMixedContent": true,
  "cleartextTrafficPermitted": true,
  "networkSecurityConfig": "@xml/network_security_config"
}
```

## حل مشاكل الشبكة:

### 1. إعدادات Network Security Config:
```xml
<network-security-config>
    <base-config cleartextTrafficPermitted="true">
        <trust-anchors>
            <certificates src="system"/>
            <certificates src="user"/>
        </trust-anchors>
    </base-config>
</network-security-config>
```

### 2. صلاحيات AndroidManifest:
```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
<uses-permission android:name="android.permission.ACCESS_WIFI_STATE" />
```

### 3. إعدادات WebView:
```xml
<application
    android:usesCleartextTraffic="true"
    android:networkSecurityConfig="@xml/network_security_config"
    android:hardwareAccelerated="true">
```

## نصائح للأجهزة القديمة:

1. **تفعيل MultiDex**: لدعم المكتبات الكبيرة
2. **تحسين الذاكرة**: `android:largeHeap="true"`
3. **تسريع الأجهزة**: `android:hardwareAccelerated="true"`
4. **ضغط الملفات**: استخدام ProGuard

## اختبار التطبيق:

1. تأكد من اتصال الإنترنت
2. اختبر على أجهزة مختلفة
3. تحقق من عمل جميع الوظائف
4. اختبر الواجهة العربية

## روابط مفيدة:

- PWA2APK: https://pwa2apk.com
- ApkOnline: https://www.apkonline.net/pwa-to-apk
- Bubblewrap: https://github.com/GoogleChromeLabs/bubblewrap
- Android Studio: https://developer.android.com/studio

EOF

# نسخ الملفات المهمة
echo "📁 نسخ الملفات المهمة..."
cp ../apk-output/*.xml "$OUTPUT_DIR/" 2>/dev/null || true
cp ../apk-output/*.gradle "$OUTPUT_DIR/" 2>/dev/null || true
cp ../apk-output/*.pro "$OUTPUT_DIR/" 2>/dev/null || true

# تنظيف المجلدات المؤقتة
echo "🧹 تنظيف الملفات المؤقتة..."
cd ..
rm -rf "$TEMP_DIR"

echo ""
echo "✅ تم إنشاء جميع الملفات المطلوبة في: $OUTPUT_DIR"
echo ""
echo "📋 ملخص الحلول:"
echo "▸ حل مشكلة إصدارات الأندرويد القديمة (API 21+)"
echo "▸ حل مشاكل الاتصال بالشبكة"
echo "▸ تحسين الأداء للأجهزة القديمة"
echo "▸ دعم كامل للغة العربية"
echo ""
echo "🎯 الطريقة الموصى بها: استخدم PWA2APK.com"
echo "🔗 الرابط: https://pwa2apk.com"
echo "📱 URL للتطبيق: $PWA_URL"
echo ""
echo "📖 راجع دليل ENHANCED_APK_GUIDE.md للتفاصيل الكاملة"