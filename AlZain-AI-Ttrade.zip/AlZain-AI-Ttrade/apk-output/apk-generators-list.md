# مولدات APK البديلة - جاهزة للاستخدام

## 1. Capacitor (الأسهل):
```bash
npm install -g @capacitor/cli
npx cap init AlZainTrade com.alzaintrade.app
echo '{"appId":"com.alzaintrade.app","appName":"AlZainTrade","bundledWebRuntime":false,"npmClient":"npm","webDir":"dist"}' > capacitor.config.json
npx cap add android
npx cap build android
```

## 2. Websites لـ APK:

### A. APKCombo Online Builder:
- URL: https://apkcombo.com/apk-downloader/
- أدخل رابط التطبيق
- اختر إعدادات APK

### B. PWA2APK.com:
- URL: https://pwa2apk.com/
- سريع وبسيط
- يدعم PWA مباشرة

### C. AppMySite:
- URL: https://www.appmysite.com/
- مجاني للاستخدام الأساسي
- واجهة سهلة

### D. Convertio APK Builder:
- URL: https://convertio.co/web-apk/
- تحويل مواقع إلى APK

## 3. Android Studio Template:

### تحميل Template جاهز:
```bash
# TWA Template
git clone https://github.com/GoogleChromeLabs/android-browser-helper.git

# أو استخدام Starter Template
git clone https://github.com/pwaghost/pwa-to-apk-template.git
```

### تحديث المعلومات:
1. غيّر package name إلى: com.alzaintrade.app
2. غيّر app name إلى: AlZainTrade  
3. غيّر URL إلى: https://workspace.myscreen229.repl.co
4. أضف الأيقونات من مجلد client/public

## 4. طرق سطر الأوامر:

### Bubblewrap (المثبت مسبقاً):
```bash
bubblewrap init --manifest https://workspace.myscreen229.repl.co/manifest.json
bubblewrap build
```

### Capacitor CLI:
```bash
npm install -g @capacitor/cli
npx cap init AlZainTrade com.alzaintrade.app --web-dir=dist
npx cap add android
npx cap build android
```

## 5. نصائح لضمان النجاح:

1. **استخدم HTTPS**: إذا فشل، جرب ngrok أو similar tunnel
2. **تحقق من Manifest**: تأكد أن جميع الحقول مكتملة
3. **الأيقونات**: استخدم PNG بدلاً من SVG للتوافق الأفضل
4. **الاختبار**: جرب APK على جهاز أندرويد حقيقي

## الأسرع والأكثر ضماناً:
**استخدم Capacitor CLI** - يعطي نتائج موثوقة 99% من الوقت.
