// Script to generate SVG icons for different sizes
const fs = require('fs');

const createIcon = (size) => {
  const svg = `<svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}" fill="none" xmlns="http://www.w3.org/2000/svg">
    <circle cx="${size/2}" cy="${size/2}" r="${size/2}" fill="#2563eb"/>
    <g transform="translate(${size*0.15}, ${size*0.15})">
      <path d="M${size*0.1} ${size*0.5}V${size*0.25}h${size*0.15}v${size*0.2}h${size*0.1}V${size*0.25}h${size*0.15}v${size*0.4}h-${size*0.05}V${size*0.45}H${size*0.2}v${size*0.05}H${size*0.1}z" fill="#ffffff"/>
      <path d="M${size*0.4} ${size*0.25}h${size*0.1}V${size*0.35}h-${size*0.1}V${size*0.35}z" fill="#ffffff"/>
      <path d="M${size*0.25} ${size*0.55}L${size*0.45} ${size*0.35}L${size*0.5} ${size*0.4}L${size*0.3} ${size*0.6}z" fill="#ffffff"/>
    </g>
  </svg>`;
  return svg;
};

const sizes = [72, 96, 128, 144, 152, 192, 384, 512];

sizes.forEach(size => {
  const svg = createIcon(size);
  fs.writeFileSync(`./icon-${size}x${size}.svg`, svg);
  console.log(`Created icon-${size}x${size}.svg`);
});

console.log('All icons generated successfully!');