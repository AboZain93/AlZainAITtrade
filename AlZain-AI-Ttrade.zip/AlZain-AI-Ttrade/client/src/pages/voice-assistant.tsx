import { useState, useRef, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useLanguageContext } from '@/components/language-provider';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { FloatingRefreshButton } from '@/components/floating-refresh-button';
import { 
  Mic, 
  MicOff, 
  Volume2, 
  VolumeX, 
  Send, 
  MessageCircle, 
  Languages, 
  BarChart3,
  History,
  Headphones,
  Zap,
  Play,
  Pause,
  RotateCcw,
  CheckCircle,
  XCircle,
  Clock,
  TrendingUp,
  Database,
  Users,
  Settings,
  Globe,
  Star
} from 'lucide-react';

interface VoiceCommand {
  command: string;
  language: string;
  confidence: number;
  intent: string;
  entities: Record<string, any>;
  timestamp: string;
  response: string;
  success: boolean;
}

interface VoiceResponse {
  text: string;
  language: string;
  audioUrl?: string;
  actions?: string[];
  data?: any;
}

interface VoiceStats {
  totalCommands: number;
  successRate: number;
  topIntents: { intent: string; count: number }[];
  languageBreakdown: { language: string; count: number }[];
}

export default function VoiceAssistant() {
  const { language } = useLanguageContext();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [textInput, setTextInput] = useState('');
  const [selectedLanguage, setSelectedLanguage] = useState(language);
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [currentResponse, setCurrentResponse] = useState<VoiceResponse | null>(null);
  const [conversationHistory, setConversationHistory] = useState<Array<{
    type: 'user' | 'assistant';
    text: string;
    timestamp: Date;
    data?: any;
  }>>([]);

  const audioRef = useRef<HTMLAudioElement>(null);
  const recognitionRef = useRef<any>(null);

  const { data: supportedLanguages } = useQuery<{ languages: string[] }>({
    queryKey: ['/api/voice/languages'],
  });

  const { data: commandHistory } = useQuery<VoiceCommand[]>({
    queryKey: ['/api/voice/history'],
    refetchInterval: 30000,
  });

  const { data: voiceStats } = useQuery<VoiceStats>({
    queryKey: ['/api/voice/stats'],
    refetchInterval: 60000,
  });

  const processCommandMutation = useMutation({
    mutationFn: ({ text, language }: { text: string; language: string }) =>
      apiRequest('POST', '/api/voice/command', { text, language }),
    onSuccess: (response: VoiceResponse) => {
      setCurrentResponse(response);
      setConversationHistory(prev => [
        ...prev,
        { type: 'user', text: textInput || 'أمر صوتي', timestamp: new Date() },
        { type: 'assistant', text: response.text, timestamp: new Date(), data: response.data }
      ]);
      setTextInput('');
      
      // تشغيل الاستجابة الصوتية إذا كانت متاحة
      if (response.audioUrl && audioRef.current) {
        audioRef.current.src = response.audioUrl;
        audioRef.current.play();
        setIsSpeaking(true);
      }
      
      queryClient.invalidateQueries({ queryKey: ['/api/voice/history'] });
      queryClient.invalidateQueries({ queryKey: ['/api/voice/stats'] });
    },
    onError: (error) => {
      toast({
        title: language === 'ar' ? 'خطأ' : 'Error',
        description: language === 'ar' ? 'فشل في معالجة الأمر الصوتي' : 'Failed to process voice command',
        variant: 'destructive',
      });
    },
  });

  const ttsRequestMutation = useMutation({
    mutationFn: ({ text, language }: { text: string; language: string }) =>
      apiRequest('POST', '/api/voice/tts', { text, language }),
    onSuccess: (response: { audioUrl: string }) => {
      if (audioRef.current) {
        audioRef.current.src = response.audioUrl;
        audioRef.current.play();
        setIsSpeaking(true);
      }
    },
  });

  // إعداد التعرف على الكلام
  useEffect(() => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = false;
      recognitionRef.current.lang = selectedLanguage === 'ar' ? 'ar-SA' : 
                                     selectedLanguage === 'fr' ? 'fr-FR' :
                                     selectedLanguage === 'es' ? 'es-ES' : 'en-US';

      recognitionRef.current.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setTextInput(transcript);
        setIsListening(false);
        
        // معالجة الأمر تلقائياً
        processCommandMutation.mutate({ text: transcript, language: selectedLanguage });
      };

      recognitionRef.current.onerror = () => {
        setIsListening(false);
        toast({
          title: language === 'ar' ? 'خطأ' : 'Error',
          description: language === 'ar' ? 'لم يتم التعرف على الصوت' : 'Speech recognition failed',
          variant: 'destructive',
        });
      };

      recognitionRef.current.onend = () => {
        setIsListening(false);
      };
    }
  }, [selectedLanguage, processCommandMutation, language, toast]);

  const startListening = () => {
    if (recognitionRef.current) {
      setIsListening(true);
      recognitionRef.current.start();
    }
  };

  const stopListening = () => {
    if (recognitionRef.current) {
      recognitionRef.current.stop();
      setIsListening(false);
    }
  };

  const handleTextSubmit = () => {
    if (textInput.trim()) {
      processCommandMutation.mutate({ text: textInput, language: selectedLanguage });
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleTextSubmit();
    }
  };

  const playText = (text: string) => {
    ttsRequestMutation.mutate({ text, language: selectedLanguage });
  };

  const getLanguageName = (code: string) => {
    const languages = {
      ar: language === 'ar' ? 'العربية' : 'Arabic',
      en: language === 'ar' ? 'الإنجليزية' : 'English',
      fr: language === 'ar' ? 'الفرنسية' : 'French',
      es: language === 'ar' ? 'الإسبانية' : 'Spanish'
    };
    return languages[code as keyof typeof languages] || code;
  };

  const getIntentName = (intent: string) => {
    const intents = {
      market_data: language === 'ar' ? 'بيانات السوق' : 'Market Data',
      trading_signals: language === 'ar' ? 'إشارات التداول' : 'Trading Signals',
      portfolio: language === 'ar' ? 'المحفظة' : 'Portfolio',
      analysis: language === 'ar' ? 'تحليل السوق' : 'Market Analysis',
      help: language === 'ar' ? 'مساعدة' : 'Help',
      unknown: language === 'ar' ? 'غير معروف' : 'Unknown'
    };
    return intents[intent as keyof typeof intents] || intent;
  };

  const handleRefreshData = () => {
    queryClient.invalidateQueries({ queryKey: ['/api/voice/history'] });
    queryClient.invalidateQueries({ queryKey: ['/api/voice/stats'] });
    queryClient.invalidateQueries({ queryKey: ['/api/voice/languages'] });
  };

  return (
    <div className="container mx-auto p-6 space-y-6" dir={language === 'ar' ? 'rtl' : 'ltr'}>
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="flex items-center justify-center gap-3">
          <Headphones className="h-8 w-8 text-primary" />
          <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
            {language === 'ar' ? 'المساعد الصوتي الذكي' : 'Smart Voice Assistant'}
          </h1>
        </div>
        <p className="text-lg text-muted-foreground max-w-3xl mx-auto leading-relaxed">
          {language === 'ar' 
            ? 'تحدث مع المساعد الذكي بأربع لغات واحصل على معلومات فورية عن الأسواق والتوصيات'
            : 'Speak with the smart assistant in four languages and get instant market information and recommendations'
          }
        </p>
        
        {/* Language Selector */}
        <div className="flex items-center justify-center gap-4">
          <Select value={selectedLanguage} onValueChange={setSelectedLanguage}>
            <SelectTrigger className="w-48">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {supportedLanguages?.languages.map((lang) => (
                <SelectItem key={lang} value={lang}>
                  <div className="flex items-center gap-2">
                    <Globe className="h-4 w-4" />
                    {getLanguageName(lang)}
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          
          <Badge variant="outline" className="flex items-center gap-1">
            <Languages className="h-3 w-3" />
            {supportedLanguages?.languages.length || 4} {language === 'ar' ? 'لغة' : 'Languages'}
          </Badge>
        </div>
      </div>

      <Tabs defaultValue="chat" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="chat" className="flex items-center gap-2">
            <MessageCircle className="h-4 w-4" />
            {language === 'ar' ? 'المحادثة' : 'Chat'}
          </TabsTrigger>
          <TabsTrigger value="history" className="flex items-center gap-2">
            <History className="h-4 w-4" />
            {language === 'ar' ? 'السجل' : 'History'}
          </TabsTrigger>
          <TabsTrigger value="stats" className="flex items-center gap-2">
            <BarChart3 className="h-4 w-4" />
            {language === 'ar' ? 'الإحصائيات' : 'Statistics'}
          </TabsTrigger>
        </TabsList>

        {/* Chat Tab */}
        <TabsContent value="chat" className="space-y-6">
          {/* Voice Input Interface */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Mic className="h-5 w-5" />
                {language === 'ar' ? 'واجهة الصوت' : 'Voice Interface'}
              </CardTitle>
              <CardDescription>
                {language === 'ar' 
                  ? 'اضغط على الميكروفون للتحدث أو اكتب نصاً مباشرة'
                  : 'Press microphone to speak or type text directly'
                }
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Voice Controls */}
              <div className="flex items-center justify-center gap-4">
                <Button
                  size="lg"
                  variant={isListening ? "destructive" : "default"}
                  className="w-20 h-20 rounded-full"
                  onClick={isListening ? stopListening : startListening}
                  disabled={processCommandMutation.isPending}
                >
                  {isListening ? (
                    <MicOff className="h-8 w-8" />
                  ) : (
                    <Mic className="h-8 w-8" />
                  )}
                </Button>
                
                <div className="text-center">
                  <div className="text-sm font-medium">
                    {isListening ? (
                      language === 'ar' ? 'جاري الاستماع...' : 'Listening...'
                    ) : (
                      language === 'ar' ? 'اضغط للتحدث' : 'Press to speak'
                    )}
                  </div>
                  {isListening && (
                    <div className="flex items-center justify-center gap-1 mt-2">
                      <div className="w-2 h-6 bg-red-500 rounded animate-pulse"></div>
                      <div className="w-2 h-4 bg-red-400 rounded animate-pulse delay-75"></div>
                      <div className="w-2 h-8 bg-red-500 rounded animate-pulse delay-150"></div>
                      <div className="w-2 h-3 bg-red-400 rounded animate-pulse delay-225"></div>
                    </div>
                  )}
                </div>
              </div>

              {/* Text Input */}
              <div className="flex gap-2">
                <Input
                  placeholder={language === 'ar' ? 'اكتب أمرك هنا...' : 'Type your command here...'}
                  value={textInput}
                  onChange={(e) => setTextInput(e.target.value)}
                  onKeyPress={handleKeyPress}
                  disabled={processCommandMutation.isPending}
                />
                <Button 
                  onClick={handleTextSubmit}
                  disabled={!textInput.trim() || processCommandMutation.isPending}
                >
                  <Send className="h-4 w-4" />
                </Button>
              </div>

              {/* Current Response */}
              {currentResponse && (
                <Card className="bg-gradient-to-br from-blue-50 to-purple-50 dark:from-blue-950/50 dark:to-purple-950/50">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <p className="text-sm font-medium mb-2">{currentResponse.text}</p>
                        {currentResponse.data && (
                          <div className="text-xs text-muted-foreground">
                            {JSON.stringify(currentResponse.data, null, 2)}
                          </div>
                        )}
                      </div>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => playText(currentResponse.text)}
                        disabled={ttsRequestMutation.isPending || isSpeaking}
                      >
                        {isSpeaking ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}
            </CardContent>
          </Card>

          {/* Conversation History */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageCircle className="h-5 w-5" />
                {language === 'ar' ? 'سجل المحادثة' : 'Conversation History'}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4 max-h-96 overflow-y-auto">
                {conversationHistory.length === 0 ? (
                  <div className="text-center text-muted-foreground py-8">
                    {language === 'ar' ? 'ابدأ محادثة بالتحدث أو الكتابة' : 'Start a conversation by speaking or typing'}
                  </div>
                ) : (
                  conversationHistory.map((item, index) => (
                    <div key={index} className={`flex ${item.type === 'user' ? 'justify-end' : 'justify-start'}`}>
                      <div className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                        item.type === 'user' 
                          ? 'bg-primary text-primary-foreground' 
                          : 'bg-muted'
                      }`}>
                        <p className="text-sm">{item.text}</p>
                        <p className="text-xs opacity-70 mt-1">
                          {item.timestamp.toLocaleTimeString(language === 'ar' ? 'ar-SA' : 'en-US')}
                        </p>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* History Tab */}
        <TabsContent value="history" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <History className="h-5 w-5" />
                {language === 'ar' ? 'سجل الأوامر' : 'Command History'}
              </CardTitle>
              <CardDescription>
                {language === 'ar' 
                  ? 'آخر 50 أمر تم معالجته مع تفاصيل الاستجابة'
                  : 'Last 50 processed commands with response details'
                }
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {commandHistory?.map((cmd, index) => (
                  <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-medium text-sm">{cmd.command}</span>
                        <Badge variant="outline" className="text-xs">
                          {getLanguageName(cmd.language)}
                        </Badge>
                        <Badge variant="outline" className="text-xs">
                          {getIntentName(cmd.intent)}
                        </Badge>
                      </div>
                      <p className="text-xs text-muted-foreground">{cmd.response}</p>
                      <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {new Date(cmd.timestamp).toLocaleString(language === 'ar' ? 'ar-SA' : 'en-US')}
                        </span>
                        <span>{cmd.confidence}% {language === 'ar' ? 'ثقة' : 'confidence'}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {cmd.success ? (
                        <CheckCircle className="h-4 w-4 text-green-500" />
                      ) : (
                        <XCircle className="h-4 w-4 text-red-500" />
                      )}
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => playText(cmd.response)}
                      >
                        <Volume2 className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Statistics Tab */}
        <TabsContent value="stats" className="space-y-6">
          {voiceStats && (
            <>
              {/* Overview Stats */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-muted-foreground">
                          {language === 'ar' ? 'إجمالي الأوامر' : 'Total Commands'}
                        </p>
                        <p className="text-2xl font-bold">{voiceStats.totalCommands}</p>
                      </div>
                      <MessageCircle className="h-8 w-8 text-blue-600" />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-muted-foreground">
                          {language === 'ar' ? 'معدل النجاح' : 'Success Rate'}
                        </p>
                        <p className="text-2xl font-bold">{voiceStats.successRate.toFixed(1)}%</p>
                      </div>
                      <TrendingUp className="h-8 w-8 text-green-600" />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-muted-foreground">
                          {language === 'ar' ? 'أكثر الأوامر' : 'Top Intent'}
                        </p>
                        <p className="text-2xl font-bold">
                          {voiceStats.topIntents[0] ? getIntentName(voiceStats.topIntents[0].intent) : '-'}
                        </p>
                      </div>
                      <Star className="h-8 w-8 text-yellow-600" />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-muted-foreground">
                          {language === 'ar' ? 'اللغات المستخدمة' : 'Languages Used'}
                        </p>
                        <p className="text-2xl font-bold">{voiceStats.languageBreakdown.length}</p>
                      </div>
                      <Languages className="h-8 w-8 text-purple-600" />
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Top Intents */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="h-5 w-5" />
                    {language === 'ar' ? 'أكثر الأوامر استخداماً' : 'Most Used Commands'}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {voiceStats.topIntents.map((intent, index) => (
                      <div key={intent.intent} className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-sm font-bold">
                            {index + 1}
                          </div>
                          <span className="font-medium">{getIntentName(intent.intent)}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="w-32 bg-muted rounded-full h-2">
                            <div 
                              className="bg-primary h-2 rounded-full transition-all"
                              style={{ 
                                width: `${(intent.count / voiceStats.topIntents[0].count) * 100}%` 
                              }}
                            />
                          </div>
                          <span className="text-sm text-muted-foreground w-8 text-right">
                            {intent.count}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Language Breakdown */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Globe className="h-5 w-5" />
                    {language === 'ar' ? 'توزيع اللغات' : 'Language Distribution'}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {voiceStats.languageBreakdown.map((lang) => (
                      <div key={lang.language} className="text-center p-4 bg-muted/50 rounded-lg">
                        <div className="text-2xl font-bold">{lang.count}</div>
                        <div className="text-sm text-muted-foreground">
                          {getLanguageName(lang.language)}
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {((lang.count / voiceStats.totalCommands) * 100).toFixed(1)}%
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </>
          )}
        </TabsContent>
      </Tabs>

      {/* Hidden Audio Element for TTS */}
      <audio 
        ref={audioRef} 
        onEnded={() => setIsSpeaking(false)}
        onPlay={() => setIsSpeaking(true)}
        hidden 
      />

      <FloatingRefreshButton onRefresh={handleRefreshData} />
    </div>
  );
}