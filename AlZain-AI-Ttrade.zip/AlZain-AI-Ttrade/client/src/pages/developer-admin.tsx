import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { 
  Shield, 
  Users, 
  Key, 
  Plus, 
  Edit, 
  Trash2, 
  Activity,
  CheckCircle,
  XCircle,
  Calendar,
  Settings,
  Package,
  DollarSign,
  Copy,
  Download,
  BarChart3,
  UserPlus,
  CreditCard,
  Globe,
  Zap,
  Clock,
  Eye,
  Database,
  Server,
  Monitor
} from "lucide-react";

interface Product {
  id: number;
  name: string;
  nameAr: string;
  description: string;
  descriptionAr: string;
  priceUsd: number;
  originalPriceUsd: number;
  productType: string;
  category: string;
  billingCycle: string;
  features: string[];
  limits: any;
  trialDays: number;
  trialTrades: number;
  maxDevicesAllowed: number;
  isPopular: boolean;
  isActive: boolean;
  sortOrder: number;
}

interface License {
  id: number;
  licenseKey: string;
  userId: string;
  productId: number;
  licenseType: string;
  isActivated: boolean;
  isValid: boolean;
  isRevoked: boolean;
  isTrial: boolean;
  maxTrades: number;
  tradesUsed: number;
  expiresAt: string;
  trialEndDate: string;
  createdAt: string;
  deviceFingerprint: string;
}

interface CommercialUser {
  id: string;
  username: string;
  email: string;
  firstName: string;
  lastName: string;
  subscriptionStatus: string;
  subscriptionTier: string;
  dailySignalsUsed: number;
  monthlySignalsUsed: number;
  totalSignalsUsed: number;
  trialEndDate: string;
  createdAt: string;
  lastLogin: string;
  isActive: boolean;
}

interface DashboardStats {
  totalUsers: number;
  totalProducts: number;
  totalLicenses: number;
  activeLicenses: number;
  trialLicenses: number;
  revenue: number;
  revenueThisMonth: number;
}

export default function DeveloperAdmin() {
  const { toast } = useToast();
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [selectedLicense, setSelectedLicense] = useState<License | null>(null);
  const [showCreateProduct, setShowCreateProduct] = useState(false);
  const [showCreateLicense, setShowCreateLicense] = useState(false);

  // Form states
  const [newProduct, setNewProduct] = useState({
    name: '',
    nameAr: '',
    description: '',
    descriptionAr: '',
    priceUsd: 0,
    originalPriceUsd: 0,
    productType: 'subscription',
    category: 'trading',
    billingCycle: 'monthly',
    features: [''],
    limits: {
      dailySignals: 50,
      monthlySignals: 1500,
      devices: 1
    },
    trialDays: 7,
    trialTrades: 10,
    maxDevicesAllowed: 1,
    isPopular: false,
    isActive: true,
    sortOrder: 0
  });

  const [newLicense, setNewLicense] = useState({
    productId: 0,
    licenseType: 'trial',
    maxTrades: 10,
    trialDurationDays: 7,
    quantity: 1
  });

  // Get dev key from URL or set default
  const urlParams = new URLSearchParams(window.location.search);
  const devKey = urlParams.get('devKey') || 'dev-2025-alzain-trade';

  // Fetch dashboard stats
  const { data: stats, isLoading: statsLoading, error: statsError } = useQuery<DashboardStats>({
    queryKey: ['/api/developer/stats', devKey],
    queryFn: async () => {
      const res = await fetch('/api/developer/stats', {
        headers: { 'x-dev-key': devKey }
      });
      if (!res.ok) throw new Error('Failed to fetch stats');
      return res.json();
    },
    refetchInterval: 30000,
    retry: 3,
  });

  // Fetch products
  const { data: products, isLoading: productsLoading, error: productsError } = useQuery<Product[]>({
    queryKey: ['/api/developer/products', devKey],
    queryFn: async () => {
      const res = await fetch('/api/developer/products', {
        headers: { 'x-dev-key': devKey }
      });
      if (!res.ok) throw new Error('Failed to fetch products');
      return res.json();
    },
    refetchInterval: 30000,
    retry: 3,
  });

  // Fetch licenses
  const { data: licenses, isLoading: licensesLoading, error: licensesError } = useQuery<License[]>({
    queryKey: ['/api/developer/licenses', devKey],
    queryFn: async () => {
      const res = await fetch('/api/developer/licenses', {
        headers: { 'x-dev-key': devKey }
      });
      if (!res.ok) throw new Error('Failed to fetch licenses');
      return res.json();
    },
    refetchInterval: 30000,
    retry: 3,
  });

  // Fetch users
  const { data: users, isLoading: usersLoading, error: usersError } = useQuery<CommercialUser[]>({
    queryKey: ['/api/developer/users', devKey],
    queryFn: async () => {
      const res = await fetch('/api/developer/users', {
        headers: { 'x-dev-key': devKey }
      });
      if (!res.ok) throw new Error('Failed to fetch users');
      return res.json();
    },
    refetchInterval: 30000,
    retry: 3,
  });

  // Create product mutation
  const createProductMutation = useMutation({
    mutationFn: (productData: any) => 
      fetch('/api/developer/products', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-dev-key': devKey
        },
        body: JSON.stringify(productData)
      }).then(res => res.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/developer/products'] });
      queryClient.invalidateQueries({ queryKey: ['/api/developer/stats'] });
      setShowCreateProduct(false);
      setNewProduct({
        name: '',
        nameAr: '',
        description: '',
        descriptionAr: '',
        priceUsd: 0,
        originalPriceUsd: 0,
        productType: 'subscription',
        category: 'trading',
        billingCycle: 'monthly',
        features: [''],
        limits: {
          dailySignals: 50,
          monthlySignals: 1500,
          devices: 1
        },
        trialDays: 7,
        trialTrades: 10,
        maxDevicesAllowed: 1,
        isPopular: false,
        isActive: true,
        sortOrder: 0
      });
      toast({
        title: "تم إنشاء المنتج",
        description: "تم إنشاء المنتج بنجاح",
      });
    },
    onError: (error: any) => {
      toast({
        title: "خطأ",
        description: `فشل في إنشاء المنتج: ${error.message}`,
        variant: 'destructive',
      });
    },
  });

  // Create license mutation
  const createLicenseMutation = useMutation({
    mutationFn: (licenseData: any) => 
      fetch('/api/developer/licenses', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-dev-key': devKey
        },
        body: JSON.stringify(licenseData)
      }).then(res => res.json()),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/developer/licenses'] });
      queryClient.invalidateQueries({ queryKey: ['/api/developer/stats'] });
      setShowCreateLicense(false);
      setNewLicense({
        productId: 0,
        licenseType: 'trial',
        maxTrades: 10,
        trialDurationDays: 7,
        quantity: 1
      });
      toast({
        title: "تم إنشاء التراخيص",
        description: `تم إنشاء ${data.licenses?.length || 1} ترخيص بنجاح`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "خطأ",
        description: `فشل في إنشاء التراخيص: ${error.message}`,
        variant: 'destructive',
      });
    },
  });

  // Update product mutation
  const updateProductMutation = useMutation({
    mutationFn: (data: { id: number; updates: Partial<Product> }) => 
      fetch(`/api/developer/products/${data.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'x-dev-key': devKey
        },
        body: JSON.stringify(data.updates)
      }).then(res => res.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/developer/products'] });
      setSelectedProduct(null);
      toast({
        title: "تم تحديث المنتج",
        description: "تم تحديث المنتج بنجاح",
      });
    },
  });

  // Revoke license mutation
  const revokeLicenseMutation = useMutation({
    mutationFn: (data: { licenseKey: string; reason: string }) => 
      fetch('/api/developer/licenses/revoke', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-dev-key': devKey
        },
        body: JSON.stringify(data)
      }).then(res => res.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/developer/licenses'] });
      toast({
        title: "تم إلغاء الترخيص",
        description: "تم إلغاء الترخيص بنجاح",
      });
    },
  });

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "تم النسخ",
      description: "تم نسخ النص إلى الحافظة",
    });
  };

  const addFeature = () => {
    setNewProduct({
      ...newProduct,
      features: [...newProduct.features, '']
    });
  };

  const updateFeature = (index: number, value: string) => {
    const updatedFeatures = [...newProduct.features];
    updatedFeatures[index] = value;
    setNewProduct({
      ...newProduct,
      features: updatedFeatures
    });
  };

  const removeFeature = (index: number) => {
    const updatedFeatures = newProduct.features.filter((_, i) => i !== index);
    setNewProduct({
      ...newProduct,
      features: updatedFeatures
    });
  };

  // Show errors if any
  const hasErrors = statsError || productsError || licensesError || usersError;

  return (
    <div className="container mx-auto p-6 max-w-7xl">
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-4">
          <div className="p-2 bg-blue-500 text-white rounded-lg">
            <Shield className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-3xl font-bold">لوحة تحكم المطور</h1>
            <p className="text-gray-600">إدارة المنتجات، التراخيص، والمستخدمين</p>
            <div className="mt-2 text-sm text-gray-500">
              DevKey: <code className="bg-gray-100 px-2 py-1 rounded">{devKey}</code>
            </div>
          </div>
        </div>

        {/* Error Display */}
        {hasErrors && (
          <Card className="border-red-200 bg-red-50 mb-6">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 text-red-800">
                <XCircle className="w-5 h-5" />
                <h3 className="font-semibold">أخطاء في تحميل البيانات</h3>
              </div>
              <div className="mt-2 text-sm text-red-700 space-y-1">
                {statsError && <div>• خطأ في الإحصائيات: {statsError.message}</div>}
                {productsError && <div>• خطأ في المنتجات: {productsError.message}</div>}
                {licensesError && <div>• خطأ في التراخيص: {licensesError.message}</div>}
                {usersError && <div>• خطأ في المستخدمين: {usersError.message}</div>}
              </div>
              <div className="mt-3 text-xs text-red-600">
                تأكد من صحة DevKey أو تحقق من حالة الخادم
              </div>
            </CardContent>
          </Card>
        )}

        {/* Success Display */}
        {!hasErrors && stats && (
          <Card className="border-green-200 bg-green-50 mb-6">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 text-green-800">
                <CheckCircle className="w-5 h-5" />
                <h3 className="font-semibold">متصل بنجاح</h3>
              </div>
              <div className="mt-1 text-sm text-green-700">
                تم تحميل جميع البيانات بنجاح
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Dashboard Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card className="border-l-4 border-l-blue-500">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">إجمالي المستخدمين</p>
                <p className="text-2xl font-bold text-blue-600">
                  {statsLoading ? "..." : stats?.totalUsers || 0}
                </p>
              </div>
              <Users className="w-8 h-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-green-500">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">إجمالي المنتجات</p>
                <p className="text-2xl font-bold text-green-600">
                  {statsLoading ? "..." : stats?.totalProducts || 0}
                </p>
              </div>
              <Package className="w-8 h-8 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-purple-500">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">التراخيص النشطة</p>
                <p className="text-2xl font-bold text-purple-600">
                  {statsLoading ? "..." : stats?.activeLicenses || 0}
                </p>
              </div>
              <Key className="w-8 h-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-orange-500">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">الإيرادات الشهرية</p>
                <p className="text-2xl font-bold text-orange-600">
                  ${statsLoading ? "..." : (stats?.revenueThisMonth || 0).toFixed(2)}
                </p>
              </div>
              <DollarSign className="w-8 h-8 text-orange-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs defaultValue="products" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="products">المنتجات</TabsTrigger>
          <TabsTrigger value="licenses">التراخيص</TabsTrigger>
          <TabsTrigger value="users">المستخدمين</TabsTrigger>
          <TabsTrigger value="analytics">التحليلات</TabsTrigger>
        </TabsList>

        {/* Products Tab */}
        <TabsContent value="products" className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-bold">إدارة المنتجات</h2>
            <Dialog open={showCreateProduct} onOpenChange={setShowCreateProduct}>
              <DialogTrigger asChild>
                <Button className="bg-blue-500 hover:bg-blue-600">
                  <Plus className="w-4 h-4 mr-2" />
                  إنشاء منتج جديد
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>إنشاء منتج جديد</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="name">اسم المنتج (الإنجليزية)</Label>
                      <Input
                        id="name"
                        value={newProduct.name}
                        onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })}
                        placeholder="Premium Trading Signals"
                      />
                    </div>
                    <div>
                      <Label htmlFor="nameAr">اسم المنتج (العربية)</Label>
                      <Input
                        id="nameAr"
                        value={newProduct.nameAr}
                        onChange={(e) => setNewProduct({ ...newProduct, nameAr: e.target.value })}
                        placeholder="إشارات التداول المتقدمة"
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="description">الوصف (الإنجليزية)</Label>
                    <Textarea
                      id="description"
                      value={newProduct.description}
                      onChange={(e) => setNewProduct({ ...newProduct, description: e.target.value })}
                      placeholder="Advanced trading signals with AI analysis"
                      rows={3}
                    />
                  </div>

                  <div>
                    <Label htmlFor="descriptionAr">الوصف (العربية)</Label>
                    <Textarea
                      id="descriptionAr"
                      value={newProduct.descriptionAr}
                      onChange={(e) => setNewProduct({ ...newProduct, descriptionAr: e.target.value })}
                      placeholder="إشارات تداول متقدمة مع تحليل الذكاء الاصطناعي"
                      rows={3}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="priceUsd">السعر (بالدولار)</Label>
                      <Input
                        id="priceUsd"
                        type="number"
                        value={newProduct.priceUsd}
                        onChange={(e) => setNewProduct({ ...newProduct, priceUsd: parseInt(e.target.value) })}
                        placeholder="2999"
                      />
                    </div>
                    <div>
                      <Label htmlFor="originalPriceUsd">السعر الأصلي</Label>
                      <Input
                        id="originalPriceUsd"
                        type="number"
                        value={newProduct.originalPriceUsd}
                        onChange={(e) => setNewProduct({ ...newProduct, originalPriceUsd: parseInt(e.target.value) })}
                        placeholder="4999"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>نوع المنتج</Label>
                      <Select value={newProduct.productType} onValueChange={(value) => setNewProduct({ ...newProduct, productType: value })}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="subscription">اشتراك</SelectItem>
                          <SelectItem value="license">ترخيص</SelectItem>
                          <SelectItem value="one-time">دفعة واحدة</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>دورة الفوترة</Label>
                      <Select value={newProduct.billingCycle} onValueChange={(value) => setNewProduct({ ...newProduct, billingCycle: value })}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="monthly">شهري</SelectItem>
                          <SelectItem value="yearly">سنوي</SelectItem>
                          <SelectItem value="lifetime">مدى الحياة</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div>
                    <Label>الميزات</Label>
                    {newProduct.features.map((feature, index) => (
                      <div key={index} className="flex gap-2 mb-2">
                        <Input
                          value={feature}
                          onChange={(e) => updateFeature(index, e.target.value)}
                          placeholder="ميزة المنتج"
                        />
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => removeFeature(index)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    ))}
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={addFeature}
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      إضافة ميزة
                    </Button>
                  </div>

                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <Label>أيام التجربة</Label>
                      <Input
                        type="number"
                        value={newProduct.trialDays}
                        onChange={(e) => setNewProduct({ ...newProduct, trialDays: parseInt(e.target.value) })}
                      />
                    </div>
                    <div>
                      <Label>صفقات التجربة</Label>
                      <Input
                        type="number"
                        value={newProduct.trialTrades}
                        onChange={(e) => setNewProduct({ ...newProduct, trialTrades: parseInt(e.target.value) })}
                      />
                    </div>
                    <div>
                      <Label>الأجهزة المسموحة</Label>
                      <Input
                        type="number"
                        value={newProduct.maxDevicesAllowed}
                        onChange={(e) => setNewProduct({ ...newProduct, maxDevicesAllowed: parseInt(e.target.value) })}
                      />
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <div className="flex items-center space-x-2">
                      <Switch
                        id="isPopular"
                        checked={newProduct.isPopular}
                        onCheckedChange={(checked) => setNewProduct({ ...newProduct, isPopular: checked })}
                      />
                      <Label htmlFor="isPopular">منتج شائع</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Switch
                        id="isActive"
                        checked={newProduct.isActive}
                        onCheckedChange={(checked) => setNewProduct({ ...newProduct, isActive: checked })}
                      />
                      <Label htmlFor="isActive">نشط</Label>
                    </div>
                  </div>

                  <div className="flex justify-end gap-2">
                    <Button
                      variant="outline"
                      onClick={() => setShowCreateProduct(false)}
                    >
                      إلغاء
                    </Button>
                    <Button
                      onClick={() => createProductMutation.mutate(newProduct)}
                      disabled={createProductMutation.isPending}
                    >
                      {createProductMutation.isPending ? "جاري الإنشاء..." : "إنشاء المنتج"}
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {productsLoading ? (
              <div className="col-span-full text-center py-8">جاري التحميل...</div>
            ) : (
              products?.map((product) => (
                <Card key={product.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-lg">{product.nameAr || product.name}</CardTitle>
                        <div className="flex gap-2 mt-2">
                          <Badge variant={product.isActive ? "default" : "secondary"}>
                            {product.isActive ? "نشط" : "غير نشط"}
                          </Badge>
                          {product.isPopular && <Badge variant="secondary">شائع</Badge>}
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setSelectedProduct(product)}
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-600">السعر:</span>
                        <span className="font-medium">${(product.priceUsd / 100).toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-600">نوع المنتج:</span>
                        <span className="font-medium">{product.productType}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-600">أيام التجربة:</span>
                        <span className="font-medium">{product.trialDays}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-600">صفقات التجربة:</span>
                        <span className="font-medium">{product.trialTrades}</span>
                      </div>
                      <div className="text-sm text-gray-600">
                        <p className="line-clamp-2">{product.descriptionAr || product.description}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </TabsContent>

        {/* Licenses Tab */}
        <TabsContent value="licenses" className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-bold">إدارة التراخيص</h2>
            <Dialog open={showCreateLicense} onOpenChange={setShowCreateLicense}>
              <DialogTrigger asChild>
                <Button className="bg-green-500 hover:bg-green-600">
                  <Plus className="w-4 h-4 mr-2" />
                  إنشاء تراخيص جديدة
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>إنشاء تراخيص جديدة</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label>المنتج</Label>
                    <Select value={newLicense.productId.toString()} onValueChange={(value) => setNewLicense({ ...newLicense, productId: parseInt(value) })}>
                      <SelectTrigger>
                        <SelectValue placeholder="اختر المنتج" />
                      </SelectTrigger>
                      <SelectContent>
                        {products?.map((product) => (
                          <SelectItem key={product.id} value={product.id.toString()}>
                            {product.nameAr || product.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label>نوع الترخيص</Label>
                    <Select value={newLicense.licenseType} onValueChange={(value) => setNewLicense({ ...newLicense, licenseType: value })}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="trial">تجريبي</SelectItem>
                        <SelectItem value="paid">مدفوع</SelectItem>
                        <SelectItem value="lifetime">مدى الحياة</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>عدد الصفقات</Label>
                      <Input
                        type="number"
                        value={newLicense.maxTrades}
                        onChange={(e) => setNewLicense({ ...newLicense, maxTrades: parseInt(e.target.value) })}
                      />
                    </div>
                    <div>
                      <Label>مدة التجربة (أيام)</Label>
                      <Input
                        type="number"
                        value={newLicense.trialDurationDays}
                        onChange={(e) => setNewLicense({ ...newLicense, trialDurationDays: parseInt(e.target.value) })}
                      />
                    </div>
                  </div>

                  <div>
                    <Label>الكمية</Label>
                    <Input
                      type="number"
                      value={newLicense.quantity}
                      onChange={(e) => setNewLicense({ ...newLicense, quantity: parseInt(e.target.value) })}
                      placeholder="عدد التراخيص المراد إنشاؤها"
                    />
                  </div>

                  <div className="flex justify-end gap-2">
                    <Button
                      variant="outline"
                      onClick={() => setShowCreateLicense(false)}
                    >
                      إلغاء
                    </Button>
                    <Button
                      onClick={() => createLicenseMutation.mutate(newLicense)}
                      disabled={createLicenseMutation.isPending}
                    >
                      {createLicenseMutation.isPending ? "جاري الإنشاء..." : "إنشاء التراخيص"}
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          <div className="space-y-4">
            {licensesLoading ? (
              <div className="text-center py-8">جاري التحميل...</div>
            ) : (
              licenses?.map((license) => (
                <Card key={license.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-4">
                          <div className="flex-1">
                            <div className="font-mono text-sm bg-gray-100 p-2 rounded">
                              {license.licenseKey}
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <Badge variant={license.isValid ? "default" : "destructive"}>
                              {license.isValid ? "صالح" : "غير صالح"}
                            </Badge>
                            <Badge variant={license.isActivated ? "default" : "secondary"}>
                              {license.isActivated ? "مفعل" : "غير مفعل"}
                            </Badge>
                            <Badge variant={license.isTrial ? "secondary" : "default"}>
                              {license.isTrial ? "تجريبي" : "مدفوع"}
                            </Badge>
                          </div>
                        </div>
                        <div className="mt-2 grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                          <div>
                            <span className="text-gray-600">الصفقات:</span>
                            <span className="font-medium ml-2">{license.tradesUsed}/{license.maxTrades}</span>
                          </div>
                          <div>
                            <span className="text-gray-600">ينتهي في:</span>
                            <span className="font-medium ml-2">
                              {license.expiresAt ? new Date(license.expiresAt).toLocaleDateString('ar-SA') : 'لا ينتهي'}
                            </span>
                          </div>
                          <div>
                            <span className="text-gray-600">المستخدم:</span>
                            <span className="font-medium ml-2">{license.userId || 'غير محدد'}</span>
                          </div>
                          <div>
                            <span className="text-gray-600">الجهاز:</span>
                            <span className="font-medium ml-2">{license.deviceFingerprint || 'غير محدد'}</span>
                          </div>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => copyToClipboard(license.licenseKey)}
                        >
                          <Copy className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setSelectedLicense(license)}
                        >
                          <Eye className="w-4 h-4" />
                        </Button>
                        {license.isValid && (
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => revokeLicenseMutation.mutate({
                              licenseKey: license.licenseKey,
                              reason: 'Admin revoked'
                            })}
                          >
                            <XCircle className="w-4 h-4" />
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </TabsContent>

        {/* Users Tab */}
        <TabsContent value="users" className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-bold">إدارة المستخدمين</h2>
          </div>

          <div className="space-y-4">
            {usersLoading ? (
              <div className="text-center py-8">جاري التحميل...</div>
            ) : (
              users?.map((user) => (
                <Card key={user.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-4">
                          <div className="flex-1">
                            <div className="font-medium">{user.firstName} {user.lastName}</div>
                            <div className="text-sm text-gray-600">@{user.username} • {user.email}</div>
                          </div>
                          <div className="flex gap-2">
                            <Badge variant={user.isActive ? "default" : "secondary"}>
                              {user.isActive ? "نشط" : "غير نشط"}
                            </Badge>
                            <Badge variant={user.subscriptionStatus === 'active' ? "default" : "secondary"}>
                              {user.subscriptionStatus}
                            </Badge>
                          </div>
                        </div>
                        <div className="mt-2 grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                          <div>
                            <span className="text-gray-600">الإشارات اليومية:</span>
                            <span className="font-medium ml-2">{user.dailySignalsUsed}</span>
                          </div>
                          <div>
                            <span className="text-gray-600">الإشارات الشهرية:</span>
                            <span className="font-medium ml-2">{user.monthlySignalsUsed}</span>
                          </div>
                          <div>
                            <span className="text-gray-600">إجمالي الإشارات:</span>
                            <span className="font-medium ml-2">{user.totalSignalsUsed}</span>
                          </div>
                          <div>
                            <span className="text-gray-600">آخر تسجيل دخول:</span>
                            <span className="font-medium ml-2">
                              {user.lastLogin ? new Date(user.lastLogin).toLocaleDateString('ar-SA') : 'لا يوجد'}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </TabsContent>

        {/* Analytics Tab */}
        <TabsContent value="analytics" className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-bold">تحليلات النظام</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="w-5 h-5" />
                  إحصائيات التراخيص
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span>إجمالي التراخيص:</span>
                    <span className="font-medium">{stats?.totalLicenses || 0}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>التراخيص النشطة:</span>
                    <span className="font-medium text-green-600">{stats?.activeLicenses || 0}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>التراخيص التجريبية:</span>
                    <span className="font-medium text-blue-600">{stats?.trialLicenses || 0}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <DollarSign className="w-5 h-5" />
                  إحصائيات الإيرادات
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span>إجمالي الإيرادات:</span>
                    <span className="font-medium">${(stats?.revenue || 0).toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>إيرادات هذا الشهر:</span>
                    <span className="font-medium text-green-600">${(stats?.revenueThisMonth || 0).toFixed(2)}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}