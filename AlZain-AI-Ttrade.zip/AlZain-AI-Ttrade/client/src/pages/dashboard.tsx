import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useLanguageContext } from '@/components/language-provider';
import { useThemeContext } from '@/components/theme-provider';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { MarketStatus } from '@/components/market-status';
import { TradingRecommendation } from '@/components/trading-recommendation';
import { TechnicalIndicators } from '@/components/technical-indicators';
import { RecentRecommendations } from '@/components/recent-recommendations';
import { TelegramStatus } from '@/components/telegram-status';
import { FloatingRefreshButton } from '@/components/floating-refresh-button';
import { MarketAsset } from '@/../../shared/schema';
import { useState } from 'react';
import { 
  Activity, 
  Users, 
  TrendingUp, 
  BarChart3, 
  Moon, 
  Sun, 
  Globe,
  Menu,
  Settings,
  Send,
  RefreshCw,
  Filter,
  Building2
} from 'lucide-react';

interface DashboardStats {
  totalRecommendations: number;
  successRate: number;
  activeUsers: number;
  avgConfidence: number;
  telegramStats?: {
    sentToday: number;
    subscribers: number;
    responseRate: number;
  };
}

interface TradingPlatform {
  id: number;
  name: string;
  displayName: string;
  logo?: string;
  description: string;
  websiteUrl: string;
  signUpUrl: string;
  minimumDeposit: number;
  supportedAssets: string[];
  features: string[];
  isActive: boolean;
  priority: number;
  telegramChannelId?: string;
}

export default function Dashboard() {
  const { t, language, toggleLanguage } = useLanguageContext();
  const { theme, toggleTheme } = useThemeContext();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedAssetType, setSelectedAssetType] = useState<string>('all');

  const { data: stats, isLoading: statsLoading } = useQuery<DashboardStats>({
    queryKey: ['/api/dashboard/stats'],
    refetchInterval: 60000, // Refetch every minute
  });

  const { data: marketAssets, isLoading: assetsLoading } = useQuery<MarketAsset[]>({
    queryKey: ['/api/market-assets'],
    refetchInterval: 60000,
  });

  const { data: platforms = [], isLoading: platformsLoading } = useQuery<TradingPlatform[]>({
    queryKey: ['/api/platforms/active'],
    refetchInterval: 60000,
  });

  const { data: currentPlatform } = useQuery<TradingPlatform>({
    queryKey: ['/api/platforms/current'],
    refetchInterval: 30000,
  });

  const refreshMarketDataMutation = useMutation({
    mutationFn: () => apiRequest('POST', '/api/market-data/refresh'),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/market-data'] });
      toast({
        title: 'Success',
        description: 'Market data refreshed successfully',
      });
    },
    onError: () => {
      toast({
        title: 'Error',
        description: 'Failed to refresh market data',
        variant: 'destructive',
      });
    },
  });

  const generateRecommendationMutation = useMutation({
    mutationFn: (symbol: string) => apiRequest('POST', '/api/generate-recommendation', { symbol }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/trading-recommendations'] });
      toast({
        title: 'Success',
        description: 'New recommendation generated',
      });
    },
    onError: () => {
      toast({
        title: 'Error',
        description: 'Failed to generate recommendation',
        variant: 'destructive',
      });
    },
  });

  const sendTestTelegramMutation = useMutation({
    mutationFn: () => apiRequest('POST', '/api/telegram/send-test'),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/telegram/stats'] });
      toast({
        title: 'Success',
        description: 'Test message sent to Telegram',
      });
    },
    onError: () => {
      toast({
        title: 'Error',
        description: 'Failed to send test message',
        variant: 'destructive',
      });
    },
  });

  const setActivePlatformMutation = useMutation({
    mutationFn: (platformId: string) => apiRequest('POST', '/api/platforms/set-active', { platformId }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/platforms/current'] });
      queryClient.invalidateQueries({ queryKey: ['/api/trading-recommendations'] });
      toast({
        title: language === 'ar' ? 'تم التحديث' : 'Updated',
        description: language === 'ar' ? 'تم تغيير المنصة بنجاح' : 'Platform changed successfully',
      });
    },
    onError: () => {
      toast({
        title: language === 'ar' ? 'خطأ' : 'Error',
        description: language === 'ar' ? 'فشل في تغيير المنصة' : 'Failed to change platform',
        variant: 'destructive',
      });
    },
  });

  const handleRefreshAll = () => {
    queryClient.invalidateQueries({ queryKey: ['/api/dashboard/stats'] });
    queryClient.invalidateQueries({ queryKey: ['/api/market-assets'] });
    queryClient.invalidateQueries({ queryKey: ['/api/market-data'] });
    queryClient.invalidateQueries({ queryKey: ['/api/trading-recommendations'] });
    queryClient.invalidateQueries({ queryKey: ['/api/telegram/stats'] });
    queryClient.invalidateQueries({ queryKey: ['/api/platforms/active'] });
    queryClient.invalidateQueries({ queryKey: ['/api/platforms/current'] });
    refreshMarketDataMutation.mutate();
  };

  const handlePlatformChange = (platformId: string) => {
    setActivePlatformMutation.mutate(platformId);
    // Reset asset type filter when platform changes
    setSelectedAssetType('all');
  };

  const getPlatformIcon = (platformName: string) => {
    switch (platformName.toLowerCase()) {
      case 'quotex': return '🎯';
      case 'iq_option': return '🧠';
      case 'binomo': return '💫';
      case 'pocket_option': return '🚀';
      case 'olymp_trade': return '🏆';
      default: return '📊';
    }
  };

  // Filter assets by platform first, then by type
  const platformFilteredAssets = marketAssets?.filter(asset => {
    // If no platform is selected, show all assets
    if (!currentPlatform || !currentPlatform.supportedAssets) return true;
    // Only show assets supported by the current platform
    return currentPlatform.supportedAssets.includes(asset.symbol);
  }) || [];

  const filteredAssets = platformFilteredAssets.filter(asset => 
    selectedAssetType === 'all' || asset.type === selectedAssetType
  );

  // Get unique asset types from platform-filtered assets for dropdown
  const assetTypes = platformFilteredAssets.reduce((types: string[], asset) => {
    if (!types.includes(asset.type)) {
      types.push(asset.type);
    }
    return types;
  }, []) || [];

  // Asset type labels
  const getAssetTypeLabel = (type: string) => {
    const labels = {
      forex: language === 'ar' ? 'العملات الأجنبية' : 'Forex',
      crypto: language === 'ar' ? 'العملات الرقمية' : 'Crypto',
      stock: language === 'ar' ? 'الأسهم' : 'Stocks',
      commodity: language === 'ar' ? 'السلع' : 'Commodities',
      index: language === 'ar' ? 'المؤشرات' : 'Indices',
    };
    return labels[type as keyof typeof labels] || type;
  };

  const StatCard = ({ title, value, icon: Icon, trend }: {
    title: string;
    value: string | number;
    icon: any;
    trend?: { value: string; positive: boolean };
  }) => (
    <Card className="card-hover">
      <CardContent className="pt-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-muted-foreground">{title}</p>
            <p className="text-2xl font-bold text-foreground">{value}</p>
          </div>
          <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
            <Icon className="h-6 w-6 text-primary" />
          </div>
        </div>
        {trend && (
          <div className="mt-4 flex items-center text-sm">
            <TrendingUp className={`h-4 w-4 mr-1 ${trend.positive ? 'text-green-500' : 'text-red-500 rotate-180'}`} />
            <span className={trend.positive ? 'text-green-500' : 'text-red-500'}>
              {trend.value}
            </span>
            <span className="text-muted-foreground ml-2">from last week</span>
          </div>
        )}
      </CardContent>
    </Card>
  );

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card/80 backdrop-blur-sm shadow-sm border-b border-border sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo and Brand */}
            <div className="flex items-center space-x-4 rtl:space-x-reverse">
              <div className="flex items-center space-x-2 rtl:space-x-reverse">
                <div className="w-8 h-8 bg-gradient-to-br from-primary to-accent rounded-lg p-1 shadow-lg">
                  <img 
                    src="/app-icon.jpg" 
                    alt="AlZainTrade Logo" 
                    className="w-full h-full rounded-md object-cover"
                    onError={(e) => {
                      // Fallback to chart icon if image fails
                      const target = e.currentTarget as HTMLImageElement;
                      const nextElement = target.nextElementSibling as HTMLElement;
                      target.style.display = 'none';
                      if (nextElement) {
                        nextElement.style.display = 'block';
                      }
                    }}
                  />
                  <BarChart3 className="h-5 w-5 text-white hidden" />
                </div>
                <span className="text-xl font-bold text-foreground">AlZainTrade</span>
              </div>
            </div>

            {/* Navigation */}
            <nav className="hidden md:flex space-x-8 rtl:space-x-reverse">
              <a href="#" className="text-foreground hover:text-primary px-3 py-2 text-sm font-medium">
                {t('dashboard')}
              </a>
              <a href="#" className="text-muted-foreground hover:text-primary px-3 py-2 text-sm font-medium">
                {t('recommendations')}
              </a>
              <a href="#" className="text-muted-foreground hover:text-primary px-3 py-2 text-sm font-medium">
                {t('technicalAnalysis')}
              </a>
              <a href="#" className="text-muted-foreground hover:text-primary px-3 py-2 text-sm font-medium">
                {t('statistics')}
              </a>
            </nav>

            {/* Right Side Actions */}
            <div className="flex items-center space-x-4 rtl:space-x-reverse">
              {/* Theme Toggle */}
              <Button
                variant="ghost"
                size="icon"
                onClick={toggleTheme}
                className="hover:bg-muted"
              >
                {theme === 'light' ? <Moon className="h-5 w-5" /> : <Sun className="h-5 w-5" />}
              </Button>
              
              {/* Language Toggle */}
              <Button
                variant="ghost"
                size="sm"
                onClick={toggleLanguage}
                className="hover:bg-muted"
              >
                <Globe className="h-4 w-4 mr-1" />
                {language === 'ar' ? 'EN' : 'عر'}
              </Button>
              
              {/* User Profile */}
              <div className="flex items-center space-x-2 rtl:space-x-reverse">
                <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                  <Users className="h-4 w-4 text-white" />
                </div>
                <span className="text-sm font-medium text-foreground">Ahmed AlZain</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        {/* Quick Stats */}
        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-foreground">
            {language === 'ar' ? 'إحصائيات سريعة' : 'Quick Stats'}
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <StatCard
            title={t('totalRecommendations')}
            value={stats?.totalRecommendations || 0}
            icon={Activity}
            trend={{ value: '+12%', positive: true }}
          />
          <StatCard
            title={t('successRate')}
            value={`${stats?.successRate || 0}%`}
            icon={TrendingUp}
            trend={{ value: '+2.1%', positive: true }}
          />
          <StatCard
            title={t('activeUsers')}
            value={stats?.activeUsers || 0}
            icon={Users}
            trend={{ value: '+8.5%', positive: true }}
          />
          <StatCard
            title={t('avgConfidence')}
            value={`${stats?.avgConfidence || 0}%`}
            icon={BarChart3}
            trend={{ value: '+1.2%', positive: true }}
          />
          </div>
        </section>

        {/* Platform Selector */}
        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-foreground">
            {language === 'ar' ? 'منصة التداول النشطة' : 'Active Trading Platform'}
          </h2>
          <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-950 dark:to-indigo-950 border-blue-200 dark:border-blue-800">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-blue-800 dark:text-blue-200">
                <Building2 className="h-5 w-5" />
                {language === 'ar' ? 'اختيار المنصة' : 'Platform Selection'}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center">
                {/* Current Platform Display */}
                <div className="flex-1">
                  {currentPlatform ? (
                    <div className="flex items-center gap-3">
                      <span className="text-2xl">{getPlatformIcon(currentPlatform.name)}</span>
                      <div>
                        <h3 className="font-semibold text-lg text-blue-900 dark:text-blue-100">
                          {currentPlatform.displayName}
                        </h3>
                        <p className="text-sm text-blue-600 dark:text-blue-300">
                          {currentPlatform.supportedAssets?.length || 0} {language === 'ar' ? 'أصل متاح' : 'assets available'}
                        </p>
                      </div>
                    </div>
                  ) : (
                    <div className="text-gray-500">
                      {language === 'ar' ? 'لم يتم تحديد منصة' : 'No platform selected'}
                    </div>
                  )}
                </div>

                {/* Platform Dropdown */}
                <div className="w-full sm:w-64">
                  <Select 
                    value={currentPlatform?.id?.toString() || ""} 
                    onValueChange={handlePlatformChange}
                    disabled={setActivePlatformMutation.isPending}
                  >
                    <SelectTrigger className="bg-white dark:bg-gray-800 border-blue-300 dark:border-blue-700">
                      <SelectValue placeholder={language === 'ar' ? 'اختر المنصة' : 'Select Platform'} />
                    </SelectTrigger>
                    <SelectContent>
                      {platforms.map((platform: TradingPlatform) => (
                        <SelectItem key={platform.id} value={platform.id.toString()}>
                          <div className="flex items-center gap-2">
                            <span>{getPlatformIcon(platform.name)}</span>
                            <span>{platform.displayName}</span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Platform Info */}
              {currentPlatform && (
                <div className="pt-3 border-t border-blue-200 dark:border-blue-800">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                    <div>
                      <span className="font-medium text-blue-800 dark:text-blue-200">
                        {language === 'ar' ? 'الحد الأدنى:' : 'Min Deposit:'}
                      </span>
                      <p className="text-blue-600 dark:text-blue-300">${currentPlatform.minimumDeposit}</p>
                    </div>
                    <div>
                      <span className="font-medium text-blue-800 dark:text-blue-200">
                        {language === 'ar' ? 'الأصول:' : 'Assets:'}
                      </span>
                      <p className="text-blue-600 dark:text-blue-300">{currentPlatform.supportedAssets?.length || 0}</p>
                    </div>
                    <div>
                      <span className="font-medium text-blue-800 dark:text-blue-200">
                        {language === 'ar' ? 'الحالة:' : 'Status:'}
                      </span>
                      <p className="text-green-600 dark:text-green-400">
                        {language === 'ar' ? 'جاهز للتداول' : 'Ready to Trade'}
                      </p>
                    </div>
                    <div>
                      <Button
                        variant="outline"
                        size="sm"
                        className="text-blue-600 border-blue-300 hover:bg-blue-50 dark:text-blue-400 dark:border-blue-700 dark:hover:bg-blue-950"
                        onClick={() => window.open(currentPlatform.websiteUrl, '_blank')}
                      >
                        <Globe className="h-3 w-3 mr-1" />
                        {language === 'ar' ? 'زيارة الموقع' : 'Visit Site'}
                      </Button>
                    </div>
                  </div>
                </div>
              )}

              {/* Loading State */}
              {setActivePlatformMutation.isPending && (
                <div className="flex items-center gap-2 text-blue-600 dark:text-blue-400">
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600 dark:border-blue-400"></div>
                  {language === 'ar' ? 'جاري تحديث المنصة...' : 'Updating platform...'}
                </div>
              )}
            </CardContent>
          </Card>
        </section>

        {/* Market Assets with Filtering */}
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold text-foreground">
              {currentPlatform 
                ? (language === 'ar' ? `أصول منصة ${currentPlatform.displayName}` : `${currentPlatform.displayName} Platform Assets`)
                : (language === 'ar' ? 'أصول التداول المتاحة' : 'Available Trading Assets')
              }
            </h2>
            {currentPlatform && (
              <Badge variant="secondary" className="text-sm">
                {language === 'ar' ? 'متوافق مع المنصة' : 'Platform Compatible'}
              </Badge>
            )}
          </div>
          <Card>
          <CardHeader>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex flex-col gap-2">
                <CardTitle className="text-lg font-semibold flex items-center gap-2">
                  <Filter className="h-5 w-5" />
                  {language === 'ar' ? 'قائمة الأصول المتاحة' : 'Available Assets List'}
                </CardTitle>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <span className="font-medium text-primary">{filteredAssets.length}</span>
                    {language === 'ar' ? 'أصل مُصفى من' : 'filtered assets of'}
                    <span className="font-medium">{platformFilteredAssets.length}</span>
                    {language === 'ar' ? 'أصل متاح' : 'available'}
                  </span>
                  {currentPlatform && (
                    <Badge variant="outline" className="text-xs">
                      {currentPlatform.displayName}
                    </Badge>
                  )}
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-2">
                  <span className="text-sm text-muted-foreground">
                    {language === 'ar' ? 'تصفية بالنوع:' : 'Filter by type:'}
                  </span>
                  <Select value={selectedAssetType} onValueChange={setSelectedAssetType}>
                    <SelectTrigger className="w-48">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">
                        {language === 'ar' ? 'جميع الأصول' : 'All Assets'}
                      </SelectItem>
                      {assetTypes.map(type => (
                        <SelectItem key={type} value={type}>
                          <div className="flex items-center gap-2">
                            <span className="text-xs">
                              {platformFilteredAssets.filter(a => a.type === type).length}
                            </span>
                            {getAssetTypeLabel(type)}
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {/* Asset Type Summary */}
            {!assetsLoading && platformFilteredAssets.length > 0 && (
              <div className="mb-6 p-4 bg-muted/50 rounded-lg">
                <h4 className="font-medium mb-3 text-sm text-muted-foreground">
                  {language === 'ar' ? 'ملخص أنواع الأصول:' : 'Asset Type Summary:'}
                </h4>
                <div className="flex flex-wrap gap-2">
                  {assetTypes.map(type => {
                    const count = platformFilteredAssets.filter(a => a.type === type).length;
                    return (
                      <Badge 
                        key={type} 
                        variant={selectedAssetType === type ? "default" : "secondary"}
                        className="text-xs cursor-pointer hover:opacity-80"
                        onClick={() => setSelectedAssetType(selectedAssetType === type ? 'all' : type)}
                      >
                        {getAssetTypeLabel(type)} ({count})
                      </Badge>
                    );
                  })}
                </div>
              </div>
            )}

            {assetsLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {[...Array(6)].map((_, i) => (
                  <div key={i} className="h-24 bg-muted rounded-lg animate-pulse" />
                ))}
              </div>
            ) : (
              <>
                {/* Platform Compatibility Notice */}
                {currentPlatform && filteredAssets.length > 0 && (
                  <div className="mb-4 p-3 bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-800 rounded-lg">
                    <div className="flex items-center gap-2 text-sm text-blue-800 dark:text-blue-200">
                      <Building2 className="h-4 w-4" />
                      <span>
                        {language === 'ar' 
                          ? `الأصول المعروضة متوافقة مع منصة ${currentPlatform.displayName}` 
                          : `Showing assets compatible with ${currentPlatform.displayName} platform`
                        }
                      </span>
                    </div>
                  </div>
                )}

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {filteredAssets.map(asset => (
                    <div key={asset.id} className="p-4 border rounded-lg hover:shadow-md hover:border-primary/20 transition-all duration-200 bg-card">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <h4 className="font-semibold text-foreground text-lg">{asset.symbol}</h4>
                            <div className={`w-2 h-2 rounded-full ${asset.isActive ? 'bg-green-500' : 'bg-red-500'}`} />
                          </div>
                          <p className="text-sm text-muted-foreground mb-3 line-clamp-2">{asset.name}</p>
                          
                          <div className="flex items-center justify-between">
                            <Badge 
                              variant="outline" 
                              className="text-xs"
                              style={{
                                backgroundColor: asset.type === 'forex' ? '#e3f2fd' : 
                                                asset.type === 'crypto' ? '#fff3e0' :
                                                asset.type === 'stock' ? '#f3e5f5' :
                                                asset.type === 'commodity' ? '#e8f5e8' : '#f5f5f5'
                              }}
                            >
                              {getAssetTypeLabel(asset.type)}
                            </Badge>
                            
                            <span className="text-xs text-muted-foreground">
                              {asset.isActive ? 
                                (language === 'ar' ? 'نشط' : 'Active') : 
                                (language === 'ar' ? 'غير نشط' : 'Inactive')
                              }
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </>
            )}
            
            {filteredAssets.length === 0 && !assetsLoading && (
              <div className="text-center py-12">
                <div className="mx-auto w-16 h-16 bg-muted rounded-full flex items-center justify-center mb-4">
                  <Filter className="h-8 w-8 text-muted-foreground" />
                </div>
                <h3 className="text-lg font-semibold text-foreground mb-2">
                  {language === 'ar' ? 'لا توجد أصول متاحة' : 'No assets available'}
                </h3>
                <p className="text-muted-foreground">
                  {currentPlatform 
                    ? (language === 'ar' 
                        ? `لا توجد أصول من نوع "${getAssetTypeLabel(selectedAssetType)}" متوافقة مع منصة ${currentPlatform.displayName}`
                        : `No "${getAssetTypeLabel(selectedAssetType)}" assets compatible with ${currentPlatform.displayName} platform`
                      )
                    : (language === 'ar' ? 'يرجى اختيار منصة التداول أولاً' : 'Please select a trading platform first')
                  }
                </p>
              </div>
            )}
          </CardContent>
        </Card>
        </section>

        {/* Market Status and Latest Recommendation */}
        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-foreground">
            {language === 'ar' ? 'حالة السوق والتوصيات' : 'Market Status & Recommendations'}
          </h2>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Market Status */}
            <div className="lg:col-span-2">
              <MarketStatus />
            </div>

            {/* Latest Recommendation */}
            <div className="lg:col-span-1">
              <TradingRecommendation />
            </div>
          </div>
        </section>

        {/* Technical Analysis Section */}
        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-foreground">
            {language === 'ar' ? 'التحليل الفني والذكاء الاصطناعي' : 'Technical Analysis & AI Insights'}
          </h2>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Technical Indicators */}
          <TechnicalIndicators />

          {/* AI Analysis */}
          <Card className="card-hover">
            <CardHeader>
              <CardTitle className="text-lg font-semibold">
                {t('aiAnalysis')}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {/* AI Confidence Meter */}
              <div className="mb-6">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-muted-foreground">
                    {t('overallConfidence')}
                  </span>
                  <span className="text-2xl font-bold text-primary">91%</span>
                </div>
                <div className="w-full bg-muted rounded-full h-3">
                  <div 
                    className="bg-gradient-to-r from-primary to-primary/80 h-3 rounded-full" 
                    style={{ width: '91%' }}
                  ></div>
                </div>
              </div>

              {/* AI Insights */}
              <div className="space-y-4">
                <div className="p-4 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg">
                  <div className="flex items-center space-x-2 rtl:space-x-reverse mb-2">
                    <Activity className="h-4 w-4 text-green-600" />
                    <span className="font-medium text-green-800 dark:text-green-200">
                      {t('positiveAnalysis')}
                    </span>
                  </div>
                  <p className="text-sm text-green-700 dark:text-green-300">
                    The model predicts continued upward trend for EUR/USD based on advanced technical analysis
                  </p>
                </div>

                <div className="p-4 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg">
                  <div className="flex items-center space-x-2 rtl:space-x-reverse mb-2">
                    <BarChart3 className="h-4 w-4 text-blue-600" />
                    <span className="font-medium text-blue-800 dark:text-blue-200">
                      {t('technicalPattern')}
                    </span>
                  </div>
                  <p className="text-sm text-blue-700 dark:text-blue-300">
                    Resistance breakout pattern detected with increased volume supporting upward movement
                  </p>
                </div>

                <div className="p-4 bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg">
                  <div className="flex items-center space-x-2 rtl:space-x-reverse mb-2">
                    <Activity className="h-4 w-4 text-yellow-600" />
                    <span className="font-medium text-yellow-800 dark:text-yellow-200">
                      {t('warning')}
                    </span>
                  </div>
                  <p className="text-sm text-yellow-700 dark:text-yellow-300">
                    Monitor European economic news scheduled for the next 2 hours
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
          </div>
        </section>

        {/* Recent Recommendations */}
        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-foreground">
            {language === 'ar' ? 'التوصيات الأخيرة' : 'Recent Recommendations'}
          </h2>
          <RecentRecommendations />
        </section>

        {/* Telegram Bot Status */}
        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-foreground">
            {language === 'ar' ? 'حالة بوت تليجرام' : 'Telegram Bot Status'}
          </h2>
          <TelegramStatus />
        </section>
      </main>

      {/* Floating Refresh Button */}
      <FloatingRefreshButton onRefresh={handleRefreshAll} />
    </div>
  );
}
