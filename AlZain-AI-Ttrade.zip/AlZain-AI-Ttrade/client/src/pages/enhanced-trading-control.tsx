import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useLanguageContext } from '../components/language-provider';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Switch } from '../components/ui/switch';
import { Slider } from '../components/ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Badge } from '../components/ui/badge';
import { Label } from '../components/ui/label';
import { Separator } from '../components/ui/separator';
import { Input } from '../components/ui/input';
import { Checkbox } from '../components/ui/checkbox';
import { Progress } from '../components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { useToast } from '../hooks/use-toast';
import { apiRequest, queryClient } from '../lib/queryClient';
import { 
  Play, 
  Pause, 
  Settings, 
  Clock, 
  Target, 
  AlertTriangle,
  Activity,
  TrendingUp,
  Bot,
  Zap,
  Shield,
  BarChart3,
  ChevronDown,
  ChevronUp,
  DollarSign,
  Save,
  RotateCcw,
  CheckCircle,
  XCircle,
  TimerIcon,
  Users,
  Globe,
  Building2
} from 'lucide-react';
import { CountdownTimer } from '../components/countdown-timer';
import { motion, AnimatePresence } from 'framer-motion';

// Simple Platform Dropdown Component
const PlatformDropdown = () => {
  const { language } = useLanguageContext();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch available platforms
  const { data: platforms = [] } = useQuery({
    queryKey: ['/api/platforms/active'],
    refetchInterval: 30000,
  });

  // Fetch current platform
  const { data: currentPlatform } = useQuery({
    queryKey: ['/api/platforms/current'],
    refetchInterval: 30000,
  });

  // Change platform mutation
  const changePlatformMutation = useMutation({
    mutationFn: async (platformId: number) => {
      return apiRequest('POST', '/api/platforms/change', { platformId });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/platforms/current'] });
      queryClient.invalidateQueries({ queryKey: ['/api/market-assets'] });
      toast({
        title: language === 'ar' ? 'تم التغيير' : 'Platform Changed',
        description: language === 'ar' ? 'تم تغيير المنصة بنجاح' : 'Platform changed successfully',
      });
    },
    onError: () => {
      toast({
        title: language === 'ar' ? 'خطأ' : 'Error',
        description: language === 'ar' ? 'فشل في تغيير المنصة' : 'Failed to change platform',
        variant: 'destructive',
      });
    },
  });

  const handlePlatformChange = (platformId: string) => {
    changePlatformMutation.mutate(parseInt(platformId));
  };

  if (!currentPlatform || platforms.length === 0) {
    return null;
  }

  return (
    <div className="flex items-center gap-2">
      <Select 
        value={currentPlatform.id.toString()} 
        onValueChange={handlePlatformChange}
        disabled={changePlatformMutation.isPending}
      >
        <SelectTrigger className="w-[140px] sm:w-[160px] h-10">
          <div className="flex items-center gap-2">
            <Building2 className="h-4 w-4 text-blue-600" />
            <SelectValue />
          </div>
        </SelectTrigger>
        <SelectContent>
          {platforms.map((platform: any) => (
            <SelectItem key={platform.id} value={platform.id.toString()}>
              <div className="flex items-center gap-2">
                <div className={`w-2 h-2 rounded-full ${platform.id === currentPlatform.id ? 'bg-green-500' : 'bg-gray-400'}`} />
                <span>{platform.displayName}</span>
              </div>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
      
      {/* Current Platform Badge */}
      <Badge variant="outline" className="hidden sm:flex items-center gap-1 text-xs">
        <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
        {currentPlatform.displayName}
      </Badge>
    </div>
  );
};

// Real-time clock component
const RealTimeClock = ({ language, tradingHours }: { 
  language: string; 
  tradingHours: { start: string; end: string; enabled: boolean } 
}) => {
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const getCurrentStatus = () => {
    if (!tradingHours.enabled) return null;
    
    const now = currentTime;
    const currentHour = now.getHours();
    const currentMinute = now.getMinutes();
    const currentTimeInMinutes = currentHour * 60 + currentMinute;
    
    const [startHour, startMinute] = tradingHours.start.split(':').map(Number);
    const [endHour, endMinute] = tradingHours.end.split(':').map(Number);
    const startTime = startHour * 60 + startMinute;
    const endTime = endHour * 60 + endMinute;
    
    const isWithinHours = currentTimeInMinutes >= startTime && currentTimeInMinutes <= endTime;
    
    return isWithinHours 
      ? (language === 'ar' ? '✅ ضمن ساعات التداول' : '✅ Within trading hours')
      : (language === 'ar' ? '⏰ خارج ساعات التداول' : '⏰ Outside trading hours');
  };

  return (
    <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-800">
      <div className="flex items-center gap-2 mb-1">
        <TimerIcon className="h-4 w-4 text-blue-600" />
        <span className="font-medium text-blue-800 dark:text-blue-200">
          {language === 'ar' ? 'الوقت الحالي' : 'Current Time'}
        </span>
      </div>
      <div className="text-lg font-mono text-blue-700 dark:text-blue-300">
        {currentTime.toLocaleTimeString('en-GB', { hour12: false })}
      </div>
      {tradingHours.enabled && (
        <div className="text-xs text-blue-600 dark:text-blue-400 mt-1">
          {getCurrentStatus()}
        </div>
      )}
    </div>
  );
};

interface TradingSettings {
  autoSignalsEnabled: boolean;
  signalInterval: number;
  minConfidence: number;
  maxRiskLevel: 'low' | 'medium' | 'high';
  enabledAssets: string[];
  tradingHours: {
    start: string;
    end: string;
    enabled: boolean;
  };
  maxSignalsPerDay: number;
  stopLossEnabled: boolean;
  takeProfitEnabled: boolean;
}

interface SystemStatus {
  isActive: boolean;
  lastSignal: string;
  signalsToday: number;
  successRate: number;
  nextSignalIn: number;
}

const DEFAULT_SETTINGS: TradingSettings = {
  autoSignalsEnabled: false,
  signalInterval: 10,
  minConfidence: 75,
  maxRiskLevel: 'medium',
  enabledAssets: ['EUR/USD', 'GBP/USD', 'XAU/USD', 'BTC/USD'],
  tradingHours: {
    start: '09:00',
    end: '17:00',
    enabled: true
  },
  maxSignalsPerDay: 20,
  stopLossEnabled: true,
  takeProfitEnabled: true
};

const AVAILABLE_ASSETS = [
  { symbol: 'EUR/USD', name: 'Euro/US Dollar', category: 'forex' },
  { symbol: 'GBP/USD', name: 'British Pound/US Dollar', category: 'forex' },
  { symbol: 'USD/JPY', name: 'US Dollar/Japanese Yen', category: 'forex' },
  { symbol: 'AUD/USD', name: 'Australian Dollar/US Dollar', category: 'forex' },
  { symbol: 'USD/CAD', name: 'US Dollar/Canadian Dollar', category: 'forex' },
  { symbol: 'EUR/GBP', name: 'Euro/British Pound', category: 'forex' },
  { symbol: 'XAU/USD', name: 'Gold/US Dollar', category: 'commodity' },
  { symbol: 'XAG/USD', name: 'Silver/US Dollar', category: 'commodity' },
  { symbol: 'WTI/USD', name: 'Crude Oil/US Dollar', category: 'commodity' },
  { symbol: 'BTC/USD', name: 'Bitcoin/US Dollar', category: 'crypto' },
  { symbol: 'ETH/USD', name: 'Ethereum/US Dollar', category: 'crypto' },
  { symbol: 'LTC/USD', name: 'Litecoin/US Dollar', category: 'crypto' }
];

export default function EnhancedTradingControl() {
  const { language } = useLanguageContext();
  const { toast } = useToast();
  
  const [settings, setSettings] = useState<TradingSettings>(() => {
    const saved = localStorage.getItem('enhanced-trading-settings');
    return saved ? JSON.parse(saved) : DEFAULT_SETTINGS;
  });
  
  const [activeTab, setActiveTab] = useState('overview');
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);

  // Fetch system status
  const { data: systemStatus, refetch: refetchStatus } = useQuery<SystemStatus>({
    queryKey: ['/api/system-status'],
    refetchInterval: 5000,
  });

  // Fetch telegram stats
  const { data: telegramStats } = useQuery({
    queryKey: ['/api/telegram/stats'],
    refetchInterval: 10000,
  });

  // Save settings mutation
  const saveSettingsMutation = useMutation({
    mutationFn: async (newSettings: TradingSettings) => {
      localStorage.setItem('enhanced-trading-settings', JSON.stringify(newSettings));
      
      // Always update trading settings on backend
      await apiRequest('POST', '/api/trading-settings/update', {
        ...newSettings,
        autoSignalsEnabled: newSettings.autoSignalsEnabled
      });
      
      return { success: true };
    },
    onSuccess: () => {
      setHasUnsavedChanges(false);
      refetchStatus();
      toast({
        title: language === 'ar' ? 'تم الحفظ بنجاح' : 'Settings Saved',
        description: language === 'ar' 
          ? 'تم تطبيق جميع إعدادات التداول وساعات التداول' 
          : 'All trading settings and trading hours have been applied',
      });
    },
    onError: (error: any) => {
      toast({
        title: language === 'ar' ? 'خطأ في الحفظ' : 'Save Error',
        description: error.message || (language === 'ar' ? 'فشل في حفظ الإعدادات' : 'Failed to save settings'),
        variant: 'destructive',
      });
    },
  });

  // Toggle auto signals
  const toggleAutoSignalsMutation = useMutation({
    mutationFn: async (enabled: boolean) => {
      if (enabled) {
        return apiRequest('POST', '/api/auto-signals/start', {
          interval: settings.signalInterval,
          maxPerDay: settings.maxSignalsPerDay,
          minConfidence: settings.minConfidence,
          maxRiskLevel: settings.maxRiskLevel,
          enabledAssets: settings.enabledAssets,
          tradingHours: settings.tradingHours,
          stopLossEnabled: settings.stopLossEnabled,
          takeProfitEnabled: settings.takeProfitEnabled
        });
      } else {
        return apiRequest('POST', '/api/auto-signals/stop');
      }
    },
    onSuccess: (data, enabled) => {
      setSettings(prev => ({ ...prev, autoSignalsEnabled: enabled }));
      refetchStatus();
      toast({
        title: language === 'ar' ? 'تم التحديث' : 'Updated',
        description: enabled 
          ? (language === 'ar' ? 'تم تفعيل الإشارات التلقائية' : 'Auto signals enabled')
          : (language === 'ar' ? 'تم إيقاف الإشارات التلقائية' : 'Auto signals disabled'),
      });
    },
  });

  // Generate immediate signal
  const generateSignalMutation = useMutation({
    mutationFn: async () => {
      const assets = settings.enabledAssets;
      const randomAsset = assets[Math.floor(Math.random() * assets.length)];
      
      return apiRequest('POST', '/api/generate-recommendation', {
        symbol: randomAsset,
        sendToTelegram: true,
        minConfidence: settings.minConfidence,
        maxRiskLevel: settings.maxRiskLevel,
      });
    },
    onSuccess: () => {
      refetchStatus();
      queryClient.invalidateQueries({ queryKey: ['/api/telegram/stats'] });
      toast({
        title: language === 'ar' ? 'تم إنشاء إشارة جديدة' : 'New Signal Generated',
        description: language === 'ar' 
          ? 'تم إرسال الإشارة إلى تليجرام بنجاح' 
          : 'Signal sent to Telegram successfully',
      });
    },
  });

  const handleSettingChange = (key: keyof TradingSettings, value: any) => {
    setSettings(prev => ({ ...prev, [key]: value }));
    setHasUnsavedChanges(true);
  };

  const handleAssetToggle = (asset: string, checked: boolean) => {
    const newAssets = checked 
      ? [...settings.enabledAssets, asset]
      : settings.enabledAssets.filter(a => a !== asset);
    
    handleSettingChange('enabledAssets', newAssets);
  };

  const handleResetSettings = () => {
    setSettings(DEFAULT_SETTINGS);
    setHasUnsavedChanges(true);
    toast({
      title: language === 'ar' ? 'تم إعادة التعيين' : 'Settings Reset',
      description: language === 'ar' 
        ? 'تم إعادة تعيين جميع الإعدادات' 
        : 'All settings have been reset',
    });
  };

  // Auto-save when settings change (with debouncing)
  useEffect(() => {
    localStorage.setItem('enhanced-trading-settings', JSON.stringify(settings));
    
    // Auto-apply settings to backend after a delay
    const timeoutId = setTimeout(async () => {
      if (hasUnsavedChanges) {
        try {
          await apiRequest('POST', '/api/trading-settings/update', {
            ...settings,
            autoSignalsEnabled: settings.autoSignalsEnabled
          });
          
          setHasUnsavedChanges(false);
          console.log('Settings auto-saved and applied to backend');
        } catch (error) {
          console.log('Auto-save failed, manual save required:', error);
        }
      }
    }, 2000); // Apply settings after 2 seconds of inactivity

    return () => clearTimeout(timeoutId);
  }, [settings, hasUnsavedChanges]);

  const getAssetsByCategory = (category: string) => {
    return AVAILABLE_ASSETS.filter(asset => asset.category === category);
  };

  const getRiskLevelColor = (level: string) => {
    switch (level) {
      case 'low': return 'text-green-600 bg-green-50 border-green-200';
      case 'medium': return 'text-yellow-600 bg-yellow-50 border-yellow-200';
      case 'high': return 'text-red-600 bg-red-50 border-red-200';
      default: return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  return (
    <div className="container mx-auto px-3 sm:px-6 py-4 sm:py-6 space-y-4 sm:space-y-6 max-w-7xl">
      {/* Header - Mobile Optimized */}
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col space-y-3 sm:flex-row sm:items-center sm:justify-between sm:space-y-0"
      >
        <div className="flex-1 min-w-0">
          <h1 className="text-xl sm:text-2xl lg:text-3xl font-bold bg-gradient-to-r from-blue-600 to-emerald-600 bg-clip-text text-transparent truncate">
            {language === 'ar' ? 'التحكم المتطور في التداول' : 'Advanced Trading Control'}
          </h1>
          <p className="text-sm sm:text-base text-gray-600 dark:text-gray-400 mt-1">
            {language === 'ar' ? 'إدارة شاملة ومتطورة لجميع إعدادات التداول' : 'Comprehensive and advanced trading settings management'}
          </p>
        </div>
        <div className="flex items-center gap-2 sm:gap-3 flex-shrink-0">
          {/* Simple Platform Selector */}
          <PlatformDropdown />
        </div>
      </motion.div>

      {/* Quick Navigation - Mobile Optimized */}
      <div className="fixed bottom-4 right-4 z-50 flex flex-col gap-2">
        <Button
          onClick={() => window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' })}
          size="icon"
          className="h-12 w-12 rounded-full bg-gradient-to-r from-blue-600 to-emerald-600 hover:from-blue-700 hover:to-emerald-700 shadow-lg hover:shadow-xl transition-all duration-300"
        >
          <ChevronDown className="h-5 w-5 text-white" />
        </Button>
        <Button
          onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          size="icon"
          className="h-12 w-12 rounded-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 shadow-lg hover:shadow-xl transition-all duration-300"
        >
          <ChevronUp className="h-5 w-5 text-white" />
        </Button>
      </div>

      {/* System Status Cards - Mobile Optimized */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.1 }}
        >
          <Card className="border-l-4 border-l-blue-500">
            <CardHeader className="pb-2 sm:pb-3">
              <CardTitle className="text-sm sm:text-lg flex items-center gap-2">
                <Activity className="h-4 w-4 sm:h-5 sm:w-5 text-blue-500" />
                <span className="truncate">{language === 'ar' ? 'حالة النظام' : 'System Status'}</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="flex items-center justify-between">
                <Badge className={`text-xs ${systemStatus?.isActive ? 'bg-green-500' : 'bg-red-500'}`}>
                  {systemStatus?.isActive 
                    ? (language === 'ar' ? 'نشط' : 'Active')
                    : (language === 'ar' ? 'متوقف' : 'Stopped')
                  }
                </Badge>
                {systemStatus?.isActive ? 
                  <CheckCircle className="h-5 w-5 sm:h-6 sm:w-6 text-green-500" /> :
                  <XCircle className="h-5 w-5 sm:h-6 sm:w-6 text-red-500" />
                }
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.2 }}
        >
          <Card className="border-l-4 border-l-emerald-500">
            <CardHeader className="pb-2 sm:pb-3">
              <CardTitle className="text-sm sm:text-lg flex items-center gap-2">
                <TrendingUp className="h-4 w-4 sm:h-5 sm:w-5 text-emerald-500" />
                <span className="truncate">{language === 'ar' ? 'إشارات اليوم' : "Today's Signals"}</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xl sm:text-2xl font-bold text-emerald-600">
                  {telegramStats?.sentToday || 0}
                </span>
                <div className="text-xs sm:text-sm text-gray-500">
                  / {settings.maxSignalsPerDay}
                </div>
              </div>
              <Progress 
                value={(telegramStats?.sentToday || 0) / settings.maxSignalsPerDay * 100} 
                className="h-2" 
              />
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.3 }}
        >
          <Card className="border-l-4 border-l-purple-500">
            <CardHeader className="pb-2 sm:pb-3">
              <CardTitle className="text-sm sm:text-lg flex items-center gap-2">
                <Target className="h-4 w-4 sm:h-5 sm:w-5 text-purple-500" />
                <span className="truncate">{language === 'ar' ? 'معدل النجاح' : 'Success Rate'}</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="flex items-center justify-between">
                <span className="text-xl sm:text-2xl font-bold text-purple-600">
                  {systemStatus?.successRate?.toFixed(1) || '0.0'}%
                </span>
                <BarChart3 className="h-5 w-5 sm:h-6 sm:w-6 text-purple-500" />
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.4 }}
        >
          <Card className="border-l-4 border-l-orange-500">
            <CardHeader className="pb-2 sm:pb-3">
              <CardTitle className="text-sm sm:text-lg flex items-center gap-2">
                <Users className="h-4 w-4 sm:h-5 sm:w-5 text-orange-500" />
                <span className="truncate">{language === 'ar' ? 'المشتركون' : 'Subscribers'}</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="flex items-center justify-between">
                <span className="text-xl sm:text-2xl font-bold text-orange-600">
                  {telegramStats?.subscribers || 0}
                </span>
                <Globe className="h-5 w-5 sm:h-6 sm:w-6 text-orange-500" />
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Main Controls - Mobile Optimized Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4 sm:space-y-6">
        <TabsList className="grid w-full grid-cols-2 sm:grid-cols-4 h-auto">
          <TabsTrigger value="overview" className="flex items-center gap-1 sm:gap-2 p-2 sm:p-3 text-xs sm:text-sm">
            <Activity className="h-3 w-3 sm:h-4 sm:w-4" />
            <span className="hidden xs:inline">{language === 'ar' ? 'نظرة عامة' : 'Overview'}</span>
            <span className="xs:hidden">{language === 'ar' ? 'عام' : 'Main'}</span>
          </TabsTrigger>
          <TabsTrigger value="settings" className="flex items-center gap-1 sm:gap-2 p-2 sm:p-3 text-xs sm:text-sm">
            <Settings className="h-3 w-3 sm:h-4 sm:w-4" />
            <span className="hidden xs:inline">{language === 'ar' ? 'الإعدادات' : 'Settings'}</span>
            <span className="xs:hidden">{language === 'ar' ? 'إعدادات' : 'Config'}</span>
          </TabsTrigger>
          <TabsTrigger value="assets" className="flex items-center gap-1 sm:gap-2 p-2 sm:p-3 text-xs sm:text-sm">
            <DollarSign className="h-3 w-3 sm:h-4 sm:w-4" />
            <span className="hidden xs:inline">{language === 'ar' ? 'الأصول' : 'Assets'}</span>
            <span className="xs:hidden">{language === 'ar' ? 'أصول' : 'Assets'}</span>
          </TabsTrigger>
          <TabsTrigger value="advanced" className="flex items-center gap-1 sm:gap-2 p-2 sm:p-3 text-xs sm:text-sm">
            <Zap className="h-3 w-3 sm:h-4 sm:w-4" />
            <span className="hidden xs:inline">{language === 'ar' ? 'متقدم' : 'Advanced'}</span>
            <span className="xs:hidden">{language === 'ar' ? 'متقدم' : 'Pro'}</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4 sm:space-y-6">
          {/* Top Priority Section - Main Controls */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-6">
            {/* Main Control Panel - Enhanced */}
            <Card className="lg:col-span-2 bg-gradient-to-br from-blue-50 via-white to-emerald-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 border-2">
              <CardHeader className="pb-4">
                <CardTitle className="flex items-center gap-3 text-xl">
                  <div className="p-2 bg-gradient-to-r from-blue-500 to-emerald-500 rounded-lg">
                    <Bot className="h-6 w-6 text-white" />
                  </div>
                  {language === 'ar' ? 'مركز التحكم الرئيسي' : 'Main Control Center'}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Status & Toggle */}
                <div className="p-4 bg-white dark:bg-gray-800 rounded-lg border-l-4 border-blue-500 shadow-sm">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className={`w-4 h-4 rounded-full ${systemStatus?.isActive ? 'bg-green-500 animate-pulse shadow-lg shadow-green-500/50' : 'bg-red-500'}`} />
                      <div>
                        <Label htmlFor="auto-signals" className="text-lg font-semibold">
                          {language === 'ar' ? 'الإشارات التلقائية' : 'Auto Signals'}
                        </Label>
                        <p className="text-sm text-muted-foreground">
                          {systemStatus?.isActive 
                            ? (language === 'ar' ? 'يعمل الآن' : 'Currently Active') 
                            : (language === 'ar' ? 'متوقف' : 'Stopped')
                          }
                        </p>
                      </div>
                    </div>
                    <Switch
                      id="auto-signals"
                      checked={systemStatus?.isActive || false}
                      onCheckedChange={(checked) => toggleAutoSignalsMutation.mutate(checked)}
                      disabled={toggleAutoSignalsMutation.isPending}
                      className="scale-125"
                    />
                  </div>
                </div>

                {/* Quick Controls Grid */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-3">
                    <Label className="text-sm font-medium text-blue-600 dark:text-blue-400">
                      {language === 'ar' ? 'فترة الإشارات' : 'Signal Interval'}
                    </Label>
                    <div className="text-center p-3 bg-gradient-to-r from-blue-100 to-blue-50 dark:from-blue-900 dark:to-blue-800 rounded-lg">
                      <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                        {settings.signalInterval}
                      </div>
                      <div className="text-xs text-blue-500 dark:text-blue-300">
                        {language === 'ar' ? 'دقيقة' : 'minutes'}
                      </div>
                    </div>
                    <Slider
                      value={[settings.signalInterval]}
                      onValueChange={([value]) => handleSettingChange('signalInterval', value)}
                      min={1}
                      max={60}
                      step={1}
                      className="w-full"
                    />
                  </div>
                  
                  <div className="space-y-3">
                    <Label className="text-sm font-medium text-emerald-600 dark:text-emerald-400">
                      {language === 'ar' ? 'الحد الأقصى اليومي' : 'Daily Limit'}
                    </Label>
                    <div className="text-center p-3 bg-gradient-to-r from-emerald-100 to-emerald-50 dark:from-emerald-900 dark:to-emerald-800 rounded-lg">
                      <div className="text-2xl font-bold text-emerald-600 dark:text-emerald-400">
                        {settings.maxSignalsPerDay}
                      </div>
                      <div className="text-xs text-emerald-500 dark:text-emerald-300">
                        {language === 'ar' ? 'إشارة/يوم' : 'signals/day'}
                      </div>
                    </div>
                    <Slider
                      value={[settings.maxSignalsPerDay]}
                      onValueChange={([value]) => handleSettingChange('maxSignalsPerDay', value)}
                      min={10}
                      max={100}
                      step={5}
                      className="w-full"
                    />
                  </div>
                </div>

                {/* Generate Signal Button */}
                <Button
                  onClick={() => generateSignalMutation.mutate()}
                  disabled={generateSignalMutation.isPending}
                  className="w-full h-14 text-lg font-semibold bg-gradient-to-r from-blue-600 to-emerald-600 hover:from-blue-700 hover:to-emerald-700 text-white shadow-lg hover:shadow-xl transition-all duration-300"
                  size="lg"
                >
                  {generateSignalMutation.isPending ? (
                    <>
                      <Bot className="mr-3 h-5 w-5 animate-spin" />
                      {language === 'ar' ? 'جاري الإنشاء...' : 'Generating Signal...'}
                    </>
                  ) : (
                    <>
                      <Zap className="mr-3 h-5 w-5" />
                      {language === 'ar' ? 'إنشاء إشارة فورية' : 'Generate Instant Signal'}
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>

            {/* Primary Countdown Timer - Unified Control Center */}
            <Card className="bg-gradient-to-br from-emerald-50 via-blue-50 to-purple-50 dark:from-emerald-900 dark:via-blue-900 dark:to-purple-900 border-2 border-blue-200 dark:border-blue-700">
              <CardHeader className="text-center pb-4">
                <CardTitle className="flex items-center justify-center gap-2 text-xl">
                  <Clock className="h-6 w-6 text-blue-600" />
                  {language === 'ar' ? 'الوقت المتبقي للإشارة التالية' : 'Next Signal Countdown'}
                </CardTitle>
                <p className="text-sm text-muted-foreground mt-1">
                  {language === 'ar' ? 
                    `فاصل زمني: ${settings.signalInterval} دقيقة • حد يومي: ${settings.maxSignalsPerDay} إشارة` :
                    `Interval: ${settings.signalInterval} min • Daily limit: ${settings.maxSignalsPerDay} signals`
                  }
                </p>
              </CardHeader>
              <CardContent className="p-6">
                <CountdownTimer 
                  targetMinutes={settings.signalInterval}
                  isActive={settings.autoSignalsEnabled && (systemStatus?.isActive || false)}
                  className="p-0 bg-transparent border-0"
                />
                
                {/* System Status & Statistics */}
                <div className="mt-6 pt-4 border-t border-blue-200 dark:border-blue-700">
                  <div className="grid grid-cols-3 gap-3 text-center">
                    <div className="p-3 bg-emerald-100 dark:bg-emerald-900 rounded-lg">
                      <div className="text-xl font-bold text-emerald-600 dark:text-emerald-400">
                        {telegramStats?.sentToday || 0}
                      </div>
                      <div className="text-xs text-emerald-600 dark:text-emerald-500">
                        {language === 'ar' ? 'إشارات اليوم' : 'Today\'s Signals'}
                      </div>
                    </div>
                    <div className="p-3 bg-blue-100 dark:bg-blue-900 rounded-lg">
                      <div className="text-xl font-bold text-blue-600 dark:text-blue-400">
                        {systemStatus?.successRate || 0}%
                      </div>
                      <div className="text-xs text-blue-600 dark:text-blue-500">
                        {language === 'ar' ? 'معدل النجاح' : 'Success Rate'}
                      </div>
                    </div>
                    <div className="p-3 bg-purple-100 dark:bg-purple-900 rounded-lg">
                      <div className="text-xl font-bold text-purple-600 dark:text-purple-400">
                        {settings.enabledAssets.length}
                      </div>
                      <div className="text-xs text-purple-600 dark:text-purple-500">
                        {language === 'ar' ? 'الأصول النشطة' : 'Active Assets'}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Current Status Indicator */}
                <div className="mt-4 p-3 bg-gradient-to-r from-gray-50 to-gray-100 dark:from-gray-800 dark:to-gray-700 rounded-lg">
                  <div className="flex items-center justify-center gap-2">
                    <div className={`w-3 h-3 rounded-full ${
                      settings.autoSignalsEnabled ? 'bg-green-500 animate-pulse' : 'bg-red-500'
                    }`} />
                    <span className="text-sm font-medium">
                      {settings.autoSignalsEnabled ? 
                        (language === 'ar' ? '✅ النظام نشط ويعمل' : '✅ System Active & Running') :
                        (language === 'ar' ? '🔴 النظام متوقف' : '🔴 System Paused')
                      }
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Secondary Controls Section */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">

            {/* System Status & Monitoring */}
            <Card className="bg-gradient-to-br from-orange-50 via-white to-yellow-50 dark:from-orange-900 dark:via-gray-800 dark:to-yellow-900">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-orange-500" />
                  {language === 'ar' ? 'مراقبة النظام' : 'System Monitoring'}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div className="p-3 bg-white dark:bg-gray-800 rounded-lg text-center">
                    <div className="text-2xl font-bold text-green-600">
                      {systemStatus?.successRate || 0}%
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {language === 'ar' ? 'معدل النجاح' : 'Success Rate'}
                    </div>
                  </div>
                  <div className="p-3 bg-white dark:bg-gray-800 rounded-lg text-center">
                    <div className="text-2xl font-bold text-blue-600">
                      {telegramStats?.sentToday || 0}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {language === 'ar' ? 'إشارات اليوم' : 'Today Signals'}
                    </div>
                  </div>
                </div>
                
                <div className="p-3 bg-white dark:bg-gray-800 rounded-lg">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm font-medium">
                      {language === 'ar' ? 'التقدم اليومي' : 'Daily Progress'}
                    </span>
                    <span className="text-sm text-muted-foreground">
                      {telegramStats?.sentToday || 0}/{settings.maxSignalsPerDay}
                    </span>
                  </div>
                  <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                    <div 
                      className="bg-gradient-to-r from-green-500 to-emerald-500 h-2 rounded-full transition-all duration-300"
                      style={{ 
                        width: `${Math.min(100, ((telegramStats?.sentToday || 0) / settings.maxSignalsPerDay) * 100)}%` 
                      }}
                    />
                  </div>
                </div>

                <div className="text-center">
                  <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-sm ${
                    systemStatus?.isActive 
                      ? 'bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300' 
                      : 'bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300'
                  }`}>
                    <div className={`w-2 h-2 rounded-full ${systemStatus?.isActive ? 'bg-green-500' : 'bg-red-500'}`} />
                    {systemStatus?.isActive 
                      ? (language === 'ar' ? 'النظام يعمل' : 'System Active')
                      : (language === 'ar' ? 'النظام متوقف' : 'System Stopped')
                    }
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Trading Hours & Limitations */}
            <Card className="bg-gradient-to-br from-violet-50 via-white to-pink-50 dark:from-violet-900 dark:via-gray-800 dark:to-pink-900">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-violet-500" />
                  {language === 'ar' ? 'ساعات التداول والقيود' : 'Trading Hours & Limits'}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <Label className="text-sm font-medium">
                      {language === 'ar' ? 'الحد الأدنى للثقة' : 'Min Confidence'}
                    </Label>
                    <span className="text-sm font-bold text-violet-600">
                      {settings.minConfidence}%
                    </span>
                  </div>
                  <Slider
                    value={[settings.minConfidence]}
                    onValueChange={([value]) => handleSettingChange('minConfidence', value)}
                    min={50}
                    max={95}
                    step={5}
                    className="w-full"
                  />
                </div>

                <div className="space-y-3">
                  <Label className="text-sm font-medium">
                    {language === 'ar' ? 'مستوى المخاطر المسموح' : 'Max Risk Level'}
                  </Label>
                  <Select 
                    value={settings.maxRiskLevel} 
                    onValueChange={(value: 'low' | 'medium' | 'high') => handleSettingChange('maxRiskLevel', value)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 bg-green-500 rounded-full" />
                          {language === 'ar' ? 'منخفض' : 'Low Risk'}
                        </div>
                      </SelectItem>
                      <SelectItem value="medium">
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 bg-yellow-500 rounded-full" />
                          {language === 'ar' ? 'متوسط' : 'Medium Risk'}
                        </div>
                      </SelectItem>
                      <SelectItem value="high">
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 bg-red-500 rounded-full" />
                          {language === 'ar' ? 'عالي' : 'High Risk'}
                        </div>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="p-3 bg-gradient-to-r from-violet-100 to-pink-100 dark:from-violet-900 dark:to-pink-900 rounded-lg">
                  <div className="text-center">
                    <div className="text-lg font-bold text-violet-600 dark:text-violet-400">
                      {new Date().toLocaleTimeString('ar-EG', { 
                        hour: '2-digit', 
                        minute: '2-digit',
                        hour12: false 
                      })}
                    </div>
                    <div className="text-xs text-violet-500">
                      {language === 'ar' ? 'الوقت المحلي' : 'Local Time'}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Enhancement Features Section - Quick Access */}
          <div className="mt-8 p-6 bg-gradient-to-r from-indigo-50 via-purple-50 to-pink-50 dark:from-indigo-900 dark:via-purple-900 dark:to-pink-900 rounded-lg border-2 border-dashed border-indigo-200 dark:border-indigo-700">
            <div className="text-center mb-4">
              <h3 className="text-xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
                {language === 'ar' ? 'ميزات التحسين السريع' : 'Quick Enhancement Features'}
              </h3>
              <p className="text-sm text-muted-foreground mt-1">
                {language === 'ar' ? 'وصول سريع للميزات المتقدمة والتحسينات' : 'Quick access to advanced features and improvements'}
              </p>
            </div>
            
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <Button
                variant="outline"
                className="h-16 flex-col gap-1 bg-white dark:bg-gray-800 hover:bg-indigo-50 dark:hover:bg-indigo-900 border-indigo-200"
                onClick={() => window.location.href = '/social-trading'}
              >
                <Users className="h-5 w-5 text-indigo-600" />
                <span className="text-xs">
                  {language === 'ar' ? 'التداول الاجتماعي' : 'Social Trading'}
                </span>
              </Button>
              
              <Button
                variant="outline"
                className="h-16 flex-col gap-1 bg-white dark:bg-gray-800 hover:bg-purple-50 dark:hover:bg-purple-900 border-purple-200"
                onClick={() => window.location.href = '/voice-assistant'}
              >
                <Bot className="h-5 w-5 text-purple-600" />
                <span className="text-xs">
                  {language === 'ar' ? 'المساعد الصوتي' : 'Voice Assistant'}
                </span>
              </Button>
              
              <Button
                variant="outline"
                className="h-16 flex-col gap-1 bg-white dark:bg-gray-800 hover:bg-emerald-50 dark:hover:bg-emerald-900 border-emerald-200"
                onClick={() => window.location.href = '/advanced-charts'}
              >
                <BarChart3 className="h-5 w-5 text-emerald-600" />
                <span className="text-xs">
                  {language === 'ar' ? 'الرسوم البيانية' : 'Advanced Charts'}
                </span>
              </Button>
              
              <Button
                variant="outline"
                className="h-16 flex-col gap-1 bg-white dark:bg-gray-800 hover:bg-orange-50 dark:hover:bg-orange-900 border-orange-200"
                onClick={() => window.location.href = '/portfolio-manager'}
              >
                <Target className="h-5 w-5 text-orange-600" />
                <span className="text-xs">
                  {language === 'ar' ? 'إدارة المحفظة' : 'Portfolio'}
                </span>
              </Button>
            </div>
            
            <div className="mt-4 text-center">
              <Button
                variant="ghost"
                size="sm"
                className="text-indigo-600 hover:text-indigo-700 hover:bg-indigo-50 dark:hover:bg-indigo-900"
                onClick={() => window.location.href = '/improvement-suggestions'}
              >
                {language === 'ar' ? 'عرض جميع التحسينات المتاحة' : 'View All Available Improvements'}
                <ChevronDown className="ml-1 h-4 w-4" />
              </Button>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="settings" className="space-y-4 sm:space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
            {/* Trading Hours */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-blue-500" />
                  {language === 'ar' ? 'ساعات التداول' : 'Trading Hours'}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label>{language === 'ar' ? 'تفعيل حدود الوقت' : 'Enable Time Restrictions'}</Label>
                  <Switch
                    checked={settings.tradingHours.enabled}
                    onCheckedChange={(checked) => 
                      handleSettingChange('tradingHours', { ...settings.tradingHours, enabled: checked })
                    }
                  />
                </div>

                {/* Real-time Clock Display */}
                <RealTimeClock language={language} tradingHours={settings.tradingHours} />
                
                {settings.tradingHours.enabled && (
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>{language === 'ar' ? 'وقت البداية' : 'Start Time'}</Label>
                      <Input
                        type="time"
                        value={settings.tradingHours.start}
                        onChange={(e) => 
                          handleSettingChange('tradingHours', { 
                            ...settings.tradingHours, 
                            start: e.target.value 
                          })
                        }
                        className="font-mono"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>{language === 'ar' ? 'وقت النهاية' : 'End Time'}</Label>
                      <Input
                        type="time"
                        value={settings.tradingHours.end}
                        onChange={(e) => 
                          handleSettingChange('tradingHours', { 
                            ...settings.tradingHours, 
                            end: e.target.value 
                          })
                        }
                        className="font-mono"
                      />
                    </div>
                  </div>
                )}

                {/* Trading Hours Info */}
                {settings.tradingHours.enabled && (
                  <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                    <div className="text-sm text-gray-600 dark:text-gray-400">
                      <div className="font-medium mb-1">
                        {language === 'ar' ? 'ساعات التداول المحددة:' : 'Set Trading Hours:'}
                      </div>
                      <div className="font-mono">
                        {settings.tradingHours.start} - {settings.tradingHours.end}
                      </div>
                      <div className="text-xs mt-1 text-gray-500">
                        {language === 'ar' 
                          ? 'سيتم إيقاف الإشارات التلقائية خارج هذه الأوقات'
                          : 'Auto signals will be paused outside these hours'
                        }
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Risk Management */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="h-5 w-5 text-emerald-500" />
                  {language === 'ar' ? 'إدارة المخاطر' : 'Risk Management'}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label>{language === 'ar' ? 'تفعيل وقف الخسارة' : 'Enable Stop Loss'}</Label>
                  <Switch
                    checked={settings.stopLossEnabled}
                    onCheckedChange={(checked) => handleSettingChange('stopLossEnabled', checked)}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <Label>{language === 'ar' ? 'تفعيل جني الأرباح' : 'Enable Take Profit'}</Label>
                  <Switch
                    checked={settings.takeProfitEnabled}
                    onCheckedChange={(checked) => handleSettingChange('takeProfitEnabled', checked)}
                  />
                </div>

                <div className="p-3 rounded-lg border">
                  <div className="flex items-center gap-2 mb-2">
                    <AlertTriangle className="h-4 w-4 text-orange-500" />
                    <span className="text-sm font-medium">
                      {language === 'ar' ? 'مستوى المخاطر الحالي' : 'Current Risk Level'}
                    </span>
                  </div>
                  <Badge className={getRiskLevelColor(settings.maxRiskLevel)}>
                    {settings.maxRiskLevel === 'low' ? (language === 'ar' ? 'منخفض' : 'Low') :
                     settings.maxRiskLevel === 'medium' ? (language === 'ar' ? 'متوسط' : 'Medium') :
                     (language === 'ar' ? 'عالي' : 'High')}
                  </Badge>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="assets" className="space-y-4 sm:space-y-6">
          <Card>
            <CardHeader className="pb-3 sm:pb-6">
              <CardTitle className="flex items-center gap-2 text-lg">
                <DollarSign className="h-4 w-4 sm:h-5 sm:w-5 text-purple-500" />
                {language === 'ar' ? 'اختيار الأصول المالية' : 'Asset Selection'}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4 sm:space-y-6">
                {/* Forex */}
                <div>
                  <h3 className="text-base sm:text-lg font-semibold mb-2 sm:mb-3 flex items-center gap-2">
                    <Globe className="h-4 w-4 sm:h-5 sm:w-5" />
                    {language === 'ar' ? 'أزواج العملات' : 'Forex Pairs'}
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2 sm:gap-3">
                    {getAssetsByCategory('forex').map((asset) => (
                      <div key={asset.symbol} className="flex items-center space-x-2 p-2 sm:p-3 border rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">
                        <Checkbox
                          checked={settings.enabledAssets.includes(asset.symbol)}
                          onCheckedChange={(checked) => handleAssetToggle(asset.symbol, checked as boolean)}
                        />
                        <div className="flex-1 min-w-0">
                          <div className="font-medium text-sm sm:text-base truncate">{asset.symbol}</div>
                          <div className="text-xs text-gray-500 truncate">{asset.name}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Commodities */}
                <div>
                  <h3 className="text-base sm:text-lg font-semibold mb-2 sm:mb-3 flex items-center gap-2">
                    <BarChart3 className="h-4 w-4 sm:h-5 sm:w-5" />
                    {language === 'ar' ? 'السلع' : 'Commodities'}
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2 sm:gap-3">
                    {getAssetsByCategory('commodity').map((asset) => (
                      <div key={asset.symbol} className="flex items-center space-x-2 p-2 sm:p-3 border rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">
                        <Checkbox
                          checked={settings.enabledAssets.includes(asset.symbol)}
                          onCheckedChange={(checked) => handleAssetToggle(asset.symbol, checked as boolean)}
                        />
                        <div className="flex-1 min-w-0">
                          <div className="font-medium text-sm sm:text-base truncate">{asset.symbol}</div>
                          <div className="text-xs text-gray-500 truncate">{asset.name}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Cryptocurrencies */}
                <div>
                  <h3 className="text-base sm:text-lg font-semibold mb-2 sm:mb-3 flex items-center gap-2">
                    <Zap className="h-4 w-4 sm:h-5 sm:w-5" />
                    {language === 'ar' ? 'العملات الرقمية' : 'Cryptocurrencies'}
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2 sm:gap-3">
                    {getAssetsByCategory('crypto').map((asset) => (
                      <div key={asset.symbol} className="flex items-center space-x-2 p-2 sm:p-3 border rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">
                        <Checkbox
                          checked={settings.enabledAssets.includes(asset.symbol)}
                          onCheckedChange={(checked) => handleAssetToggle(asset.symbol, checked as boolean)}
                        />
                        <div className="flex-1 min-w-0">
                          <div className="font-medium text-sm sm:text-base truncate">{asset.symbol}</div>
                          <div className="text-xs text-gray-500 truncate">{asset.name}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="advanced" className="space-y-4 sm:space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
            {/* Advanced Settings */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Zap className="h-5 w-5 text-yellow-500" />
                  {language === 'ar' ? 'الإعدادات المتقدمة' : 'Advanced Settings'}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-4 border rounded-lg bg-yellow-50 dark:bg-yellow-900/20">
                  <div className="flex items-center gap-2 mb-2">
                    <AlertTriangle className="h-5 w-5 text-yellow-600" />
                    <span className="font-medium text-yellow-800 dark:text-yellow-200">
                      {language === 'ar' ? 'تحذير' : 'Warning'}
                    </span>
                  </div>
                  <p className="text-sm text-yellow-700 dark:text-yellow-300">
                    {language === 'ar' 
                      ? 'تعديل هذه الإعدادات قد يؤثر على أداء النظام. يُنصح بالحذر.'
                      : 'Modifying these settings may affect system performance. Use with caution.'
                    }
                  </p>
                </div>

                <div className="space-y-2">
                  <Label>{language === 'ar' ? 'عدد الأصول المفعلة' : 'Enabled Assets Count'}</Label>
                  <div className="text-2xl font-bold text-blue-600">
                    {settings.enabledAssets.length}
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>{language === 'ar' ? 'حالة الحفظ' : 'Save Status'}</Label>
                  <div className="flex items-center gap-2">
                    {hasUnsavedChanges ? (
                      <>
                        <XCircle className="h-5 w-5 text-orange-500" />
                        <span className="text-orange-600">
                          {language === 'ar' ? 'يوجد تغييرات غير محفوظة' : 'Unsaved changes'}
                        </span>
                      </>
                    ) : (
                      <>
                        <CheckCircle className="h-5 w-5 text-green-500" />
                        <span className="text-green-600">
                          {language === 'ar' ? 'جميع التغييرات محفوظة' : 'All changes saved'}
                        </span>
                      </>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Actions */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="h-5 w-5 text-blue-500" />
                  {language === 'ar' ? 'إجراءات' : 'Actions'}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button
                  onClick={() => saveSettingsMutation.mutate(settings)}
                  disabled={!hasUnsavedChanges || saveSettingsMutation.isPending}
                  className="w-full h-10 sm:h-12 text-sm sm:text-base"
                  variant="default"
                >
                  <Save className="mr-2 h-3 w-3 sm:h-4 sm:w-4" />
                  {saveSettingsMutation.isPending 
                    ? (language === 'ar' ? 'جاري الحفظ...' : 'Saving...')
                    : (language === 'ar' ? 'حفظ الإعدادات' : 'Save Settings')
                  }
                </Button>

                <Button
                  onClick={handleResetSettings}
                  variant="outline"
                  className="w-full h-10 sm:h-12 text-sm sm:text-base"
                >
                  <RotateCcw className="mr-2 h-3 w-3 sm:h-4 sm:w-4" />
                  {language === 'ar' ? 'إعادة تعيين' : 'Reset to Defaults'}
                </Button>

                <Separator />

                <div className="text-sm text-gray-500 space-y-1">
                  <div>
                    {language === 'ar' ? 'آخر حفظ:' : 'Last saved:'} {' '}
                    {new Date().toLocaleString(language === 'ar' ? 'ar' : 'en')}
                  </div>
                  <div>
                    {language === 'ar' ? 'الإصدار:' : 'Version:'} v2.1.0
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}