import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { DateSettings } from '@/components/date-settings';
import { FloatingRefreshButton } from '@/components/floating-refresh-button';
import { useLanguageContext } from '@/components/language-provider';
import { 
  Settings as SettingsIcon, 
  Calendar, 
  Globe, 
  Bell, 
  Shield,
  Palette,
  Clock
} from 'lucide-react';

export default function Settings() {
  const { language } = useLanguageContext();

  const handleRefresh = async () => {
    // Refresh settings or reload from localStorage
    window.location.reload();
  };

  return (
    <div className="container mx-auto px-4 py-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100">
            {language === 'ar' ? 'الإعدادات' : 'Settings'}
          </h1>
          <p className="text-muted-foreground mt-1">
            {language === 'ar' 
              ? 'إدارة إعدادات التطبيق والتفضيلات الشخصية'
              : 'Manage your application preferences and personal settings'
            }
          </p>
        </div>
        <Badge variant="outline" className="px-3 py-1">
          <SettingsIcon className="h-4 w-4 mr-2" />
          {language === 'ar' ? 'تكوين' : 'Configuration'}
        </Badge>
      </div>

      <Separator />

      {/* Settings Sections */}
      <div className="grid gap-6 md:grid-cols-1 lg:grid-cols-2">
        {/* Date & Time Settings */}
        <DateSettings />

        {/* Language & Localization */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Globe className="h-5 w-5" />
              {language === 'ar' ? 'اللغة والتوطين' : 'Language & Localization'}
            </CardTitle>
            <CardDescription>
              {language === 'ar'
                ? 'إعدادات اللغة وخيارات العرض الإقليمية'
                : 'Language preferences and regional display options'
              }
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
              <div>
                <div className="font-medium">
                  {language === 'ar' ? 'اللغة الحالية' : 'Current Language'}
                </div>
                <div className="text-sm text-muted-foreground">
                  {language === 'ar' ? 'العربية' : 'English'}
                </div>
              </div>
              <Badge variant="secondary">
                {language === 'ar' ? 'نشط' : 'Active'}
              </Badge>
            </div>
            <div className="text-sm text-muted-foreground">
              {language === 'ar'
                ? 'يمكن تغيير اللغة من الشريط الجانبي'
                : 'Language can be changed from the sidebar'
              }
            </div>
          </CardContent>
        </Card>

        {/* Notification Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Bell className="h-5 w-5" />
              {language === 'ar' ? 'إعدادات الإشعارات' : 'Notification Settings'}
            </CardTitle>
            <CardDescription>
              {language === 'ar'
                ? 'تحكم في إشعارات التطبيق والتنبيهات'
                : 'Control application notifications and alerts'
              }
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-medium">
                    {language === 'ar' ? 'تنبيهات التوصيات' : 'Trading Alerts'}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {language === 'ar' ? 'إشعارات التوصيات الجديدة' : 'New trading recommendation notifications'}
                  </div>
                </div>
                <Badge variant="default" className="bg-emerald-500">
                  {language === 'ar' ? 'مفعل' : 'Enabled'}
                </Badge>
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-medium">
                    {language === 'ar' ? 'تحديثات السوق' : 'Market Updates'}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {language === 'ar' ? 'تحديثات حالة السوق' : 'Market status updates'}
                  </div>
                </div>
                <Badge variant="default" className="bg-emerald-500">
                  {language === 'ar' ? 'مفعل' : 'Enabled'}
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Theme Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Palette className="h-5 w-5" />
              {language === 'ar' ? 'المظهر والثيم' : 'Appearance & Theme'}
            </CardTitle>
            <CardDescription>
              {language === 'ar'
                ? 'تخصيص مظهر التطبيق والألوان'
                : 'Customize application appearance and colors'
              }
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div className="p-3 border rounded-lg text-center">
                <div className="w-8 h-8 bg-gradient-to-br from-emerald-400 to-teal-600 rounded-full mx-auto mb-2"></div>
                <div className="text-sm font-medium">
                  {language === 'ar' ? 'الزمردي' : 'Emerald'}
                </div>
                <div className="text-xs text-muted-foreground">
                  {language === 'ar' ? 'الحالي' : 'Current'}
                </div>
              </div>
              <div className="p-3 border rounded-lg text-center opacity-50">
                <div className="w-8 h-8 bg-gradient-to-br from-blue-400 to-purple-600 rounded-full mx-auto mb-2"></div>
                <div className="text-sm font-medium">
                  {language === 'ar' ? 'الأزرق' : 'Blue'}
                </div>
                <div className="text-xs text-muted-foreground">
                  {language === 'ar' ? 'قريباً' : 'Soon'}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Trading Signal Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5" />
              {language === 'ar' ? 'إعدادات الإشارات التلقائية' : 'Auto Signals Settings'}
            </CardTitle>
            <CardDescription>
              {language === 'ar'
                ? 'تكوين المدة الزمنية والإعدادات للإشارات التلقائية'
                : 'Configure timing and settings for automatic signals'
              }
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
              <div>
                <div className="font-medium">
                  {language === 'ar' ? 'التحكم المتقدم' : 'Advanced Control'}
                </div>
                <div className="text-sm text-muted-foreground">
                  {language === 'ar' ? 'للتحكم الكامل في الإشارات' : 'For full signal control'}
                </div>
              </div>
              <Badge variant="outline">
                {language === 'ar' ? 'صفحة التحكم' : 'Control Page'}
              </Badge>
            </div>
            <div className="text-sm text-muted-foreground">
              {language === 'ar'
                ? 'يمكن ضبط المدة الزمنية وتشغيل/إيقاف الإشارات من صفحة "التحكم في التداول"'
                : 'Signal intervals and start/stop controls are available in the "Trading Control" page'
              }
            </div>
          </CardContent>
        </Card>

        {/* Security Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5" />
              {language === 'ar' ? 'الأمان والخصوصية' : 'Security & Privacy'}
            </CardTitle>
            <CardDescription>
              {language === 'ar'
                ? 'إعدادات الأمان وحماية البيانات'
                : 'Security settings and data protection'
              }
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-medium">
                    {language === 'ar' ? 'تشفير البيانات' : 'Data Encryption'}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {language === 'ar' ? 'حماية البيانات بالتشفير' : 'Protect data with encryption'}
                  </div>
                </div>
                <Badge variant="default" className="bg-green-500">
                  {language === 'ar' ? 'مفعل' : 'Active'}
                </Badge>
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-medium">
                    {language === 'ar' ? 'المصادقة الآمنة' : 'Secure Authentication'}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {language === 'ar' ? 'حماية الوصول للحساب' : 'Secure account access'}
                  </div>
                </div>
                <Badge variant="default" className="bg-green-500">
                  {language === 'ar' ? 'مفعل' : 'Active'}
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* System Information */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5" />
              {language === 'ar' ? 'معلومات النظام' : 'System Information'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="text-center p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                <div className="font-semibold text-lg text-emerald-600">
                  v2.1.0
                </div>
                <div className="text-sm text-muted-foreground">
                  {language === 'ar' ? 'إصدار التطبيق' : 'App Version'}
                </div>
              </div>
              <div className="text-center p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                <div className="font-semibold text-lg text-teal-600">
                  PWA
                </div>
                <div className="text-sm text-muted-foreground">
                  {language === 'ar' ? 'نوع التطبيق' : 'App Type'}
                </div>
              </div>
              <div className="text-center p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                <div className="font-semibold text-lg text-cyan-600">
                  {new Date().getFullYear()}
                </div>
                <div className="text-sm text-muted-foreground">
                  {language === 'ar' ? 'السنة' : 'Year'}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Floating Refresh Button */}
      <FloatingRefreshButton onRefresh={handleRefresh} />
    </div>
  );
}