import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useLanguageContext } from '@/components/language-provider';
import { 
  TrendingUp, 
  AlertTriangle, 
  CheckCircle, 
  Clock, 
  Users, 
  Bot, 
  Zap, 
  Shield, 
  Database, 
  Smartphone,
  Globe,
  BarChart3,
  Settings,
  Brain,
  Star,
  Target,
  Lightbulb,
  Rocket,
  Timer,
  DollarSign,
  Activity
} from 'lucide-react';

interface Suggestion {
  id: string;
  category: string;
  priority: 'high' | 'medium' | 'low';
  impact: 'high' | 'medium' | 'low';
  difficulty: 'easy' | 'medium' | 'hard';
  timeEstimate: string;
  title: string;
  titleAr: string;
  description: string;
  descriptionAr: string;
  benefits: string[];
  benefitsAr: string[];
  implementation: string[];
  implementationAr: string[];
  icon: any;
  status: 'suggested' | 'planned' | 'in-progress' | 'completed';
}

export default function ImprovementSuggestions() {
  const context = useLanguageContext();
  const language = context?.language || 'ar';
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const suggestions: Suggestion[] = [
    {
      id: 'signal-accuracy',
      category: 'AI Performance',
      priority: 'high',
      impact: 'high',
      difficulty: 'medium',
      timeEstimate: '2-3 weeks',
      title: 'Enhanced Signal Accuracy Algorithm',
      titleAr: 'خوارزمية محسنة لدقة الإشارات',
      description: 'Implement advanced machine learning models with ensemble methods to improve signal accuracy from current 74% to 85%+',
      descriptionAr: 'تطبيق نماذج تعلم آلي متقدمة مع طرق جماعية لتحسين دقة الإشارات من 74% الحالية إلى 85%+',
      benefits: [
        'Higher profitable trades',
        'Improved user confidence',
        'Better risk management',
        'Competitive advantage'
      ],
      benefitsAr: [
        'صفقات أكثر ربحية',
        'تحسين ثقة المستخدم',
        'إدارة أفضل للمخاطر',
        'ميزة تنافسية'
      ],
      implementation: [
        'Implement XGBoost and Random Forest models',
        'Add sentiment analysis from financial news',
        'Include macroeconomic indicators',
        'Implement real-time model validation'
      ],
      implementationAr: [
        'تطبيق نماذج XGBoost و Random Forest',
        'إضافة تحليل المشاعر من الأخبار المالية',
        'تضمين المؤشرات الاقتصادية الكلية',
        'تطبيق التحقق من النموذج في الوقت الفعلي'
      ],
      icon: Brain,
      status: 'completed'
    },
    {
      id: 'real-time-data',
      category: 'Data Management',
      priority: 'high',
      impact: 'high',
      difficulty: 'hard',
      timeEstimate: '4-5 weeks',
      title: 'Real-time Market Data Integration',
      titleAr: 'تكامل بيانات السوق في الوقت الفعلي',
      description: 'Integrate multiple premium data providers for millisecond-level market data updates',
      descriptionAr: 'دمج عدة مزودي بيانات متميزين للحصول على تحديثات بيانات السوق بمستوى المللي ثانية',
      benefits: [
        'Ultra-fast signal generation',
        'Competitive market entry',
        'Reduced latency',
        'Higher accuracy'
      ],
      benefitsAr: [
        'توليد إشارات فائق السرعة',
        'دخول تنافسي للسوق',
        'تقليل زمن الاستجابة',
        'دقة أعلى'
      ],
      implementation: [
        'Integrate Bloomberg API',
        'Add Reuters data feed',
        'Implement WebSocket connections',
        'Build data caching layer'
      ],
      implementationAr: [
        'دمج واجهة برمجة تطبيقات Bloomberg',
        'إضافة تغذية بيانات Reuters',
        'تطبيق اتصالات WebSocket',
        'بناء طبقة تخزين مؤقت للبيانات'
      ],
      icon: Zap,
      status: 'completed'
    },
    {
      id: 'mobile-app',
      category: 'User Experience',
      priority: 'high',
      impact: 'high',
      difficulty: 'hard',
      timeEstimate: '6-8 weeks',
      title: 'Native Mobile Applications',
      titleAr: 'تطبيقات الهاتف المحمول الأصلية',
      description: 'Develop native iOS and Android apps with push notifications and offline capabilities',
      descriptionAr: 'تطوير تطبيقات iOS و Android أصلية مع إشعارات فورية وإمكانيات عدم الاتصال',
      benefits: [
        'Better user experience',
        'Instant notifications',
        'Offline access',
        'Wider user reach'
      ],
      benefitsAr: [
        'تجربة مستخدم أفضل',
        'إشعارات فورية',
        'وصول بدون اتصال',
        'وصول أوسع للمستخدمين'
      ],
      implementation: [
        'React Native development',
        'Push notification service',
        'Offline data storage',
        'App store deployment'
      ],
      implementationAr: [
        'تطوير React Native',
        'خدمة الإشعارات الفورية',
        'تخزين البيانات بدون اتصال',
        'نشر في متجر التطبيقات'
      ],
      icon: Smartphone,
      status: 'completed'
    },
    {
      id: 'advanced-charts',
      category: 'Analytics',
      priority: 'medium',
      impact: 'high',
      difficulty: 'medium',
      timeEstimate: '3-4 weeks',
      title: 'Advanced Charting & Technical Analysis',
      titleAr: 'رسوم بيانية متقدمة وتحليل فني',
      description: 'Implement professional-grade charting with 50+ technical indicators and drawing tools',
      descriptionAr: 'تطبيق رسوم بيانية احترافية مع أكثر من 50 مؤشراً فنياً وأدوات رسم',
      benefits: [
        'Professional analysis tools',
        'Better trading decisions',
        'Enhanced user engagement',
        'Competitive features'
      ],
      benefitsAr: [
        'أدوات تحليل احترافية',
        'قرارات تداول أفضل',
        'تفاعل محسن للمستخدم',
        'ميزات تنافسية'
      ],
      implementation: [
        'TradingView integration',
        'Custom indicator builder',
        'Drawing tools suite',
        'Multi-timeframe analysis'
      ],
      implementationAr: [
        'تكامل TradingView',
        'باني مؤشرات مخصص',
        'مجموعة أدوات الرسم',
        'تحليل متعدد الإطارات الزمنية'
      ],
      icon: BarChart3,
      status: 'completed'
    },
    {
      id: 'portfolio-management',
      category: 'Portfolio',
      priority: 'high',
      impact: 'high',
      difficulty: 'medium',
      timeEstimate: '3-4 weeks',
      title: 'Comprehensive Portfolio Management',
      titleAr: 'إدارة محفظة شاملة',
      description: 'Advanced portfolio tracking with risk metrics, P&L analysis, and automated rebalancing',
      descriptionAr: 'تتبع محفظة متقدم مع مقاييس المخاطر وتحليل الربح والخسارة وإعادة التوازن التلقائي',
      benefits: [
        'Risk management',
        'Performance tracking',
        'Automated optimization',
        'Professional reporting'
      ],
      benefitsAr: [
        'إدارة المخاطر',
        'تتبع الأداء',
        'تحسين تلقائي',
        'تقارير احترافية'
      ],
      implementation: [
        'Portfolio analytics engine',
        'Risk calculation models',
        'Rebalancing algorithms',
        'Performance reports'
      ],
      implementationAr: [
        'محرك تحليلات المحفظة',
        'نماذج حساب المخاطر',
        'خوارزميات إعادة التوازن',
        'تقارير الأداء'
      ],
      icon: Shield,
      status: 'completed'
    },
    {
      id: 'social-features',
      category: 'Social',
      priority: 'medium',
      impact: 'medium',
      difficulty: 'medium',
      timeEstimate: '4-5 weeks',
      title: 'Social Trading Platform',
      titleAr: 'منصة التداول الاجتماعي',
      description: 'Enable users to follow top traders, copy trades, and share strategies',
      descriptionAr: 'تمكين المستخدمين من متابعة أفضل المتداولين ونسخ الصفقات ومشاركة الاستراتيجيات',
      benefits: [
        'Community building',
        'Learning opportunities',
        'Increased engagement',
        'Revenue sharing'
      ],
      benefitsAr: [
        'بناء المجتمع',
        'فرص التعلم',
        'زيادة التفاعل',
        'مشاركة الإيرادات'
      ],
      implementation: [
        'User ranking system',
        'Copy trading engine',
        'Social feed features',
        'Performance leaderboards'
      ],
      implementationAr: [
        'نظام تصنيف المستخدمين',
        'محرك نسخ التداول',
        'ميزات التغذية الاجتماعية',
        'لوحات المتصدرين'
      ],
      icon: Users,
      status: 'completed'
    },
    {
      id: 'ai-assistant',
      category: 'AI Features',
      priority: 'medium',
      impact: 'high',
      difficulty: 'hard',
      timeEstimate: '5-6 weeks',
      title: 'AI Trading Assistant',
      titleAr: 'مساعد التداول بالذكاء الاصطناعي',
      description: 'Conversational AI assistant for trading advice, market analysis, and education',
      descriptionAr: 'مساعد ذكي اصطناعي محادثي لنصائح التداول وتحليل السوق والتعليم',
      benefits: [
        '24/7 support',
        'Personalized advice',
        'Educational content',
        'User engagement'
      ],
      benefitsAr: [
        'دعم 24/7',
        'نصائح شخصية',
        'محتوى تعليمي',
        'تفاعل المستخدم'
      ],
      implementation: [
        'OpenAI GPT integration',
        'Market data context',
        'Voice interface',
        'Multilingual support'
      ],
      implementationAr: [
        'تكامل OpenAI GPT',
        'سياق بيانات السوق',
        'واجهة صوتية',
        'دعم متعدد اللغات'
      ],
      icon: Bot,
      status: 'completed'
    },
    {
      id: 'performance-optimization',
      category: 'Performance',
      priority: 'high',
      impact: 'medium',
      difficulty: 'easy',
      timeEstimate: '1-2 weeks',
      title: 'Performance Optimization',
      titleAr: 'تحسين الأداء',
      description: 'Optimize loading times, reduce memory usage, and improve overall system performance',
      descriptionAr: 'تحسين أوقات التحميل وتقليل استخدام الذاكرة وتحسين الأداء العام للنظام',
      benefits: [
        'Faster loading',
        'Better user experience',
        'Reduced server costs',
        'Higher retention'
      ],
      benefitsAr: [
        'تحميل أسرع',
        'تجربة مستخدم أفضل',
        'تكاليف خادم أقل',
        'احتفاظ أعلى'
      ],
      implementation: [
        'Code splitting',
        'Image optimization',
        'Caching strategies',
        'Database indexing'
      ],
      implementationAr: [
        'تقسيم الكود',
        'تحسين الصور',
        'استراتيجيات التخزين المؤقت',
        'فهرسة قاعدة البيانات'
      ],
      icon: Activity,
      status: 'completed'
    }
  ];

  const categories = ['all', 'AI Performance', 'Data Management', 'User Experience', 'Analytics', 'Portfolio', 'Social', 'AI Features', 'Performance'];
  
  const filteredSuggestions = selectedCategory === 'all' 
    ? suggestions 
    : suggestions.filter(s => s.category === selectedCategory);

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-100';
      case 'medium': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-100';
      case 'low': return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-100';
    }
  };

  const getImpactColor = (impact: string) => {
    switch (impact) {
      case 'high': return 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-100';
      case 'medium': return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100';
      case 'low': return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-100';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-100';
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'easy': return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100';
      case 'medium': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-100';
      case 'hard': return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-100';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-100';
    }
  };

  return (
    <div className="container mx-auto p-6 space-y-6" dir={language === 'ar' ? 'rtl' : 'ltr'}>
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="flex items-center justify-center gap-3">
          <Lightbulb className="h-8 w-8 text-primary" />
          <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            {language === 'ar' ? 'مقترحات التحسين' : 'Improvement Suggestions'}
          </h1>
        </div>
        <p className="text-lg text-muted-foreground max-w-3xl mx-auto leading-relaxed">
          {language === 'ar' 
            ? 'خطة شاملة لتطوير المنصة وتحسين الأداء بناءً على التحليل الحالي واحتياجات المستخدمين'
            : 'Comprehensive platform development plan and performance improvements based on current analysis and user needs'
          }
        </p>
      </div>

      {/* Completed Phases Banner */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <Card className="border-green-200 bg-green-50 dark:bg-green-950/20">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-green-500 rounded-full">
                <CheckCircle className="h-5 w-5 text-white" />
              </div>
              <div>
                <h3 className="font-bold text-green-800 dark:text-green-200">
                  {language === 'ar' ? 'المرحلة الأولى مكتملة ✓' : 'Phase 1 Completed ✓'}
                </h3>
                <p className="text-sm text-green-700 dark:text-green-300">
                  {language === 'ar' ? 'تحسين دقة الإشارات وتحسين الأداء' : 'Enhanced Signal Accuracy & Performance Optimization'}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="border-blue-200 bg-blue-50 dark:bg-blue-950/20">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-500 rounded-full">
                <CheckCircle className="h-5 w-5 text-white" />
              </div>
              <div>
                <h3 className="font-bold text-blue-800 dark:text-blue-200">
                  {language === 'ar' ? 'المرحلة الثانية مكتملة ✓' : 'Phase 2 Completed ✓'}
                </h3>
                <p className="text-sm text-blue-700 dark:text-blue-300">
                  {language === 'ar' ? 'ميزات اجتماعية متقدمة وتكامل الذكاء الاصطناعي' : 'Advanced Social Features & AI Integration'}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="border-purple-200 bg-purple-50 dark:bg-purple-950/20">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-purple-500 rounded-full">
                <CheckCircle className="h-5 w-5 text-white" />
              </div>
              <div>
                <h3 className="font-bold text-purple-800 dark:text-purple-200">
                  {language === 'ar' ? 'المرحلة الثالثة مكتملة ✓' : 'Phase 3 Completed ✓'}
                </h3>
                <p className="text-sm text-purple-700 dark:text-purple-300">
                  {language === 'ar' ? 'رسوم بيانية متقدمة وإدارة محفظة شاملة' : 'Advanced Charts & Comprehensive Portfolio'}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-green-600">{suggestions.filter(s => s.status === 'completed').length}</div>
            <div className="text-sm text-muted-foreground">
              {language === 'ar' ? 'مكتمل' : 'Completed'}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-yellow-600">{suggestions.filter(s => s.status === 'in-progress').length}</div>
            <div className="text-sm text-muted-foreground">
              {language === 'ar' ? 'قيد التنفيذ' : 'In Progress'}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-blue-600">{suggestions.filter(s => s.status === 'suggested').length}</div>
            <div className="text-sm text-muted-foreground">
              {language === 'ar' ? 'مقترح' : 'Suggested'}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-purple-600">{Math.round((suggestions.filter(s => s.status === 'completed').length / suggestions.length) * 100)}%</div>
            <div className="text-sm text-muted-foreground">
              {language === 'ar' ? 'نسبة الإنجاز' : 'Completion Rate'}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Category Filter */}
      <div className="flex flex-wrap gap-2 justify-center">
        {categories.map(category => (
          <Button
            key={category}
            variant={selectedCategory === category ? 'default' : 'outline'}
            size="sm"
            onClick={() => setSelectedCategory(category)}
            className="mb-2"
          >
            {category === 'all' ? (language === 'ar' ? 'الكل' : 'All') : category}
          </Button>
        ))}
      </div>

      {/* Suggestions Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredSuggestions.map((suggestion) => {
          const IconComponent = suggestion.icon;
          return (
            <Card key={suggestion.id} className={`relative overflow-hidden hover:shadow-lg transition-shadow ${
              suggestion.status === 'completed' ? 'border-green-200 bg-green-50/30 dark:bg-green-950/10' : ''
            }`}>
              {/* Status Badge */}
              {suggestion.status === 'completed' && (
                <div className="absolute top-3 right-3 z-10">
                  <div className="flex items-center gap-1 px-2 py-1 bg-green-500 text-white text-xs font-medium rounded-full">
                    <CheckCircle className="h-3 w-3" />
                    {language === 'ar' ? 'مكتمل' : 'Completed'}
                  </div>
                </div>
              )}
              <CardHeader className="pb-4">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex items-start gap-3 flex-1 min-w-0">
                    <div className={`p-3 rounded-lg ${suggestion.status === 'completed' 
                      ? 'bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-950 dark:to-emerald-950' 
                      : 'bg-gradient-to-br from-blue-50 to-purple-50 dark:from-blue-950 dark:to-purple-950'
                    }`}>
                      <IconComponent className={`h-6 w-6 ${suggestion.status === 'completed' ? 'text-green-600' : 'text-primary'}`} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <CardTitle className="text-lg leading-relaxed break-words mb-2">
                        {language === 'ar' ? suggestion.titleAr : suggestion.title}
                      </CardTitle>
                      <CardDescription className="text-sm leading-relaxed">
                        {language === 'ar' ? suggestion.descriptionAr : suggestion.description}
                      </CardDescription>
                    </div>
                  </div>
                </div>

                {/* Badges */}
                <div className="flex flex-wrap gap-2 mt-3">
                  <Badge className={getPriorityColor(suggestion.priority)}>
                    {language === 'ar' ? 
                      (suggestion.priority === 'high' ? 'عالية' : suggestion.priority === 'medium' ? 'متوسطة' : 'منخفضة') :
                      suggestion.priority
                    }
                  </Badge>
                  <Badge className={getImpactColor(suggestion.impact)}>
                    {language === 'ar' ? 'تأثير' : 'Impact'}: {language === 'ar' ?
                      (suggestion.impact === 'high' ? 'عالي' : suggestion.impact === 'medium' ? 'متوسط' : 'منخفض') :
                      suggestion.impact
                    }
                  </Badge>
                  <Badge className={getDifficultyColor(suggestion.difficulty)}>
                    {language === 'ar' ?
                      (suggestion.difficulty === 'easy' ? 'سهل' : suggestion.difficulty === 'medium' ? 'متوسط' : 'صعب') :
                      suggestion.difficulty
                    }
                  </Badge>
                  <Badge variant="outline" className="flex items-center gap-1">
                    <Timer className="h-3 w-3" />
                    {suggestion.timeEstimate}
                  </Badge>
                </div>
              </CardHeader>

              <CardContent className="pt-0">
                <Tabs defaultValue="benefits" className="w-full">
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="benefits">
                      {language === 'ar' ? 'الفوائد' : 'Benefits'}
                    </TabsTrigger>
                    <TabsTrigger value="implementation">
                      {language === 'ar' ? 'التنفيذ' : 'Implementation'}
                    </TabsTrigger>
                  </TabsList>

                  <TabsContent value="benefits" className="mt-4">
                    <ul className="space-y-2">
                      {(language === 'ar' ? suggestion.benefitsAr : suggestion.benefits).map((benefit, index) => (
                        <li key={index} className="flex items-start gap-2 text-sm leading-relaxed">
                          <CheckCircle className="h-4 w-4 text-green-600 flex-shrink-0 mt-0.5" />
                          <span className="break-words">{benefit}</span>
                        </li>
                      ))}
                    </ul>
                  </TabsContent>

                  <TabsContent value="implementation" className="mt-4">
                    <ul className="space-y-2">
                      {(language === 'ar' ? suggestion.implementationAr : suggestion.implementation).map((step, index) => (
                        <li key={index} className="flex items-start gap-2 text-sm leading-relaxed">
                          <Target className="h-4 w-4 text-blue-600 flex-shrink-0 mt-0.5" />
                          <span className="break-words">{step}</span>
                        </li>
                      ))}
                    </ul>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Implementation Roadmap */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Rocket className="h-5 w-5" />
            {language === 'ar' ? 'خريطة طريق التنفيذ' : 'Implementation Roadmap'}
          </CardTitle>
          <CardDescription>
            {language === 'ar' 
              ? 'ترتيب مقترح للتنفيذ بناءً على الأولوية والتأثير'
              : 'Suggested implementation order based on priority and impact'
            }
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="p-4 bg-red-50 dark:bg-red-950/20 border border-red-200 dark:border-red-800 rounded-lg">
              <h4 className="font-semibold text-red-900 dark:text-red-100 mb-2">
                {language === 'ar' ? 'المرحلة الأولى (الأولوية العالية)' : 'Phase 1 (High Priority)'}
              </h4>
              <ul className="text-sm text-red-700 dark:text-red-300 space-y-1">
                {suggestions.filter(s => s.priority === 'high').map(s => (
                  <li key={s.id}>• {language === 'ar' ? s.titleAr : s.title}</li>
                ))}
              </ul>
            </div>

            <div className="p-4 bg-yellow-50 dark:bg-yellow-950/20 border border-yellow-200 dark:border-yellow-800 rounded-lg">
              <h4 className="font-semibold text-yellow-900 dark:text-yellow-100 mb-2">
                {language === 'ar' ? 'المرحلة الثانية (الأولوية المتوسطة)' : 'Phase 2 (Medium Priority)'}
              </h4>
              <ul className="text-sm text-yellow-700 dark:text-yellow-300 space-y-1">
                {suggestions.filter(s => s.priority === 'medium').map(s => (
                  <li key={s.id}>• {language === 'ar' ? s.titleAr : s.title}</li>
                ))}
              </ul>
            </div>

            <div className="p-4 bg-green-50 dark:bg-green-950/20 border border-green-200 dark:border-green-800 rounded-lg">
              <h4 className="font-semibold text-green-900 dark:text-green-100 mb-2">
                {language === 'ar' ? 'المرحلة الثالثة (الأولوية المنخفضة)' : 'Phase 3 (Low Priority)'}
              </h4>
              <ul className="text-sm text-green-700 dark:text-green-300 space-y-1">
                {suggestions.filter(s => s.priority === 'low').map(s => (
                  <li key={s.id}>• {language === 'ar' ? s.titleAr : s.title}</li>
                ))}
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}