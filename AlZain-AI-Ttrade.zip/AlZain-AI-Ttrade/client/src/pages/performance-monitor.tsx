import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useLanguageContext } from '@/components/language-provider';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { FloatingRefreshButton } from '@/components/floating-refresh-button';
import { 
  Activity, 
  Cpu, 
  Database, 
  Timer, 
  Zap, 
  BarChart3,
  RefreshCw,
  CheckCircle,
  AlertTriangle,
  Gauge,
  HardDrive,
  Server,
  Layers,
  Clock,
  Target
} from 'lucide-react';

interface PerformanceMetrics {
  performance: {
    apiResponseTimes: Record<string, number[]>;
    cacheHitRates: Record<string, { hits: number; misses: number }>;
    memoryUsage: {
      rss: number;
      heapUsed: number;
      heapTotal: number;
      external: number;
    };
    activeConnections: number;
    requestCount: number;
    errorCount: number;
    lastUpdated: string;
  };
  cache: Record<string, {
    size: number;
    maxSize: number;
    hitRate: string;
    hits: number;
    misses: number;
  }>;
  timestamp: string;
}

export default function PerformanceMonitor() {
  const { language } = useLanguageContext();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: metrics, isLoading } = useQuery<PerformanceMetrics>({
    queryKey: ['/api/performance/metrics'],
    refetchInterval: 5000, // Refresh every 5 seconds
  });

  const optimizeMemoryMutation = useMutation({
    mutationFn: () => apiRequest('POST', '/api/performance/optimize'),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/performance/metrics'] });
      toast({
        title: language === 'ar' ? 'تم التحسين' : 'Optimized',
        description: language === 'ar' ? 'تم تحسين الذاكرة بنجاح' : 'Memory optimization completed successfully',
      });
    },
    onError: () => {
      toast({
        title: language === 'ar' ? 'خطأ' : 'Error',
        description: language === 'ar' ? 'فشل في تحسين الأداء' : 'Failed to optimize performance',
        variant: 'destructive',
      });
    },
  });

  const formatBytes = (bytes: number): string => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const getPerformanceStatus = (value: number, type: string): { status: string; color: string; icon: any } => {
    switch (type) {
      case 'memory':
        if (value < 50) return { status: 'excellent', color: 'text-green-600', icon: CheckCircle };
        if (value < 80) return { status: 'good', color: 'text-yellow-600', icon: Clock };
        return { status: 'critical', color: 'text-red-600', icon: AlertTriangle };
      
      case 'responseTime':
        if (value < 100) return { status: 'excellent', color: 'text-green-600', icon: CheckCircle };
        if (value < 300) return { status: 'good', color: 'text-yellow-600', icon: Clock };
        return { status: 'needs improvement', color: 'text-red-600', icon: AlertTriangle };
      
      default:
        return { status: 'unknown', color: 'text-gray-600', icon: Clock };
    }
  };

  const getAverageResponseTime = (times: number[]): number => {
    if (!times || times.length === 0) return 0;
    return times.reduce((sum, time) => sum + time, 0) / times.length;
  };

  const handleRefreshData = () => {
    queryClient.invalidateQueries({ queryKey: ['/api/performance/metrics'] });
  };

  if (isLoading || !metrics) {
    return (
      <div className="container mx-auto p-6 space-y-6" dir={language === 'ar' ? 'rtl' : 'ltr'}>
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center gap-3">
            <Gauge className="h-8 w-8 text-primary animate-pulse" />
            <h1 className="text-3xl font-bold">
              {language === 'ar' ? 'مراقب الأداء' : 'Performance Monitor'}
            </h1>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(6)].map((_, i) => (
            <Card key={i}>
              <CardContent className="p-6">
                <div className="animate-pulse space-y-4">
                  <div className="h-4 bg-muted rounded w-3/4"></div>
                  <div className="h-8 bg-muted rounded w-1/2"></div>
                  <div className="h-4 bg-muted rounded w-2/3"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  const memoryUsagePercent = (metrics.performance.memoryUsage.heapUsed / metrics.performance.memoryUsage.heapTotal) * 100;
  const totalCacheHits = Object.values(metrics.cache).reduce((sum, cache) => sum + cache.hits, 0);
  const totalCacheMisses = Object.values(metrics.cache).reduce((sum, cache) => sum + cache.misses, 0);
  const overallCacheHitRate = totalCacheHits + totalCacheMisses > 0 ? 
    (totalCacheHits / (totalCacheHits + totalCacheMisses)) * 100 : 0;

  return (
    <div className="container mx-auto p-6 space-y-6" dir={language === 'ar' ? 'rtl' : 'ltr'}>
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="flex items-center justify-center gap-3">
          <Gauge className="h-8 w-8 text-primary" />
          <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            {language === 'ar' ? 'مراقب الأداء المحسن' : 'Enhanced Performance Monitor'}
          </h1>
        </div>
        <p className="text-lg text-muted-foreground max-w-3xl mx-auto leading-relaxed">
          {language === 'ar' 
            ? 'مراقبة شاملة للأداء مع تحليلات متقدمة وتحسينات تلقائية'
            : 'Comprehensive performance monitoring with advanced analytics and automated optimizations'
          }
        </p>
        <div className="flex items-center justify-center gap-4">
          <Badge variant="outline" className="flex items-center gap-1">
            <Activity className="h-3 w-3" />
            {language === 'ar' ? 'مباشر' : 'Live'}
          </Badge>
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => optimizeMemoryMutation.mutate()}
            disabled={optimizeMemoryMutation.isPending}
          >
            {optimizeMemoryMutation.isPending ? (
              <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
            ) : (
              <Zap className="h-4 w-4 mr-2" />
            )}
            {language === 'ar' ? 'تحسين الذاكرة' : 'Optimize Memory'}
          </Button>
        </div>
      </div>

      {/* System Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">
                  {language === 'ar' ? 'الذاكرة المستخدمة' : 'Memory Usage'}
                </p>
                <p className="text-2xl font-bold">{memoryUsagePercent.toFixed(1)}%</p>
                <p className="text-xs text-muted-foreground">
                  {formatBytes(metrics.performance.memoryUsage.heapUsed)} / {formatBytes(metrics.performance.memoryUsage.heapTotal)}
                </p>
              </div>
              <HardDrive className={`h-8 w-8 ${getPerformanceStatus(memoryUsagePercent, 'memory').color}`} />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">
                  {language === 'ar' ? 'الاتصالات النشطة' : 'Active Connections'}
                </p>
                <p className="text-2xl font-bold">{metrics.performance.activeConnections}</p>
                <p className="text-xs text-muted-foreground">
                  {language === 'ar' ? 'متصل حالياً' : 'Currently connected'}
                </p>
              </div>
              <Server className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">
                  {language === 'ar' ? 'معدل إصابة الذاكرة المؤقتة' : 'Cache Hit Rate'}
                </p>
                <p className="text-2xl font-bold">{overallCacheHitRate.toFixed(1)}%</p>
                <p className="text-xs text-muted-foreground">
                  {totalCacheHits} hits / {totalCacheMisses} misses
                </p>
              </div>
              <Database className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">
                  {language === 'ar' ? 'إجمالي الطلبات' : 'Total Requests'}
                </p>
                <p className="text-2xl font-bold">{metrics.performance.requestCount}</p>
                <p className="text-xs text-muted-foreground">
                  {metrics.performance.errorCount} {language === 'ar' ? 'أخطاء' : 'errors'}
                </p>
              </div>
              <BarChart3 className="h-8 w-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* API Response Times */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Timer className="h-5 w-5" />
            {language === 'ar' ? 'أوقات استجابة API' : 'API Response Times'}
          </CardTitle>
          <CardDescription>
            {language === 'ar' 
              ? 'متوسط أوقات الاستجابة لنقاط النهاية المختلفة'
              : 'Average response times for different endpoints'
            }
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {Object.entries(metrics.performance.apiResponseTimes).map(([endpoint, times]) => {
              const avgTime = getAverageResponseTime(times);
              const status = getPerformanceStatus(avgTime, 'responseTime');
              const StatusIcon = status.icon;
              
              return (
                <div key={endpoint} className="p-4 border rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-medium text-sm truncate">{endpoint}</span>
                    <StatusIcon className={`h-4 w-4 ${status.color}`} />
                  </div>
                  <div className="space-y-1">
                    <div className="text-xl font-bold">{avgTime.toFixed(0)}ms</div>
                    <div className="text-xs text-muted-foreground">
                      {language === 'ar' ? 'متوسط من' : 'Average from'} {times.length} {language === 'ar' ? 'طلب' : 'requests'}
                    </div>
                    <div className={`text-xs ${status.color}`}>
                      {language === 'ar' ?
                        (status.status === 'excellent' ? 'ممتاز' : 
                         status.status === 'good' ? 'جيد' : 'يحتاج تحسين') :
                        status.status
                      }
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Cache Performance */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Layers className="h-5 w-5" />
            {language === 'ar' ? 'أداء الذاكرة المؤقتة' : 'Cache Performance'}
          </CardTitle>
          <CardDescription>
            {language === 'ar' 
              ? 'تفاصيل أداء الذاكرة المؤقتة لكل نوع بيانات'
              : 'Detailed cache performance for each data type'
            }
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {Object.entries(metrics.cache).map(([cacheName, cacheData]) => (
              <div key={cacheName} className="p-4 border rounded-lg">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <h4 className="font-medium capitalize">{cacheName}</h4>
                    <Badge variant="outline">
                      {cacheData.size}/{cacheData.maxSize}
                    </Badge>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">
                        {language === 'ar' ? 'معدل الإصابة' : 'Hit Rate'}
                      </span>
                      <span className="font-medium">{cacheData.hitRate}%</span>
                    </div>
                    
                    <div className="w-full bg-muted rounded-full h-2">
                      <div 
                        className="bg-green-600 h-2 rounded-full transition-all"
                        style={{ width: `${cacheData.hitRate}%` }}
                      />
                    </div>
                    
                    <div className="flex justify-between text-xs text-muted-foreground">
                      <span>{cacheData.hits} hits</span>
                      <span>{cacheData.misses} misses</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Memory Details */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Cpu className="h-5 w-5" />
            {language === 'ar' ? 'تفاصيل الذاكرة' : 'Memory Details'}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="text-center p-4 bg-blue-50 dark:bg-blue-950/20 rounded-lg">
              <div className="text-2xl font-bold text-blue-600">
                {formatBytes(metrics.performance.memoryUsage.rss)}
              </div>
              <div className="text-sm text-muted-foreground">
                {language === 'ar' ? 'مجموعة الذاكرة المقيمة' : 'Resident Set Size'}
              </div>
            </div>
            
            <div className="text-center p-4 bg-green-50 dark:bg-green-950/20 rounded-lg">
              <div className="text-2xl font-bold text-green-600">
                {formatBytes(metrics.performance.memoryUsage.heapUsed)}
              </div>
              <div className="text-sm text-muted-foreground">
                {language === 'ar' ? 'الكومة المستخدمة' : 'Heap Used'}
              </div>
            </div>
            
            <div className="text-center p-4 bg-purple-50 dark:bg-purple-950/20 rounded-lg">
              <div className="text-2xl font-bold text-purple-600">
                {formatBytes(metrics.performance.memoryUsage.heapTotal)}
              </div>
              <div className="text-sm text-muted-foreground">
                {language === 'ar' ? 'إجمالي الكومة' : 'Heap Total'}
              </div>
            </div>
            
            <div className="text-center p-4 bg-orange-50 dark:bg-orange-950/20 rounded-lg">
              <div className="text-2xl font-bold text-orange-600">
                {formatBytes(metrics.performance.memoryUsage.external)}
              </div>
              <div className="text-sm text-muted-foreground">
                {language === 'ar' ? 'الذاكرة الخارجية' : 'External Memory'}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Performance Status */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="h-5 w-5" />
            {language === 'ar' ? 'حالة النظام' : 'System Status'}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-green-50 dark:bg-green-950/20 border border-green-200 dark:border-green-800 rounded-lg">
              <div className="flex items-center gap-3">
                <CheckCircle className="h-5 w-5 text-green-600" />
                <span className="font-medium">
                  {language === 'ar' ? 'النظام يعمل بكفاءة' : 'System Running Efficiently'}
                </span>
              </div>
              <Badge variant="secondary" className="text-green-600">
                {language === 'ar' ? 'مُحسن' : 'Optimized'}
              </Badge>
            </div>
            
            <div className="text-sm text-muted-foreground">
              {language === 'ar' ? 'آخر تحديث:' : 'Last updated:'} {new Date(metrics.timestamp).toLocaleString(language === 'ar' ? 'ar-SA' : 'en-US')}
            </div>
          </div>
        </CardContent>
      </Card>

      <FloatingRefreshButton onRefresh={handleRefreshData} />
    </div>
  );
}