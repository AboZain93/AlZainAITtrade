import { useState, useEffect } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { 
  Brain, 
  TrendingUp, 
  Activity, 
  Target, 
  Zap, 
  BarChart3, 
  Settings, 
  RefreshCw,
  Gauge,
  Cpu,
  Database,
  Network,
  AlertTriangle,
  CheckCircle,
  Clock,
  Trophy,
  Lightbulb,
  ArrowUp,
  ArrowDown,
  Minus
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useLanguageContext } from '@/components/language-provider';
import { FloatingRefreshButton } from '@/components/floating-refresh-button';

interface AIModel {
  modelId: string;
  modelType: string;
  accuracy: number;
  precision: number;
  recall: number;
  f1Score: number;
  status: string;
  confidence: number;
  validationLoss: number;
  trainingSamples: number;
  specialization: string[];
}

interface ModelPrediction {
  modelId: string;
  prediction: string;
  confidence: number;
  reasoning: string[];
  timeHorizon: string;
  expectedPrice: number;
}

interface EnsemblePrediction {
  consensusScore: number;
  predictedOutcome: string;
  probabilityDistribution: {
    buyProb: number;
    sellProb: number;
    holdProb: number;
  };
  riskMetrics: {
    expectedReturn: number;
    volatility: number;
    sharpeRatio: number;
    maxDrawdown: number;
    valueAtRisk: number;
  };
  marketRegimeAnalysis: {
    regime: string;
    regimeConfidence: number;
    tradingStrategy: string;
  };
}

interface SystemStatus {
  modelsActive: number;
  modelsHealth: AIModel[];
  marketRegime: string;
  volatilityLevel: string;
  systemHealth: string;
  lastUpdate: string;
}

interface PerformanceMetrics {
  accuracyImprovement: number;
  modelUpdates: number;
  newPatterns: number;
  optimizationSuggestions: string[];
  learningProgress: {
    trainingLoss: number;
    validationLoss: number;
    overfitting: boolean;
    convergence: boolean;
  };
}

export default function AIPerformanceMonitor() {
  const { language } = useLanguageContext();
  const queryClient = useQueryClient();
  const [selectedModel, setSelectedModel] = useState<string>('');
  const [activeTab, setActiveTab] = useState('overview');

  // Fetch system status
  const { data: systemStatus, isLoading: statusLoading, refetch: refetchStatus } = useQuery<SystemStatus>({
    queryKey: ['/api/ai-performance/system-status'],
    refetchInterval: 10000,
  });

  // Fetch performance metrics
  const { data: performanceMetrics, isLoading: metricsLoading, refetch: refetchMetrics } = useQuery<PerformanceMetrics>({
    queryKey: ['/api/ai-performance/metrics'],
    refetchInterval: 15000,
  });

  // Fetch model insights
  const { data: modelInsights, isLoading: insightsLoading, refetch: refetchInsights } = useQuery({
    queryKey: ['/api/ai-performance/model-insights', selectedModel],
    enabled: !!selectedModel,
    refetchInterval: 20000,
  });

  // Fetch ensemble prediction
  const { data: ensemblePrediction, isLoading: ensembleLoading, refetch: refetchEnsemble } = useQuery<EnsemblePrediction>({
    queryKey: ['/api/ai-performance/ensemble-prediction'],
    refetchInterval: 30000,
  });

  const isLoading = statusLoading || metricsLoading || ensembleLoading;

  const handleRefresh = () => {
    refetchStatus();
    refetchMetrics();
    refetchEnsemble();
    if (selectedModel) {
      refetchInsights();
    }
  };

  const getHealthColor = (health: string) => {
    switch (health) {
      case 'excellent': return 'text-green-600 dark:text-green-400';
      case 'good': return 'text-blue-600 dark:text-blue-400';
      case 'fair': return 'text-yellow-600 dark:text-yellow-400';
      case 'poor': return 'text-red-600 dark:text-red-400';
      default: return 'text-gray-600 dark:text-gray-400';
    }
  };

  const getAccuracyColor = (accuracy: number) => {
    if (accuracy >= 0.9) return 'text-green-600 dark:text-green-400';
    if (accuracy >= 0.8) return 'text-blue-600 dark:text-blue-400';
    if (accuracy >= 0.7) return 'text-yellow-600 dark:text-yellow-400';
    return 'text-red-600 dark:text-red-400';
  };

  const getRegimeIcon = (regime: string) => {
    switch (regime) {
      case 'trending': return <TrendingUp className="h-4 w-4" />;
      case 'volatile': return <Activity className="h-4 w-4" />;
      case 'ranging': return <Minus className="h-4 w-4" />;
      case 'reversal': return <RefreshCw className="h-4 w-4" />;
      default: return <BarChart3 className="h-4 w-4" />;
    }
  };

  const getPredictionIcon = (prediction: string) => {
    switch (prediction) {
      case 'BUY': return <ArrowUp className="h-4 w-4 text-green-600" />;
      case 'SELL': return <ArrowDown className="h-4 w-4 text-red-600" />;
      case 'HOLD': return <Minus className="h-4 w-4 text-yellow-600" />;
      default: return <Target className="h-4 w-4" />;
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 dark:from-gray-900 dark:via-blue-900 dark:to-indigo-900 p-4">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-center h-64">
            <div className="flex flex-col items-center space-y-4">
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-r from-blue-400 to-purple-400 rounded-2xl blur-lg opacity-50 animate-pulse"></div>
                <div className="relative p-4 bg-gradient-to-r from-blue-500 to-purple-500 rounded-2xl">
                  <Brain className="h-12 w-12 text-white animate-spin" />
                </div>
              </div>
              <div className="text-center">
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white">
                  {language === 'ar' ? 'جاري تحميل مراقب الأداء المتقدم...' : 'Loading Advanced Performance Monitor...'}
                </h3>
                <p className="text-gray-600 dark:text-gray-300 mt-2">
                  {language === 'ar' ? 'تحليل نماذج الذكاء الاصطناعي' : 'Analyzing AI models'}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 dark:from-gray-900 dark:via-blue-900 dark:to-indigo-900 p-4">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center gap-4">
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-blue-400 to-purple-400 rounded-2xl blur-lg opacity-50"></div>
              <div className="relative p-4 bg-gradient-to-r from-blue-500 to-purple-500 rounded-2xl">
                <Brain className="h-10 w-10 text-white" />
              </div>
            </div>
            <div className="text-left">
              <h1 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white tracking-tight">
                {language === 'ar' ? 'مراقب الأداء المتقدم' : 'AI Performance Monitor'}
              </h1>
              <div className="h-1 w-32 bg-gradient-to-r from-blue-400 to-purple-400 rounded-full mt-2"></div>
            </div>
          </div>
          
          <p className="text-gray-600 dark:text-gray-300 text-lg md:text-xl max-w-3xl mx-auto leading-relaxed">
            {language === 'ar' 
              ? 'مراقبة وتحليل شامل لأداء نماذج الذكاء الاصطناعي مع التعلم التكيفي المتقدم' 
              : 'Comprehensive monitoring and analysis of AI model performance with advanced adaptive learning'
            }
          </p>
        </div>

        {/* System Overview Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card className="border-0 shadow-lg bg-gradient-to-br from-green-50 to-emerald-100 dark:from-green-900/20 dark:to-emerald-900/20">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-green-700 dark:text-green-300">
                    {language === 'ar' ? 'حالة النظام' : 'System Health'}
                  </p>
                  <p className={`text-2xl font-bold capitalize ${getHealthColor(systemStatus?.systemHealth || 'good')}`}>
                    {systemStatus?.systemHealth === 'excellent' ? (language === 'ar' ? 'ممتاز' : 'Excellent') :
                     systemStatus?.systemHealth === 'good' ? (language === 'ar' ? 'جيد' : 'Good') :
                     systemStatus?.systemHealth === 'fair' ? (language === 'ar' ? 'مقبول' : 'Fair') :
                     (language === 'ar' ? 'ضعيف' : 'Poor')}
                  </p>
                </div>
                <div className="relative">
                  <Gauge className="h-8 w-8 text-green-600 dark:text-green-400" />
                  {systemStatus?.systemHealth === 'excellent' && (
                    <CheckCircle className="h-4 w-4 text-green-600 absolute -top-1 -right-1" />
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg bg-gradient-to-br from-blue-50 to-cyan-100 dark:from-blue-900/20 dark:to-cyan-900/20">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-blue-700 dark:text-blue-300">
                    {language === 'ar' ? 'النماذج النشطة' : 'Active Models'}
                  </p>
                  <p className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                    {systemStatus?.modelsActive || 0} / 4
                  </p>
                </div>
                <Cpu className="h-8 w-8 text-blue-600 dark:text-blue-400" />
              </div>
              <div className="mt-2">
                <Progress value={(systemStatus?.modelsActive || 0) / 4 * 100} className="h-2" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg bg-gradient-to-br from-purple-50 to-violet-100 dark:from-purple-900/20 dark:to-violet-900/20">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-purple-700 dark:text-purple-300">
                    {language === 'ar' ? 'نظام السوق' : 'Market Regime'}
                  </p>
                  <div className="flex items-center gap-2">
                    {getRegimeIcon(systemStatus?.marketRegime || '')}
                    <p className="text-xl font-bold text-purple-600 dark:text-purple-400 capitalize">
                      {systemStatus?.marketRegime === 'trending' ? (language === 'ar' ? 'اتجاه' : 'Trending') :
                       systemStatus?.marketRegime === 'volatile' ? (language === 'ar' ? 'متقلب' : 'Volatile') :
                       systemStatus?.marketRegime === 'ranging' ? (language === 'ar' ? 'نطاق' : 'Ranging') :
                       systemStatus?.marketRegime === 'reversal' ? (language === 'ar' ? 'انعكاس' : 'Reversal') :
                       (language === 'ar' ? 'غير محدد' : 'Unknown')}
                    </p>
                  </div>
                </div>
                <Activity className="h-8 w-8 text-purple-600 dark:text-purple-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg bg-gradient-to-br from-orange-50 to-amber-100 dark:from-orange-900/20 dark:to-amber-900/20">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-orange-700 dark:text-orange-300">
                    {language === 'ar' ? 'تحسين الدقة' : 'Accuracy Improvement'}
                  </p>
                  <div className="flex items-center gap-1">
                    <ArrowUp className="h-4 w-4 text-green-600" />
                    <p className="text-2xl font-bold text-orange-600 dark:text-orange-400">
                      +{performanceMetrics?.accuracyImprovement?.toFixed(1) || '0.0'}%
                    </p>
                  </div>
                </div>
                <Trophy className="h-8 w-8 text-orange-600 dark:text-orange-400" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Ensemble Prediction Summary */}
        {ensemblePrediction && (
          <Card className="border-0 shadow-lg bg-gradient-to-r from-indigo-50 to-purple-50 dark:from-indigo-900/20 dark:to-purple-900/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-indigo-900 dark:text-indigo-100">
                <Target className="h-5 w-5" />
                {language === 'ar' ? 'توقع النماذج المجمعة' : 'Ensemble Prediction'}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600 dark:text-gray-400">
                      {language === 'ar' ? 'التوقع' : 'Prediction'}
                    </span>
                    <div className="flex items-center gap-2">
                      {getPredictionIcon(ensemblePrediction.predictedOutcome)}
                      <Badge variant={ensemblePrediction.predictedOutcome === 'BUY' ? 'default' : 
                                   ensemblePrediction.predictedOutcome === 'SELL' ? 'destructive' : 'secondary'}>
                        {ensemblePrediction.predictedOutcome}
                      </Badge>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600 dark:text-gray-400">
                      {language === 'ar' ? 'درجة الإجماع' : 'Consensus Score'}
                    </span>
                    <span className="font-bold text-lg text-indigo-600 dark:text-indigo-400">
                      {ensemblePrediction.consensusScore}%
                    </span>
                  </div>
                  
                  <Progress value={ensemblePrediction.consensusScore} className="h-3" />
                </div>

                <div className="space-y-3">
                  <h4 className="font-semibold text-gray-900 dark:text-gray-100">
                    {language === 'ar' ? 'توزيع الاحتمالات' : 'Probability Distribution'}
                  </h4>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-green-600">BUY</span>
                      <span className="text-sm font-medium">
                        {(ensemblePrediction.probabilityDistribution.buyProb * 100).toFixed(1)}%
                      </span>
                    </div>
                    <Progress value={ensemblePrediction.probabilityDistribution.buyProb * 100} className="h-2" />
                    
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-red-600">SELL</span>
                      <span className="text-sm font-medium">
                        {(ensemblePrediction.probabilityDistribution.sellProb * 100).toFixed(1)}%
                      </span>
                    </div>
                    <Progress value={ensemblePrediction.probabilityDistribution.sellProb * 100} className="h-2" />
                    
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-yellow-600">HOLD</span>
                      <span className="text-sm font-medium">
                        {(ensemblePrediction.probabilityDistribution.holdProb * 100).toFixed(1)}%
                      </span>
                    </div>
                    <Progress value={ensemblePrediction.probabilityDistribution.holdProb * 100} className="h-2" />
                  </div>
                </div>

                <div className="space-y-3">
                  <h4 className="font-semibold text-gray-900 dark:text-gray-100">
                    {language === 'ar' ? 'مقاييس المخاطر' : 'Risk Metrics'}
                  </h4>
                  
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600 dark:text-gray-400">
                        {language === 'ar' ? 'العائد المتوقع' : 'Expected Return'}
                      </span>
                      <span className={`font-medium ${ensemblePrediction.riskMetrics.expectedReturn >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {ensemblePrediction.riskMetrics.expectedReturn.toFixed(2)}%
                      </span>
                    </div>
                    
                    <div className="flex justify-between">
                      <span className="text-gray-600 dark:text-gray-400">
                        {language === 'ar' ? 'نسبة شارب' : 'Sharpe Ratio'}
                      </span>
                      <span className="font-medium text-blue-600">
                        {ensemblePrediction.riskMetrics.sharpeRatio.toFixed(2)}
                      </span>
                    </div>
                    
                    <div className="flex justify-between">
                      <span className="text-gray-600 dark:text-gray-400">
                        {language === 'ar' ? 'أقصى انخفاض' : 'Max Drawdown'}
                      </span>
                      <span className="font-medium text-red-600">
                        {(ensemblePrediction.riskMetrics.maxDrawdown * 100).toFixed(1)}%
                      </span>
                    </div>
                    
                    <div className="flex justify-between">
                      <span className="text-gray-600 dark:text-gray-400">VaR (95%)</span>
                      <span className="font-medium text-orange-600">
                        {ensemblePrediction.riskMetrics.valueAtRisk.toFixed(2)}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Detailed Analysis Tabs */}
        <Card className="border-0 shadow-lg">
          <CardContent className="p-0">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid w-full grid-cols-4 bg-gray-100 dark:bg-gray-800 m-4 mb-0">
                <TabsTrigger value="overview" className="flex items-center gap-2">
                  <BarChart3 className="h-4 w-4" />
                  {language === 'ar' ? 'نظرة عامة' : 'Overview'}
                </TabsTrigger>
                <TabsTrigger value="models" className="flex items-center gap-2">
                  <Cpu className="h-4 w-4" />
                  {language === 'ar' ? 'النماذج' : 'Models'}
                </TabsTrigger>
                <TabsTrigger value="learning" className="flex items-center gap-2">
                  <Lightbulb className="h-4 w-4" />
                  {language === 'ar' ? 'التعلم' : 'Learning'}
                </TabsTrigger>
                <TabsTrigger value="insights" className="flex items-center gap-2">
                  <Brain className="h-4 w-4" />
                  {language === 'ar' ? 'الرؤى' : 'Insights'}
                </TabsTrigger>
              </TabsList>

              <div className="p-6">
                <TabsContent value="overview" className="space-y-6">
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    {/* System Performance */}
                    <Card className="border border-gray-200 dark:border-gray-700">
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <Activity className="h-5 w-5" />
                          {language === 'ar' ? 'أداء النظام' : 'System Performance'}
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        {systemStatus?.modelsHealth.map((model) => (
                          <div key={model.modelId} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                            <div>
                              <p className="font-medium capitalize">
                                {model.modelType ? model.modelType.replace('_', ' ') : 'Unknown Model'}
                              </p>
                              <p className="text-sm text-gray-600 dark:text-gray-400">
                                {model.specialization ? model.specialization.slice(0, 2).join(', ') : 'General'}
                              </p>
                            </div>
                            <div className="text-right">
                              <p className={`font-bold ${getAccuracyColor(model.accuracy)}`}>
                                {(model.accuracy * 100).toFixed(1)}%
                              </p>
                              <Badge variant={model.status === 'active' ? 'default' : 'secondary'} className="text-xs">
                                {model.status === 'active' ? (language === 'ar' ? 'نشط' : 'Active') : (language === 'ar' ? 'متوقف' : 'Inactive')}
                              </Badge>
                            </div>
                          </div>
                        ))}
                      </CardContent>
                    </Card>

                    {/* Learning Progress */}
                    <Card className="border border-gray-200 dark:border-gray-700">
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <TrendingUp className="h-5 w-5" />
                          {language === 'ar' ? 'تقدم التعلم' : 'Learning Progress'}
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        {performanceMetrics && (
                          <>
                            <div className="flex justify-between items-center">
                              <span className="text-sm text-gray-600 dark:text-gray-400">
                                {language === 'ar' ? 'خسارة التدريب' : 'Training Loss'}
                              </span>
                              <span className="font-medium">
                                {performanceMetrics.learningProgress.trainingLoss.toFixed(3)}
                              </span>
                            </div>
                            
                            <div className="flex justify-between items-center">
                              <span className="text-sm text-gray-600 dark:text-gray-400">
                                {language === 'ar' ? 'خسارة التحقق' : 'Validation Loss'}
                              </span>
                              <span className="font-medium">
                                {performanceMetrics.learningProgress.validationLoss.toFixed(3)}
                              </span>
                            </div>
                            
                            <div className="flex justify-between items-center">
                              <span className="text-sm text-gray-600 dark:text-gray-400">
                                {language === 'ar' ? 'التقارب' : 'Convergence'}
                              </span>
                              <Badge variant={performanceMetrics.learningProgress.convergence ? 'default' : 'secondary'}>
                                {performanceMetrics.learningProgress.convergence ? 
                                  (language === 'ar' ? 'متقارب' : 'Converged') : 
                                  (language === 'ar' ? 'يتقارب' : 'Converging')
                                }
                              </Badge>
                            </div>
                            
                            <div className="flex justify-between items-center">
                              <span className="text-sm text-gray-600 dark:text-gray-400">
                                {language === 'ar' ? 'الإفراط في التدريب' : 'Overfitting'}
                              </span>
                              <Badge variant={performanceMetrics.learningProgress.overfitting ? 'destructive' : 'default'}>
                                {performanceMetrics.learningProgress.overfitting ? 
                                  (language === 'ar' ? 'موجود' : 'Detected') : 
                                  (language === 'ar' ? 'غير موجود' : 'None')
                                }
                              </Badge>
                            </div>
                          </>
                        )}
                      </CardContent>
                    </Card>
                  </div>
                </TabsContent>

                <TabsContent value="models" className="space-y-6">
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    {systemStatus?.modelsHealth.map((model) => (
                      <Card key={model.modelId} className="border border-gray-200 dark:border-gray-700 hover:shadow-lg transition-shadow cursor-pointer"
                            onClick={() => setSelectedModel(model.modelId)}>
                        <CardHeader>
                          <CardTitle className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <Cpu className="h-5 w-5" />
                              <span className="capitalize">
                                {model.modelType ? model.modelType.replace('_', ' ') : 'Unknown Model'}
                              </span>
                            </div>
                            <Badge variant={selectedModel === model.modelId ? 'default' : 'secondary'}>
                              {selectedModel === model.modelId ? (language === 'ar' ? 'مختار' : 'Selected') : (language === 'ar' ? 'اختر' : 'Select')}
                            </Badge>
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                          <div className="grid grid-cols-2 gap-4 text-sm">
                            <div>
                              <p className="text-gray-600 dark:text-gray-400">
                                {language === 'ar' ? 'الدقة' : 'Accuracy'}
                              </p>
                              <p className={`font-bold text-lg ${getAccuracyColor(model.accuracy)}`}>
                                {(model.accuracy * 100).toFixed(1)}%
                              </p>
                            </div>
                            <div>
                              <p className="text-gray-600 dark:text-gray-400">
                                {language === 'ar' ? 'الثقة' : 'Confidence'}
                              </p>
                              <p className="font-bold text-lg text-blue-600 dark:text-blue-400">
                                {(model.confidence * 100).toFixed(1)}%
                              </p>
                            </div>
                            <div>
                              <p className="text-gray-600 dark:text-gray-400">
                                {language === 'ar' ? 'الدقة' : 'Precision'}
                              </p>
                              <p className="font-medium">
                                {(model.precision * 100).toFixed(1)}%
                              </p>
                            </div>
                            <div>
                              <p className="text-gray-600 dark:text-gray-400">
                                {language === 'ar' ? 'الاستدعاء' : 'Recall'}
                              </p>
                              <p className="font-medium">
                                {(model.recall * 100).toFixed(1)}%
                              </p>
                            </div>
                          </div>
                          
                          <div>
                            <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                              {language === 'ar' ? 'التخصصات' : 'Specializations'}
                            </p>
                            <div className="flex flex-wrap gap-1">
                              {model.specialization && model.specialization.length > 0 ? model.specialization.map((spec) => (
                                <Badge key={spec} variant="outline" className="text-xs">
                                  {spec ? spec.replace('_', ' ') : 'General'}
                                </Badge>
                              )) : (
                                <Badge variant="outline" className="text-xs">
                                  General
                                </Badge>
                              )}
                            </div>
                          </div>
                          
                          <div className="flex justify-between text-sm">
                            <span className="text-gray-600 dark:text-gray-400">
                              {language === 'ar' ? 'عينات التدريب' : 'Training Samples'}
                            </span>
                            <span className="font-medium">
                              {model.trainingSamples.toLocaleString()}
                            </span>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </TabsContent>

                <TabsContent value="learning" className="space-y-6">
                  {performanceMetrics && (
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                      <Card className="border border-gray-200 dark:border-gray-700">
                        <CardHeader>
                          <CardTitle className="flex items-center gap-2">
                            <Lightbulb className="h-5 w-5" />
                            {language === 'ar' ? 'اقتراحات التحسين' : 'Optimization Suggestions'}
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-3">
                            {performanceMetrics.optimizationSuggestions.map((suggestion, index) => (
                              <div key={index} className="flex items-start gap-3 p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                                <Settings className="h-4 w-4 text-blue-600 mt-1 flex-shrink-0" />
                                <p className="text-sm text-blue-800 dark:text-blue-200">
                                  {suggestion}
                                </p>
                              </div>
                            ))}
                            {performanceMetrics.optimizationSuggestions.length === 0 && (
                              <p className="text-gray-600 dark:text-gray-400 text-center py-4">
                                {language === 'ar' ? 'لا توجد اقتراحات تحسين حالياً' : 'No optimization suggestions at the moment'}
                              </p>
                            )}
                          </div>
                        </CardContent>
                      </Card>

                      <Card className="border border-gray-200 dark:border-gray-700">
                        <CardHeader>
                          <CardTitle className="flex items-center gap-2">
                            <Database className="h-5 w-5" />
                            {language === 'ar' ? 'إحصائيات التعلم' : 'Learning Statistics'}
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                          <div className="grid grid-cols-2 gap-4">
                            <div className="text-center p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
                              <p className="text-2xl font-bold text-green-600 dark:text-green-400">
                                {performanceMetrics.modelUpdates}
                              </p>
                              <p className="text-sm text-green-700 dark:text-green-300">
                                {language === 'ar' ? 'تحديثات النماذج' : 'Model Updates'}
                              </p>
                            </div>
                            
                            <div className="text-center p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                              <p className="text-2xl font-bold text-purple-600 dark:text-purple-400">
                                {performanceMetrics.newPatterns}
                              </p>
                              <p className="text-sm text-purple-700 dark:text-purple-300">
                                {language === 'ar' ? 'أنماط جديدة' : 'New Patterns'}
                              </p>
                            </div>
                          </div>
                          
                          <div className="space-y-3">
                            <div className="flex justify-between items-center">
                              <span className="text-sm text-gray-600 dark:text-gray-400">
                                {language === 'ar' ? 'تحسين الدقة' : 'Accuracy Improvement'}
                              </span>
                              <span className={`font-bold ${performanceMetrics.accuracyImprovement >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                                {performanceMetrics.accuracyImprovement >= 0 ? '+' : ''}{performanceMetrics.accuracyImprovement.toFixed(1)}%
                              </span>
                            </div>
                            
                            <Progress 
                              value={Math.abs(performanceMetrics.accuracyImprovement) * 10} 
                              className="h-2" 
                            />
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  )}
                </TabsContent>

                <TabsContent value="insights" className="space-y-6">
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <Card className="border border-gray-200 dark:border-gray-700">
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <Brain className="h-5 w-5" />
                          {language === 'ar' ? 'رؤى النماذج' : 'Model Insights'}
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        {selectedModel ? (
                          <div className="space-y-4">
                            {insightsLoading ? (
                              <div className="text-center py-8">
                                <RefreshCw className="h-8 w-8 animate-spin mx-auto text-gray-400" />
                                <p className="text-gray-600 dark:text-gray-400 mt-2">
                                  {language === 'ar' ? 'جاري تحميل رؤى النموذج...' : 'Loading model insights...'}
                                </p>
                              </div>
                            ) : modelInsights ? (
                              <div className="space-y-4">
                                <p className="text-sm text-gray-600 dark:text-gray-400">
                                  {language === 'ar' ? 'تحليل مفصل للنموذج المختار' : 'Detailed analysis of selected model'}
                                </p>
                                {/* Add model insights content here */}
                                <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                                  <p className="text-blue-800 dark:text-blue-200">
                                    {language === 'ar' ? 'رؤى النموذج متاحة' : 'Model insights available'}
                                  </p>
                                </div>
                              </div>
                            ) : (
                              <p className="text-gray-600 dark:text-gray-400 text-center py-4">
                                {language === 'ar' ? 'لا توجد رؤى متاحة' : 'No insights available'}
                              </p>
                            )}
                          </div>
                        ) : (
                          <p className="text-gray-600 dark:text-gray-400 text-center py-8">
                            {language === 'ar' ? 'اختر نموذج من تبويب النماذج لعرض الرؤى' : 'Select a model from Models tab to view insights'}
                          </p>
                        )}
                      </CardContent>
                    </Card>

                    <Card className="border border-gray-200 dark:border-gray-700">
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <Network className="h-5 w-5" />
                          {language === 'ar' ? 'حالة الاتصال' : 'System Status'}
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="flex items-center justify-between p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                          <div className="flex items-center gap-2">
                            <CheckCircle className="h-4 w-4 text-green-600" />
                            <span className="text-sm text-green-800 dark:text-green-200">
                              {language === 'ar' ? 'اتصال النماذج' : 'Model Connection'}
                            </span>
                          </div>
                          <Badge variant="default" className="bg-green-600">
                            {language === 'ar' ? 'متصل' : 'Connected'}
                          </Badge>
                        </div>
                        
                        <div className="flex items-center justify-between p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                          <div className="flex items-center gap-2">
                            <Database className="h-4 w-4 text-blue-600" />
                            <span className="text-sm text-blue-800 dark:text-blue-200">
                              {language === 'ar' ? 'قاعدة البيانات' : 'Database'}
                            </span>
                          </div>
                          <Badge variant="default" className="bg-blue-600">
                            {language === 'ar' ? 'نشط' : 'Active'}
                          </Badge>
                        </div>
                        
                        <div className="flex items-center justify-between p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                          <div className="flex items-center gap-2">
                            <Zap className="h-4 w-4 text-purple-600" />
                            <span className="text-sm text-purple-800 dark:text-purple-200">
                              {language === 'ar' ? 'التعلم التكيفي' : 'Adaptive Learning'}
                            </span>
                          </div>
                          <Badge variant="default" className="bg-purple-600">
                            {language === 'ar' ? 'يعمل' : 'Running'}
                          </Badge>
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-gray-600 dark:text-gray-400">
                            {language === 'ar' ? 'آخر تحديث' : 'Last Update'}
                          </span>
                          <div className="flex items-center gap-1">
                            <Clock className="h-3 w-3 text-gray-400" />
                            <span className="text-xs text-gray-600 dark:text-gray-400">
                              {systemStatus?.lastUpdate ? new Date(systemStatus.lastUpdate).toLocaleTimeString() : 'Never'}
                            </span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </TabsContent>
              </div>
            </Tabs>
          </CardContent>
        </Card>
      </div>

      {/* Floating Refresh Button */}
      <FloatingRefreshButton onRefresh={handleRefresh} />
    </div>
  );
}