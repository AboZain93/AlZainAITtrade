import { AppHealthMonitor } from '@/components/app-health-monitor';
import { PerformanceOptimizer } from '@/components/performance-optimizer';
import { ApplicationAnalysisReport } from '@/components/application-analysis-report';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useLanguageContext } from '@/components/language-provider';
import { Activity, Zap, Gauge, Settings, BarChart3 } from 'lucide-react';

export default function AppHealthDashboard() {
  const { language } = useLanguageContext();

  return (
    <div className="container mx-auto px-4 py-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            {language === 'ar' ? 'لوحة مراقبة صحة التطبيق' : 'Application Health Dashboard'}
          </h1>
          <p className="text-muted-foreground mt-2">
            {language === 'ar' 
              ? 'مراقبة شاملة لصحة النظام والأداء والتحسينات' 
              : 'Comprehensive monitoring of system health, performance, and optimizations'}
          </p>
        </div>
      </div>

      <Tabs defaultValue="analysis" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="analysis" className="flex items-center gap-2">
            <BarChart3 className="h-4 w-4" />
            {language === 'ar' ? 'التحليل الشامل' : 'Analysis Report'}
          </TabsTrigger>
          <TabsTrigger value="health" className="flex items-center gap-2">
            <Activity className="h-4 w-4" />
            {language === 'ar' ? 'صحة النظام' : 'System Health'}
          </TabsTrigger>
          <TabsTrigger value="performance" className="flex items-center gap-2">
            <Zap className="h-4 w-4" />
            {language === 'ar' ? 'الأداء' : 'Performance'}
          </TabsTrigger>
          <TabsTrigger value="insights" className="flex items-center gap-2">
            <Gauge className="h-4 w-4" />
            {language === 'ar' ? 'الرؤى' : 'Insights'}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="analysis" className="space-y-6">
          <ApplicationAnalysisReport />
        </TabsContent>

        <TabsContent value="health" className="space-y-6">
          <AppHealthMonitor />
        </TabsContent>

        <TabsContent value="performance" className="space-y-6">
          <PerformanceOptimizer />
        </TabsContent>

        <TabsContent value="insights" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="h-5 w-5" />
                  {language === 'ar' ? 'توصيات التحسين' : 'Optimization Recommendations'}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-green-500 rounded-full mt-2"></div>
                    <div>
                      <h4 className="font-medium">
                        {language === 'ar' ? 'تحسين الذاكرة' : 'Memory Optimization'}
                      </h4>
                      <p className="text-sm text-muted-foreground">
                        {language === 'ar' 
                          ? 'استخدام الذاكرة ضمن المعدل الطبيعي' 
                          : 'Memory usage is within normal range'}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-yellow-500 rounded-full mt-2"></div>
                    <div>
                      <h4 className="font-medium">
                        {language === 'ar' ? 'أداء قاعدة البيانات' : 'Database Performance'}
                      </h4>
                      <p className="text-sm text-muted-foreground">
                        {language === 'ar' 
                          ? 'يمكن تحسين سرعة الاستعلامات' 
                          : 'Query speed can be optimized'}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                    <div>
                      <h4 className="font-medium">
                        {language === 'ar' ? 'التخزين المؤقت' : 'Caching Strategy'}
                      </h4>
                      <p className="text-sm text-muted-foreground">
                        {language === 'ar' 
                          ? 'معدل إصابة عالي في التخزين المؤقت' 
                          : 'High cache hit rate achieved'}
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="h-5 w-5" />
                  {language === 'ar' ? 'مؤشرات الأداء الرئيسية' : 'Key Performance Indicators'}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">
                      {language === 'ar' ? 'وقت الاستجابة المتوسط' : 'Avg Response Time'}
                    </span>
                    <span className="text-sm font-medium text-green-600">
                      &lt; 200ms
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">
                      {language === 'ar' ? 'معدل نجاح API' : 'API Success Rate'}
                    </span>
                    <span className="text-sm font-medium text-green-600">
                      98.5%
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">
                      {language === 'ar' ? 'وقت التشغيل' : 'Uptime'}
                    </span>
                    <span className="text-sm font-medium text-green-600">
                      99.9%
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">
                      {language === 'ar' ? 'معدل الأخطاء' : 'Error Rate'}
                    </span>
                    <span className="text-sm font-medium text-green-600">
                      &lt; 1%
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>
                  {language === 'ar' ? 'اتجاهات الأداء' : 'Performance Trends'}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">
                      {language === 'ar' ? 'آخر 24 ساعة' : 'Last 24 hours'}
                    </span>
                    <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded-full">
                      {language === 'ar' ? 'مستقر' : 'Stable'}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">
                      {language === 'ar' ? 'آخر 7 أيام' : 'Last 7 days'}
                    </span>
                    <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded-full">
                      {language === 'ar' ? 'تحسن' : 'Improving'}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">
                      {language === 'ar' ? 'آخر 30 يوم' : 'Last 30 days'}
                    </span>
                    <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded-full">
                      {language === 'ar' ? 'ممتاز' : 'Excellent'}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>
                  {language === 'ar' ? 'إجراءات سريعة' : 'Quick Actions'}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <button className="w-full text-left p-3 bg-muted rounded-lg hover:bg-muted/80 transition-colors">
                    <div className="font-medium text-sm">
                      {language === 'ar' ? 'إعادة تشغيل الخدمات' : 'Restart Services'}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {language === 'ar' 
                        ? 'إعادة تشغيل جميع الخدمات للتحسين' 
                        : 'Restart all services for optimization'}
                    </div>
                  </button>
                  <button className="w-full text-left p-3 bg-muted rounded-lg hover:bg-muted/80 transition-colors">
                    <div className="font-medium text-sm">
                      {language === 'ar' ? 'تحديث التكوين' : 'Update Configuration'}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {language === 'ar' 
                        ? 'تحديث إعدادات النظام للأداء الأمثل' 
                        : 'Update system settings for optimal performance'}
                    </div>
                  </button>
                  <button className="w-full text-left p-3 bg-muted rounded-lg hover:bg-muted/80 transition-colors">
                    <div className="font-medium text-sm">
                      {language === 'ar' ? 'تقرير تفصيلي' : 'Detailed Report'}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {language === 'ar' 
                        ? 'إنشاء تقرير شامل عن صحة النظام' 
                        : 'Generate comprehensive system health report'}
                    </div>
                  </button>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}