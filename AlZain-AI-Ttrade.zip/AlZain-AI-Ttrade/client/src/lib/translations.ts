export const translations = {
  en: {
    // Header
    dashboard: 'Dashboard',
    recommendations: 'Recommendations',
    technicalAnalysis: 'Technical Analysis',
    statistics: 'Statistics',
    
    // Dashboard Stats
    totalRecommendations: 'Total Recommendations',
    successRate: 'Success Rate',
    activeUsers: 'Active Users',
    avgConfidence: 'Average Confidence',
    
    // Market Status
    marketStatus: 'Market Status',
    liveUpdate: 'Live Update',
    
    // Trading Recommendation
    latestRecommendation: 'Latest Recommendation',
    asset: 'Asset',
    direction: 'Direction',
    confidence: 'Confidence',
    risk: 'Risk',
    technicalAnalysisLabel: 'Technical Analysis',
    success: 'Success',
    failed: 'Failed',
    
    // Technical Indicators
    technicalIndicators: 'Technical Indicators',
    rsi: 'RSI',
    macd: 'MACD',
    movingAverage: 'Moving Average',
    volume: 'Volume',
    strongBuySignal: 'Strong Buy Signal',
    priceAboveAverage: 'Price Above Average',
    highVolume: 'High Volume',
    strongTradingActivity: 'Strong Trading Activity',
    
    // AI Analysis
    aiAnalysis: 'AI Analysis',
    overallConfidence: 'Overall Confidence Level',
    aiInsights: 'AI Insights',
    positiveAnalysis: 'Positive Analysis',
    technicalPattern: 'Technical Pattern',
    warning: 'Warning',
    
    // Risk levels
    low: 'Low',
    medium: 'Medium',
    high: 'High',
    
    // Directions
    buy: 'BUY',
    sell: 'SELL',
    hold: 'HOLD',
    
    // Common
    viewAll: 'View All',
    refresh: 'Refresh',
    send: 'Send',
    settings: 'Settings',
    theme: 'Theme',
    language: 'Language',
  },
  ar: {
    // Header
    dashboard: 'لوحة التحكم',
    recommendations: 'التوصيات',
    technicalAnalysis: 'التحليل الفني',
    statistics: 'الإحصائيات',
    
    // Dashboard Stats
    totalRecommendations: 'إجمالي التوصيات',
    successRate: 'معدل النجاح',
    activeUsers: 'المستخدمين النشطين',
    avgConfidence: 'متوسط الثقة',
    
    // Market Status
    marketStatus: 'حالة السوق الحالية',
    liveUpdate: 'تحديث مباشر',
    
    // Trading Recommendation
    latestRecommendation: 'آخر توصية',
    asset: 'الأصل',
    direction: 'الاتجاه',
    confidence: 'نسبة الثقة',
    risk: 'المخاطرة',
    technicalAnalysisLabel: 'التحليل الفني',
    success: 'نجح',
    failed: 'فشل',
    
    // Technical Indicators
    technicalIndicators: 'المؤشرات الفنية',
    rsi: 'RSI',
    macd: 'MACD',
    movingAverage: 'MA',
    volume: 'حجم التداول',
    strongBuySignal: 'إشارة شراء قوية',
    priceAboveAverage: 'السعر أعلى من المتوسط',
    highVolume: 'مرتفع',
    strongTradingActivity: 'نشاط تداول قوي',
    
    // AI Analysis
    aiAnalysis: 'تحليل الذكاء الاصطناعي',
    overallConfidence: 'مستوى الثقة الإجمالي',
    aiInsights: 'رؤى الذكاء الاصطناعي',
    positiveAnalysis: 'تحليل إيجابي',
    technicalPattern: 'نمط تقني',
    warning: 'تحذير',
    
    // Risk levels
    low: 'منخفضة',
    medium: 'متوسطة',
    high: 'عالية',
    
    // Directions
    buy: 'شراء',
    sell: 'بيع',
    hold: 'انتظار',
    
    // Common
    viewAll: 'عرض الكل',
    refresh: 'تحديث',
    send: 'إرسال',
    settings: 'الإعدادات',
    theme: 'المظهر',
    language: 'اللغة',
  },
};

export type TranslationKey = keyof typeof translations.en;
export type Language = 'en' | 'ar';
