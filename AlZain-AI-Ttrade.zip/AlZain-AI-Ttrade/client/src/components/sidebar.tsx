import { EnhancedSidebar } from './sidebar-enhanced';

export function Sidebar() {
  return <EnhancedSidebar />;
}

// Export for mobile compatibility
export { EnhancedSidebar as MobileSidebar };