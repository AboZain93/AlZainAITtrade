import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { useQuery } from '@tanstack/react-query';
import { useLanguageContext } from '@/components/language-provider';
import { 
  Activity, 
  AlertTriangle, 
  CheckCircle, 
  Clock, 
  Database,
  Globe,
  Server,
  Wifi,
  RefreshCw,
  TrendingUp,
  TrendingDown,
  Minus
} from 'lucide-react';

interface HealthMetrics {
  overall: {
    status: 'healthy' | 'warning' | 'critical';
    score: number;
    uptime: number;
  };
  services: {
    api: {
      status: 'online' | 'offline' | 'degraded';
      responseTime: number;
      successRate: number;
    };
    database: {
      status: 'connected' | 'disconnected' | 'slow';
      queryTime: number;
      connectionPool: number;
    };
    telegram: {
      status: 'active' | 'inactive' | 'error';
      lastMessage: Date;
      deliveryRate: number;
    };
    signals: {
      status: 'generating' | 'paused' | 'error';
      lastGenerated: Date;
      successRate: number;
    };
  };
  performance: {
    loadTime: number;
    memoryUsage: number;
    errorRate: number;
    requestsPerMinute: number;
  };
}

export function AppHealthMonitor() {
  const context = useLanguageContext();
  const language = context?.language || 'ar';
  const [refreshInterval, setRefreshInterval] = useState(30000); // 30 seconds

  const { data: health, isLoading, error } = useQuery<HealthMetrics>({
    queryKey: ['/api/health/metrics'],
    refetchInterval: refreshInterval,
    retry: 3,
  });

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'healthy':
      case 'online':
      case 'connected':
      case 'active':
      case 'generating':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'warning':
      case 'degraded':
      case 'slow':
      case 'paused':
        return <AlertTriangle className="h-4 w-4 text-yellow-500" />;
      case 'critical':
      case 'offline':
      case 'disconnected':
      case 'inactive':
      case 'error':
        return <AlertTriangle className="h-4 w-4 text-red-500" />;
      default:
        return <Minus className="h-4 w-4 text-gray-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'healthy':
      case 'online':
      case 'connected':
      case 'active':
      case 'generating':
        return 'secondary';
      case 'warning':
      case 'degraded':
      case 'slow':
      case 'paused':
        return 'default';
      case 'critical':
      case 'offline':
      case 'disconnected':
      case 'inactive':
      case 'error':
        return 'destructive';
      default:
        return 'outline';
    }
  };

  const formatUptime = (seconds: number) => {
    const days = Math.floor(seconds / 86400);
    const hours = Math.floor((seconds % 86400) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    
    if (language === 'ar') {
      return `${days} يوم، ${hours} ساعة، ${minutes} دقيقة`;
    }
    return `${days}d ${hours}h ${minutes}m`;
  };

  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diff = Math.floor((now.getTime() - date.getTime()) / 1000);
    
    if (diff < 60) {
      return language === 'ar' ? 'الآن' : 'now';
    } else if (diff < 3600) {
      const minutes = Math.floor(diff / 60);
      return language === 'ar' ? `منذ ${minutes} دقيقة` : `${minutes}m ago`;
    } else {
      const hours = Math.floor(diff / 3600);
      return language === 'ar' ? `منذ ${hours} ساعة` : `${hours}h ago`;
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-8">
        <RefreshCw className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (error) {
    return (
      <Card className="border-destructive">
        <CardContent className="pt-6">
          <div className="flex items-center gap-2 text-destructive">
            <AlertTriangle className="h-5 w-5" />
            <span>{language === 'ar' ? 'خطأ في تحميل بيانات الصحة' : 'Failed to load health data'}</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">
            {language === 'ar' ? 'مراقب صحة التطبيق' : 'Application Health Monitor'}
          </h2>
          <p className="text-muted-foreground">
            {language === 'ar' 
              ? 'مراقبة حالة جميع خدمات ومكونات النظام' 
              : 'Monitor the status of all system services and components'}
          </p>
        </div>
        <Badge 
          variant={getStatusColor(health?.overall.status || 'unknown')}
          className="text-sm px-3 py-1"
        >
          {getStatusIcon(health?.overall.status || 'unknown')}
          <span className="ml-2">
            {health?.overall.status === 'healthy' 
              ? (language === 'ar' ? 'صحي' : 'Healthy')
              : health?.overall.status === 'warning'
              ? (language === 'ar' ? 'تحذير' : 'Warning')
              : health?.overall.status === 'critical'
              ? (language === 'ar' ? 'حرج' : 'Critical')
              : (language === 'ar' ? 'غير معروف' : 'Unknown')}
          </span>
        </Badge>
      </div>

      {/* Overall Health */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5" />
            {language === 'ar' ? 'الحالة العامة' : 'Overall Health'}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <div className="text-2xl font-bold">
                {health?.overall.score || 0}%
              </div>
              <Progress value={health?.overall.score || 0} className="mt-2" />
              <p className="text-sm text-muted-foreground mt-1">
                {language === 'ar' ? 'نقاط الصحة العامة' : 'Overall Health Score'}
              </p>
            </div>
            <div>
              <div className="text-2xl font-bold text-green-600">
                {formatUptime(health?.overall.uptime || 0)}
              </div>
              <p className="text-sm text-muted-foreground mt-1">
                {language === 'ar' ? 'وقت التشغيل' : 'Uptime'}
              </p>
            </div>
            <div>
              <div className="text-2xl font-bold">
                {health?.performance.loadTime || 0}ms
              </div>
              <p className="text-sm text-muted-foreground mt-1">
                {language === 'ar' ? 'وقت التحميل' : 'Load Time'}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Service Status */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* API Service */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              {language === 'ar' ? 'خدمة API' : 'API Service'}
            </CardTitle>
            <Server className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <Badge variant={getStatusColor(health?.services.api.status || 'unknown')}>
                {getStatusIcon(health?.services.api.status || 'unknown')}
                <span className="ml-1">
                  {health?.services.api.status === 'online' 
                    ? (language === 'ar' ? 'متصل' : 'Online')
                    : health?.services.api.status === 'degraded'
                    ? (language === 'ar' ? 'بطيء' : 'Degraded')
                    : (language === 'ar' ? 'غير متصل' : 'Offline')}
                </span>
              </Badge>
            </div>
            <div className="text-xs text-muted-foreground mt-2 space-y-1">
              <div className="flex justify-between">
                <span>{language === 'ar' ? 'وقت الاستجابة:' : 'Response:'}</span>
                <span>{health?.services.api.responseTime || 0}ms</span>
              </div>
              <div className="flex justify-between">
                <span>{language === 'ar' ? 'معدل النجاح:' : 'Success:'}</span>
                <span>{health?.services.api.successRate || 0}%</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Database */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              {language === 'ar' ? 'قاعدة البيانات' : 'Database'}
            </CardTitle>
            <Database className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <Badge variant={getStatusColor(health?.services.database.status || 'unknown')}>
                {getStatusIcon(health?.services.database.status || 'unknown')}
                <span className="ml-1">
                  {health?.services.database.status === 'connected' 
                    ? (language === 'ar' ? 'متصل' : 'Connected')
                    : health?.services.database.status === 'slow'
                    ? (language === 'ar' ? 'بطيء' : 'Slow')
                    : (language === 'ar' ? 'غير متصل' : 'Disconnected')}
                </span>
              </Badge>
            </div>
            <div className="text-xs text-muted-foreground mt-2 space-y-1">
              <div className="flex justify-between">
                <span>{language === 'ar' ? 'وقت الاستعلام:' : 'Query time:'}</span>
                <span>{health?.services.database.queryTime || 0}ms</span>
              </div>
              <div className="flex justify-between">
                <span>{language === 'ar' ? 'الاتصالات:' : 'Connections:'}</span>
                <span>{health?.services.database.connectionPool || 0}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Telegram Bot */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              {language === 'ar' ? 'بوت تليجرام' : 'Telegram Bot'}
            </CardTitle>
            <Globe className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <Badge variant={getStatusColor(health?.services.telegram.status || 'unknown')}>
                {getStatusIcon(health?.services.telegram.status || 'unknown')}
                <span className="ml-1">
                  {health?.services.telegram.status === 'active' 
                    ? (language === 'ar' ? 'نشط' : 'Active')
                    : health?.services.telegram.status === 'inactive'
                    ? (language === 'ar' ? 'غير نشط' : 'Inactive')
                    : (language === 'ar' ? 'خطأ' : 'Error')}
                </span>
              </Badge>
            </div>
            <div className="text-xs text-muted-foreground mt-2 space-y-1">
              <div className="flex justify-between">
                <span>{language === 'ar' ? 'آخر رسالة:' : 'Last message:'}</span>
                <span>{health?.services.telegram.lastMessage ? formatTimeAgo(health.services.telegram.lastMessage) : '-'}</span>
              </div>
              <div className="flex justify-between">
                <span>{language === 'ar' ? 'معدل التسليم:' : 'Delivery:'}</span>
                <span>{health?.services.telegram.deliveryRate || 0}%</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Signal Generator */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              {language === 'ar' ? 'مولد الإشارات' : 'Signal Generator'}
            </CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <Badge variant={getStatusColor(health?.services.signals.status || 'unknown')}>
                {getStatusIcon(health?.services.signals.status || 'unknown')}
                <span className="ml-1">
                  {health?.services.signals.status === 'generating' 
                    ? (language === 'ar' ? 'يولد' : 'Generating')
                    : health?.services.signals.status === 'paused'
                    ? (language === 'ar' ? 'متوقف' : 'Paused')
                    : (language === 'ar' ? 'خطأ' : 'Error')}
                </span>
              </Badge>
            </div>
            <div className="text-xs text-muted-foreground mt-2 space-y-1">
              <div className="flex justify-between">
                <span>{language === 'ar' ? 'آخر إشارة:' : 'Last signal:'}</span>
                <span>{health?.services.signals.lastGenerated ? formatTimeAgo(health.services.signals.lastGenerated) : '-'}</span>
              </div>
              <div className="flex justify-between">
                <span>{language === 'ar' ? 'معدل النجاح:' : 'Success:'}</span>
                <span>{health?.services.signals.successRate || 0}%</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Performance Metrics */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            {language === 'ar' ? 'مؤشرات الأداء' : 'Performance Metrics'}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div>
              <div className="text-2xl font-bold">
                {health?.performance.memoryUsage || 0}%
              </div>
              <Progress value={health?.performance.memoryUsage || 0} className="mt-2" />
              <p className="text-sm text-muted-foreground mt-1">
                {language === 'ar' ? 'استخدام الذاكرة' : 'Memory Usage'}
              </p>
            </div>
            <div>
              <div className="text-2xl font-bold">
                {health?.performance.errorRate || 0}%
              </div>
              <Progress 
                value={health?.performance.errorRate || 0} 
                className="mt-2"
              />
              <p className="text-sm text-muted-foreground mt-1">
                {language === 'ar' ? 'معدل الأخطاء' : 'Error Rate'}
              </p>
            </div>
            <div>
              <div className="text-2xl font-bold">
                {health?.performance.requestsPerMinute || 0}
              </div>
              <p className="text-sm text-muted-foreground mt-1">
                {language === 'ar' ? 'الطلبات في الدقيقة' : 'Requests/Minute'}
              </p>
            </div>
            <div>
              <div className="text-2xl font-bold">
                {health?.performance.loadTime || 0}ms
              </div>
              <p className="text-sm text-muted-foreground mt-1">
                {language === 'ar' ? 'وقت التحميل المتوسط' : 'Avg Load Time'}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}