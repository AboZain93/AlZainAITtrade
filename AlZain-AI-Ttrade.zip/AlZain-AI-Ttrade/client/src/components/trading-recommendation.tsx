import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useLanguageContext } from '@/components/language-provider';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { TrendingUp, TrendingDown, Activity } from 'lucide-react';

interface TradingRecommendation {
  id: number;
  assetSymbol: string;
  direction: string;
  confidence: number;
  riskLevel: string;
  technicalAnalysis: string;
  marketStatus: string;
  entryTime: string;
  duration: string;
  trend: string;
  liquidity: string;
  result?: string;
  sentToTelegram: boolean;
  createdAt: string;
}

export function TradingRecommendation() {
  const context = useLanguageContext();
  const t = context?.t || ((key: string) => key);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: recommendations, isLoading } = useQuery<TradingRecommendation[]>({
    queryKey: ['/api/trading-recommendations/recent'],
    queryFn: () => apiRequest('GET', '/api/trading-recommendations/recent?limit=1').then(res => res.json()),
  });

  const markResultMutation = useMutation({
    mutationFn: (data: { id: number; result: string }) =>
      apiRequest('PUT', `/api/trading-recommendations/${data.id}/result`, { result: data.result }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/trading-recommendations/recent'] });
      toast({
        title: 'Success',
        description: 'Recommendation result updated successfully',
      });
    },
    onError: () => {
      toast({
        title: 'Error',
        description: 'Failed to update recommendation result',
        variant: 'destructive',
      });
    },
  });

  const latestRecommendation = recommendations?.[0];

  const getDirectionIcon = (direction: string) => {
    if (direction === 'BUY') return <TrendingUp className="h-5 w-5 text-green-500" />;
    if (direction === 'SELL') return <TrendingDown className="h-5 w-5 text-red-500" />;
    return <Activity className="h-5 w-5 text-gray-500" />;
  };

  const getDirectionEmoji = (direction: string) => {
    if (direction === 'BUY') return '📈';
    if (direction === 'SELL') return '📉';
    return '⚖️';
  };

  const getRiskColor = (riskLevel: string) => {
    if (riskLevel === 'low') return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
    if (riskLevel === 'medium') return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
    return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200';
  };

  const handleMarkResult = (result: string) => {
    if (latestRecommendation) {
      markResultMutation.mutate({ id: latestRecommendation.id, result });
    }
  };

  if (isLoading) {
    return (
      <Card className="gradient-bg text-white">
        <CardHeader>
          <CardTitle className="text-lg font-semibold">
            {t('latestRecommendation')}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="animate-pulse">
              <div className="h-4 bg-white/20 rounded w-3/4 mb-2"></div>
              <div className="h-4 bg-white/20 rounded w-1/2 mb-2"></div>
              <div className="h-4 bg-white/20 rounded w-2/3"></div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!latestRecommendation) {
    return (
      <Card className="gradient-bg text-white">
        <CardHeader>
          <CardTitle className="text-lg font-semibold">
            {t('latestRecommendation')}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-white/80">No recommendations available</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="gradient-bg text-white">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold">
            {t('latestRecommendation')}
          </CardTitle>
          <div className="w-3 h-3 bg-green-400 rounded-full status-indicator"></div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-sm opacity-90">{t('asset')}:</span>
            <span className="font-semibold">{latestRecommendation.assetSymbol}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm opacity-90">{t('direction')}:</span>
            <div className="flex items-center space-x-2 rtl:space-x-reverse">
              <span className="font-semibold text-green-300">
                {t(latestRecommendation.direction.toLowerCase() as any)} {getDirectionEmoji(latestRecommendation.direction)}
              </span>
            </div>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm opacity-90">{t('confidence')}:</span>
            <span className="font-semibold">{latestRecommendation.confidence}%</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm opacity-90">{t('risk')}:</span>
            <Badge className={getRiskColor(latestRecommendation.riskLevel)}>
              {t(latestRecommendation.riskLevel as any)}
            </Badge>
          </div>
        </div>

        <div className="mt-6 p-4 bg-white/10 rounded-lg">
          <p className="text-sm opacity-90 mb-2">{t('technicalAnalysisLabel')}:</p>
          <p className="text-sm">{latestRecommendation.technicalAnalysis}</p>
        </div>

        <div className="mt-6 p-4 bg-white/10 rounded-lg">
          <p className="text-sm opacity-90 mb-2">Market Status:</p>
          <p className="text-sm">{latestRecommendation.marketStatus}</p>
        </div>

        {latestRecommendation.result === 'pending' && (
          <div className="mt-4 flex space-x-2 rtl:space-x-reverse">
            <Button
              variant="secondary"
              size="sm"
              className="flex-1 bg-green-500 hover:bg-green-600 text-white"
              onClick={() => handleMarkResult('success')}
              disabled={markResultMutation.isPending}
            >
              ✅ {t('success')}
            </Button>
            <Button
              variant="secondary"
              size="sm"
              className="flex-1 bg-red-500 hover:bg-red-600 text-white"
              onClick={() => handleMarkResult('fail')}
              disabled={markResultMutation.isPending}
            >
              🔴 {t('failed')}
            </Button>
          </div>
        )}

        {latestRecommendation.result !== 'pending' && (
          <div className="mt-4">
            <Badge 
              className={latestRecommendation.result === 'success' ? 
                'bg-green-100 text-green-800' : 
                'bg-red-100 text-red-800'
              }
            >
              {latestRecommendation.result === 'success' ? '✅ Success' : '🔴 Failed'}
            </Badge>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
