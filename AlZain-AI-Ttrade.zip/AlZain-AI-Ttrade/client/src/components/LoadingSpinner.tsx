import { cn } from '@/lib/utils';
import { Loader2, TrendingUp, Brain } from 'lucide-react';

interface LoadingSpinnerProps {
  size?: 'sm' | 'md' | 'lg';
  variant?: 'default' | 'trading' | 'ai';
  text?: string;
  className?: string;
}

export function LoadingSpinner({ 
  size = 'md', 
  variant = 'default', 
  text,
  className 
}: LoadingSpinnerProps) {
  const sizeClasses = {
    sm: 'h-4 w-4',
    md: 'h-6 w-6',
    lg: 'h-8 w-8'
  };

  const getIcon = () => {
    switch (variant) {
      case 'trading':
        return <TrendingUp className={cn(sizeClasses[size], 'animate-pulse text-green-600')} />;
      case 'ai':
        return <Brain className={cn(sizeClasses[size], 'animate-pulse text-purple-600')} />;
      default:
        return <Loader2 className={cn(sizeClasses[size], 'animate-spin')} />;
    }
  };

  const getLoadingText = () => {
    if (text) return text;
    
    switch (variant) {
      case 'trading':
        return 'تحليل السوق...';
      case 'ai':
        return 'معالجة البيانات...';
      default:
        return 'جاري التحميل...';
    }
  };

  return (
    <div className={cn(
      'flex flex-col items-center justify-center gap-3 p-6',
      className
    )}>
      <div className="relative">
        <div className="absolute inset-0 animate-ping rounded-full bg-primary/20"></div>
        {getIcon()}
      </div>
      
      {(text !== null) && (
        <div className="text-center">
          <p className="text-sm text-muted-foreground font-medium">
            {getLoadingText()}
          </p>
          <div className="flex justify-center mt-2">
            <div className="flex space-x-1">
              <div className="h-1 w-1 bg-primary rounded-full animate-bounce [animation-delay:-0.3s]"></div>
              <div className="h-1 w-1 bg-primary rounded-full animate-bounce [animation-delay:-0.15s]"></div>
              <div className="h-1 w-1 bg-primary rounded-full animate-bounce"></div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// Skeleton loading component for cards
export function SkeletonCard({ className }: { className?: string }) {
  return (
    <div className={cn('animate-pulse', className)}>
      <div className="bg-muted rounded-lg p-4 space-y-3">
        <div className="h-4 bg-muted-foreground/20 rounded w-3/4"></div>
        <div className="space-y-2">
          <div className="h-3 bg-muted-foreground/20 rounded w-full"></div>
          <div className="h-3 bg-muted-foreground/20 rounded w-2/3"></div>
        </div>
        <div className="h-8 bg-muted-foreground/20 rounded w-1/3"></div>
      </div>
    </div>
  );
}