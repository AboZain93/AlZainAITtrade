import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { useQuery } from '@tanstack/react-query';
import { useLanguageContext } from '@/components/language-provider';
import { Activity, TrendingUp, BarChart3, Volume2 } from 'lucide-react';

interface TechnicalIndicators {
  id: number;
  symbol: string;
  rsi?: number;
  macd?: number;
  ma20?: number;
  ma50?: number;
  volume?: string;
  signal?: string;
  timestamp: string;
}

export function TechnicalIndicators() {
  const { t } = useLanguageContext();

  const { data: indicators, isLoading } = useQuery<TechnicalIndicators[]>({
    queryKey: ['/api/technical-indicators'],
    refetchInterval: 60000, // Refetch every minute
  });

  // For demo purposes, we'll use the first indicator or create mock data
  const mainIndicator = indicators?.[0] || {
    rsi: 67.8,
    macd: 0.0023,
    ma20: 1.0834,
    ma50: 1.0820,
    volume: 'high',
    signal: 'BUY',
  };

  const getSignalColor = (signal?: string) => {
    if (signal === 'BUY') return 'text-green-600';
    if (signal === 'SELL') return 'text-red-600';
    return 'text-gray-600';
  };

  const getSignalIcon = (signal?: string) => {
    if (signal === 'BUY') return <TrendingUp className="h-4 w-4 text-green-500" />;
    if (signal === 'SELL') return <TrendingUp className="h-4 w-4 text-red-500 rotate-180" />;
    return <Activity className="h-4 w-4 text-gray-500" />;
  };

  const getRSIColor = (rsi?: number) => {
    if (!rsi) return 'bg-gray-300';
    if (rsi > 70) return 'bg-red-500';
    if (rsi < 30) return 'bg-green-500';
    return 'bg-yellow-500';
  };

  return (
    <Card className="card-hover">
      <CardHeader>
        <CardTitle className="text-lg font-semibold flex items-center space-x-2 rtl:space-x-reverse">
          <BarChart3 className="h-5 w-5" />
          <span>{t('technicalIndicators')}</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {/* RSI Indicator */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-foreground">{t('rsi')} (14)</span>
              <span className="text-sm font-semibold text-foreground">
                {mainIndicator.rsi?.toFixed(1) || '67.8'}
              </span>
            </div>
            <Progress 
              value={mainIndicator.rsi || 67.8} 
              className="h-2"
              style={{
                backgroundColor: 'hsl(var(--muted))',
              }}
            />
            <div className="flex justify-between text-xs text-muted-foreground mt-1">
              <span>0</span>
              <span>30</span>
              <span>70</span>
              <span>100</span>
            </div>
          </div>

          {/* MACD Indicator */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-foreground">{t('macd')}</span>
              <span className={`text-sm font-semibold ${
                (mainIndicator.macd || 0.0023) > 0 ? 'text-green-600' : 'text-red-600'
              }`}>
                {(mainIndicator.macd || 0.0023) > 0 ? '+' : ''}{(mainIndicator.macd || 0.0023).toFixed(4)}
              </span>
            </div>
            <div className="flex items-center space-x-2 rtl:space-x-reverse">
              <div className="w-3 h-3 bg-green-500 rounded-full"></div>
              <span className="text-sm text-muted-foreground">{t('strongBuySignal')}</span>
            </div>
          </div>

          {/* Moving Average */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-foreground">{t('movingAverage')} (20)</span>
              <span className="text-sm font-semibold text-foreground">
                {mainIndicator.ma20?.toFixed(4) || '1.0834'}
              </span>
            </div>
            <div className="flex items-center space-x-2 rtl:space-x-reverse">
              <div className="w-3 h-3 bg-green-500 rounded-full"></div>
              <span className="text-sm text-muted-foreground">{t('priceAboveAverage')}</span>
            </div>
          </div>

          {/* Volume */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-foreground">{t('volume')}</span>
              <span className="text-sm font-semibold text-foreground">
                {mainIndicator.volume || t('highVolume')}
              </span>
            </div>
            <div className="flex items-center space-x-2 rtl:space-x-reverse">
              <Volume2 className="h-3 w-3 text-blue-500" />
              <span className="text-sm text-muted-foreground">{t('strongTradingActivity')}</span>
            </div>
          </div>

          {/* Overall Signal */}
          <div className="pt-4 border-t border-border">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-foreground">Overall Signal</span>
              <div className="flex items-center space-x-2 rtl:space-x-reverse">
                {getSignalIcon(mainIndicator.signal)}
                <span className={`text-sm font-semibold ${getSignalColor(mainIndicator.signal)}`}>
                  {mainIndicator.signal || 'BUY'}
                </span>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
