import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useLanguageContext } from '@/components/language-provider';
import { useToast } from '@/hooks/use-toast';
import { 
  Bell, 
  Smartphone, 
  Volume2, 
  VolumeX, 
  Settings, 
  Target,
  TrendingUp,
  AlertTriangle,
  CheckCircle,
  Filter,
  Clock,
  Zap
} from 'lucide-react';

interface NotificationSettings {
  enablePushNotifications: boolean;
  enableSoundAlerts: boolean;
  minimumConfidence: number;
  riskLevelFilter: 'ALL' | 'LOW' | 'MEDIUM' | 'HIGH';
  platformFilter: 'ALL' | string;
  timeFilter: 'ALL' | 'MARKET_HOURS' | 'CUSTOM';
  customTimeStart: string;
  customTimeEnd: string;
  frequencyLimit: number; // Max notifications per hour
  prioritySignalsOnly: boolean;
}

interface SmartNotification {
  id: string;
  type: 'SIGNAL' | 'MARKET_ALERT' | 'SYSTEM' | 'PERFORMANCE';
  title: string;
  message: string;
  priority: 'LOW' | 'MEDIUM' | 'HIGH' | 'URGENT';
  timestamp: Date;
  data?: any;
  read: boolean;
  actionRequired?: boolean;
}

export function SmartNotifications() {
  const { language } = useLanguageContext();
  const { toast } = useToast();
  
  const [settings, setSettings] = useState<NotificationSettings>(() => {
    const saved = localStorage.getItem('notificationSettings');
    return saved ? JSON.parse(saved) : {
      enablePushNotifications: true,
      enableSoundAlerts: true,
      minimumConfidence: 75,
      riskLevelFilter: 'ALL',
      platformFilter: 'ALL',
      timeFilter: 'MARKET_HOURS',
      customTimeStart: '09:00',
      customTimeEnd: '17:00',
      frequencyLimit: 5,
      prioritySignalsOnly: false
    };
  });

  const [notifications, setNotifications] = useState<SmartNotification[]>([]);
  const [isPermissionGranted, setIsPermissionGranted] = useState(false);

  useEffect(() => {
    // Check notification permission
    if ('Notification' in window) {
      setIsPermissionGranted(Notification.permission === 'granted');
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('notificationSettings', JSON.stringify(settings));
  }, [settings]);

  const requestNotificationPermission = async () => {
    if ('Notification' in window) {
      const permission = await Notification.requestPermission();
      setIsPermissionGranted(permission === 'granted');
      
      if (permission === 'granted') {
        toast({
          title: language === 'ar' ? 'تم تفعيل الإشعارات' : 'Notifications Enabled',
          description: language === 'ar' 
            ? 'ستتلقى إشعارات فورية عند ظهور إشارات جديدة'
            : 'You will receive instant notifications for new trading signals',
        });
      } else {
        toast({
          title: language === 'ar' ? 'تم رفض الإشعارات' : 'Notifications Denied',
          description: language === 'ar' 
            ? 'يمكنك تفعيل الإشعارات من إعدادات المتصفح'
            : 'You can enable notifications from browser settings',
          variant: 'destructive'
        });
      }
    }
  };

  const sendTestNotification = () => {
    if (isPermissionGranted) {
      new Notification(
        language === 'ar' ? '🎯 إشارة تداول جديدة' : '🎯 New Trading Signal',
        {
          body: language === 'ar' 
            ? 'EUR/USD - شراء - ثقة 85% - مخاطرة منخفضة'
            : 'EUR/USD - BUY - 85% Confidence - Low Risk',
          icon: '/app-icon.png',
          badge: '/app-icon.png',
          tag: 'trading-signal',
          requireInteraction: true
        }
      );

      toast({
        title: language === 'ar' ? 'تم إرسال إشعار تجريبي' : 'Test Notification Sent',
        description: language === 'ar' 
          ? 'تحقق من ظهور الإشعار على جهازك'
          : 'Check if the notification appeared on your device',
      });
    }
  };

  const updateSetting = (key: keyof NotificationSettings, value: any) => {
    setSettings(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const clearAllNotifications = () => {
    setNotifications([]);
    toast({
      title: language === 'ar' ? 'تم مسح الإشعارات' : 'Notifications Cleared',
      description: language === 'ar' 
        ? 'تم حذف جميع الإشعارات بنجاح'
        : 'All notifications have been cleared successfully',
    });
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'URGENT': return 'text-red-600 dark:text-red-400';
      case 'HIGH': return 'text-orange-600 dark:text-orange-400';
      case 'MEDIUM': return 'text-blue-600 dark:text-blue-400';
      default: return 'text-gray-600 dark:text-gray-400';
    }
  };

  const getPriorityIcon = (priority: string) => {
    switch (priority) {
      case 'URGENT': return <AlertTriangle className="h-4 w-4" />;
      case 'HIGH': return <TrendingUp className="h-4 w-4" />;
      case 'MEDIUM': return <Target className="h-4 w-4" />;
      default: return <Bell className="h-4 w-4" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Notification Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bell className="h-5 w-5 text-primary" />
            {language === 'ar' ? 'إعدادات الإشعارات الذكية' : 'Smart Notification Settings'}
          </CardTitle>
          <CardDescription>
            {language === 'ar' 
              ? 'تخصيص الإشعارات لتلقي التنبيهات المهمة فقط حسب تفضيلاتك'
              : 'Customize notifications to receive only important alerts based on your preferences'
            }
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Permission Status */}
          <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
            <div className="flex items-center gap-2">
              <Smartphone className="h-5 w-5 text-primary" />
              <span className="font-medium">
                {language === 'ar' ? 'حالة الإشعارات' : 'Notification Status'}
              </span>
            </div>
            <div className="flex items-center gap-2">
              {isPermissionGranted ? (
                <>
                  <CheckCircle className="h-5 w-5 text-green-600" />
                  <Badge variant="secondary" className="text-green-600">
                    {language === 'ar' ? 'مفعلة' : 'Enabled'}
                  </Badge>
                </>
              ) : (
                <>
                  <AlertTriangle className="h-5 w-5 text-orange-600" />
                  <Badge variant="secondary" className="text-orange-600">
                    {language === 'ar' ? 'غير مفعلة' : 'Disabled'}
                  </Badge>
                  <Button 
                    size="sm" 
                    onClick={requestNotificationPermission}
                    className="ml-2"
                  >
                    {language === 'ar' ? 'تفعيل' : 'Enable'}
                  </Button>
                </>
              )}
            </div>
          </div>

          {/* Basic Settings */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="flex items-center justify-between">
              <Label htmlFor="push-notifications" className="flex items-center gap-2">
                <Bell className="h-4 w-4" />
                {language === 'ar' ? 'الإشعارات الفورية' : 'Push Notifications'}
              </Label>
              <Switch
                id="push-notifications"
                checked={settings.enablePushNotifications}
                onCheckedChange={(checked) => updateSetting('enablePushNotifications', checked)}
              />
            </div>

            <div className="flex items-center justify-between">
              <Label htmlFor="sound-alerts" className="flex items-center gap-2">
                {settings.enableSoundAlerts ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
                {language === 'ar' ? 'التنبيهات الصوتية' : 'Sound Alerts'}
              </Label>
              <Switch
                id="sound-alerts"
                checked={settings.enableSoundAlerts}
                onCheckedChange={(checked) => updateSetting('enableSoundAlerts', checked)}
              />
            </div>

            <div className="flex items-center justify-between">
              <Label htmlFor="priority-only" className="flex items-center gap-2">
                <Zap className="h-4 w-4" />
                {language === 'ar' ? 'الإشارات عالية الأولوية فقط' : 'Priority Signals Only'}
              </Label>
              <Switch
                id="priority-only"
                checked={settings.prioritySignalsOnly}
                onCheckedChange={(checked) => updateSetting('prioritySignalsOnly', checked)}
              />
            </div>
          </div>

          {/* Advanced Filters */}
          <div className="space-y-4">
            <h4 className="font-medium flex items-center gap-2">
              <Filter className="h-4 w-4" />
              {language === 'ar' ? 'فلاتر متقدمة' : 'Advanced Filters'}
            </h4>

            {/* Minimum Confidence */}
            <div className="space-y-2">
              <Label>
                {language === 'ar' ? 'الحد الأدنى للثقة' : 'Minimum Confidence'}: {settings.minimumConfidence}%
              </Label>
              <Slider
                value={[settings.minimumConfidence]}
                onValueChange={(value) => updateSetting('minimumConfidence', value[0])}
                max={100}
                min={50}
                step={5}
                className="w-full"
              />
            </div>

            {/* Risk Level Filter */}
            <div className="space-y-2">
              <Label htmlFor="risk-filter">
                {language === 'ar' ? 'فلتر مستوى المخاطرة' : 'Risk Level Filter'}
              </Label>
              <Select value={settings.riskLevelFilter} onValueChange={(value) => updateSetting('riskLevelFilter', value)}>
                <SelectTrigger id="risk-filter">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ALL">
                    {language === 'ar' ? 'جميع المستويات' : 'All Levels'}
                  </SelectItem>
                  <SelectItem value="LOW">
                    {language === 'ar' ? 'مخاطرة منخفضة فقط' : 'Low Risk Only'}
                  </SelectItem>
                  <SelectItem value="MEDIUM">
                    {language === 'ar' ? 'مخاطرة متوسطة فقط' : 'Medium Risk Only'}
                  </SelectItem>
                  <SelectItem value="HIGH">
                    {language === 'ar' ? 'مخاطرة عالية فقط' : 'High Risk Only'}
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Frequency Limit */}
            <div className="space-y-2">
              <Label>
                {language === 'ar' ? 'الحد الأقصى للإشعارات في الساعة' : 'Max Notifications per Hour'}: {settings.frequencyLimit}
              </Label>
              <Slider
                value={[settings.frequencyLimit]}
                onValueChange={(value) => updateSetting('frequencyLimit', value[0])}
                max={20}
                min={1}
                step={1}
                className="w-full"
              />
            </div>
          </div>

          {/* Test Notification */}
          <div className="flex gap-2">
            <Button 
              onClick={sendTestNotification} 
              disabled={!isPermissionGranted}
              variant="outline"
              className="flex items-center gap-2"
            >
              <Bell className="h-4 w-4" />
              {language === 'ar' ? 'اختبر الإشعارات' : 'Test Notification'}
            </Button>
            
            <Button onClick={clearAllNotifications} variant="outline">
              {language === 'ar' ? 'مسح الكل' : 'Clear All'}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Recent Notifications */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5" />
            {language === 'ar' ? 'الإشعارات الأخيرة' : 'Recent Notifications'}
          </CardTitle>
          <CardDescription>
            {language === 'ar' 
              ? 'آخر الإشعارات المرسلة حسب إعداداتك'
              : 'Latest notifications sent based on your settings'
            }
          </CardDescription>
        </CardHeader>
        <CardContent>
          {notifications.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <Bell className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>{language === 'ar' ? 'لا توجد إشعارات حتى الآن' : 'No notifications yet'}</p>
              <p className="text-sm mt-2">
                {language === 'ar' 
                  ? 'ستظهر الإشعارات هنا عند توفر إشارات تداول جديدة'
                  : 'Notifications will appear here when new trading signals are available'
                }
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {notifications.map((notification) => (
                <div
                  key={notification.id}
                  className={`p-4 rounded-lg border transition-all hover:bg-muted/50 ${
                    !notification.read ? 'bg-primary/5 border-primary/20' : 'bg-muted/20'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-3">
                      <div className={`mt-1 ${getPriorityColor(notification.priority)}`}>
                        {getPriorityIcon(notification.priority)}
                      </div>
                      <div className="flex-1">
                        <h4 className="font-medium">{notification.title}</h4>
                        <p className="text-sm text-muted-foreground mt-1">
                          {notification.message}
                        </p>
                        <p className="text-xs text-muted-foreground mt-2">
                          {notification.timestamp.toLocaleString(language === 'ar' ? 'ar-SA' : 'en-US')}
                        </p>
                      </div>
                    </div>
                    <Badge 
                      variant="secondary" 
                      className={getPriorityColor(notification.priority)}
                    >
                      {notification.priority}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Smart Features Info */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Zap className="h-5 w-5" />
            {language === 'ar' ? 'الميزات الذكية' : 'Smart Features'}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 bg-blue-50 dark:bg-blue-950/20 rounded-lg border border-blue-200 dark:border-blue-800">
              <div className="flex items-start gap-3">
                <Target className="h-5 w-5 text-blue-600 mt-0.5" />
                <div>
                  <h4 className="font-medium text-blue-900 dark:text-blue-100">
                    {language === 'ar' ? 'فلترة ذكية' : 'Smart Filtering'}
                  </h4>
                  <p className="text-sm text-blue-700 dark:text-blue-300 mt-1">
                    {language === 'ar' 
                      ? 'يتم تصفية الإشعارات تلقائياً حسب تفضيلاتك وأوقات التداول المثالية'
                      : 'Notifications are automatically filtered based on your preferences and optimal trading times'
                    }
                  </p>
                </div>
              </div>
            </div>

            <div className="p-4 bg-green-50 dark:bg-green-950/20 rounded-lg border border-green-200 dark:border-green-800">
              <div className="flex items-start gap-3">
                <TrendingUp className="h-5 w-5 text-green-600 mt-0.5" />
                <div>
                  <h4 className="font-medium text-green-900 dark:text-green-100">
                    {language === 'ar' ? 'أولويات ذكية' : 'Smart Priorities'}
                  </h4>
                  <p className="text-sm text-green-700 dark:text-green-300 mt-1">
                    {language === 'ar' 
                      ? 'الإشارات عالية الثقة والمخاطرة المنخفضة تحصل على أولوية أعلى'
                      : 'High confidence and low risk signals receive higher priority'
                    }
                  </p>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}